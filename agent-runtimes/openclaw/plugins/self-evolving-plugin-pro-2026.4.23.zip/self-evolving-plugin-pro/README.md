# Self-Evolving Plugin Pro

全新 OpenClaw 实例先安装这个 plugin：

```bash
/path/to/self-evolving-plugin-pro/scripts/install-openclaw-plugin.sh
```

plugin 内置的 skill 不需要单独注册。
OpenClaw 会在 plugin 安装并启用后，按 `openclaw.plugin.json` 里的 `skills: ["./skills"]` 自动加载。

如果当前 shell 的工作目录是正常的，也可以直接运行：

```bash
cd /path/to/self-evolving-plugin-pro
openclaw plugins install /path/to/self-evolving-plugin-pro
/path/to/self-evolving-plugin-pro/scripts/setup-runtime.sh
```

如果用户没有 CLI，只能通过飞书对话触发安装，直接把下面这段发给具备插件安装上下文的 OpenClaw 管理 bot 即可：

```text
请不要手动解压 zip 到 `/tmp` 或其他临时目录；请直接用内部插件包执行 `openclaw plugins install <插件包路径>`。
安装完成后，进入 OpenClaw 的实际安装目录 `~/.openclaw/extensions/self-evolving-plugin-pro`，在这个目录里执行 `./scripts/setup-runtime.sh`，然后立刻调用插件 FastAPI 后端的 HTTP `GET /ready` 接口确认服务已经就绪。
在重启前创建一个一次性的 cron job，让它在 1 分钟后再次检查一次 `GET /ready` 并把结果回复到当前会话，然后再执行 `openclaw gateway restart`；因为重启会打断当前 agent，会话里不要把重启后的检查写成同步步骤。
最后先把版本、安装目录、重启前 `GET /ready` 结果和失败日志摘要回复给我。
```

这个插件会做一件事：

记住报错和你的纠正，
下次遇到类似情况时，
先提醒模型少走弯路。

你平时不用专门操作。

正常聊天就行。

如果你想手动看一眼，用这 6 个命令：

```text
/learn status
/learn signals
/learn expressions
/learn review
/learn report
/learn reports
```

它们分别表示：

- `status`
  看它有没有在工作

- `signals`
  看最近记住了什么问题和反馈

- `expressions`
  看它已经学会了哪些经验

- `review`
  立刻跑一次新的回看，总结最近对话

- `report`
  直接看最近一条已经生成好的日报详情，不重跑回看

- `reports`
  看最近几次已经生成好的日报历史列表

最简单的流程就是：

```text
报错或你纠正它
-> 它记下来
-> 它回看最近对话
-> 它学会一条经验
-> 下次先提醒模型
```

## 开发检查

这个仓库现在按 JS/Python 混合工程来收口：

- JS 侧：`prettier` + `eslint` + `tsc --checkJs`
- Python 侧：`ruff format` + `ruff check` + `mypy`
- 单测：`python -m pytest tests`

初始化开发环境：

```bash
npm run bootstrap:dev
```

完整检查：

```bash
npm run check
```

安装 git hooks：

```bash
npm run hooks:install
```

现在 hook 由 `pre-commit` 管理：

- `pre-commit` 阶段只跑 staged files 的快速检查
- `pre-push` 阶段跑完整的 `npm run check`

如果你之前装过旧版手写 `.githooks`，重新执行一次 `npm run hooks:install` 就会切到新的 hook 流程。

## 发版

发版脚本已经拆成可单独调试的几步：

- `npm run release:preflight`
  检查 git 工作区、依赖和基础文件
- `npm run release:next`
  计算下一个发版号
- `npm run release:set-version -- <release_version>`
  把版本同步到 `VERSION`、`package.json`、`openclaw.plugin.json`、`fastapi_service/version.py`
- `npm run release:verify`
  跑完整格式化检查、lint、typecheck、UT/回归测试
- `npm run release:package -- <release_version>`
  基于 git tracked files 打包 zip，并生成 `release.json` 和 `SHA256SUMS`

单入口：

```bash
npm run release
```

默认规则：

- 当天第一次发版：`YYYY.MM.DD`
- 当天 hotfix：`YYYY.MM.DD.N`
- zip 产物输出到：`dist/releases/<release_version>/`

为了兼容 `package.json` 的 semver 约束，脚本会同时生成一个包内版本：

- `2026.03.28` -> `2026.3.28`
- `2026.03.28.1` -> `2026.3.28-hotfix.1`

zip 名称、`VERSION` 和 release manifest 仍然使用原始的日期版号。

如果要在临时环境里调试脚本，可以用这些环境变量：

- `OPENCLAW_RELEASE_REPO_ROOT`
- `OPENCLAW_RELEASE_DATE`
- `OPENCLAW_RELEASE_OUTPUT_DIR`
- `OPENCLAW_RELEASE_ALLOW_DIRTY=1`
