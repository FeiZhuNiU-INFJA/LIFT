# Changelog

## 2026.4.23

- `scripts/install-openclaw-plugin.sh` 里 `openclaw plugins install` 命令加上 `--dangerously-force-unsafe-install` flag。OpenClaw 2026.4.10+ 新增静态代码扫描（`skill-scanner-*.js` 里的 `dangerous-exec` + `env-harvesting` 两条 critical 规则），把 `src/runtimeManager.js`（spawn 后端 uvicorn + `process.env` + localhost fetch 组合）、`src/review/worker.js`（spawn `openclaw agent --local`）、`src/plugin/client.js`（spawn http 客户端）四处 block 掉。这几处都是 plugin 架构的必需品，实际 IO 目标只有 127.0.0.1:18090 本地后端；加 flag 是明确声明"知道这些匹配命中但都是合法使用"。已在本机安装脚本里带注释说明，避免后续 review 的人误删。本次改动不影响运行期（扫描只在 install/update/audit 时触发），Gateway 加载 / hooks / review / signal 全链路都已在 2026.4.22 的端到端验证里跑通。

## 2026.4.22

- 修 `buildExpressionXml` 在 prompt 注入里一直用本地 `gene_id` 的 bug。根因：2026-04-01 `2b9987f Track remote gene matches in reviews` 定下"只用 remote_gene_id"的全站契约，当时改了 `learnUi.js` / `promptBuilder.js`，但 hook 注入路径漏改；后续 20 多个 commit 一直原样搬运。这一处偏偏又是整条 `expression → LLM → trace` 数据管线上**最后也是唯一**一个带 id 的外化出口——id 错了，下游 trace/回流/跨 instance 聚合就无法 join 远端 gene 表，收到的全是 local sqlite 自增主键，没法聚合。现在 `<expression>` 只输出 `remote_gene_id`，缺 `remote_gene_id` 的 active expression 直接跳过不注入（绝不 fallback 到 local id，避免 trace 被污染成看似 global 实则 local 的垃圾数据）。
- 去掉 `buildExpressionXml` 写死的 5 条上限。上限是 2026-03-30 PoC 提交 `2dbfca7 implement first release PoC version` 里拍的，没有任何 commit / CHANGELOG / 讨论给过设计依据。主动截断后面的 expression = 对 trace 管线撒谎（"这条规则没参与"），和上一条修复的语义背道而驰。注入侧改成按 `created_at DESC` 取最近 10 条，显式 rehome "最近规则优先"的语义；若 active expression 超过 10 条，老的不进 prompt 但仍然在 DB 里可通过 `/learn expressions` 查到。
- 测试覆盖：新增 `skips expressions missing remote_gene_id to protect trace aggregation` 和 `orders by created_at desc and caps at 10 expressions`，加上原有 `builds expression xml with escaped payloads`（改为 remote_gene_id 输入）。JS hook-only injection E2E、Python 源文件断言（`test_review_flow.py` / `test_service_bootstrap.py`）全部切到新字段。

## 2026.4.21

- 修 webchat 页面上 `<self-evolving><protocol>...` 整段 XML 可见的 UX bug。根因是 `before_prompt_build` 返回 `prependContext`，OpenClaw（`runEmbeddedAttempt`）把它拼到 user turn prompt 前面（`effectivePrompt = prependContext + effectivePrompt`），所以 webchat 在消息气泡里渲染出来。改成 `prependSystemContext`，走 `composeSystemPromptWithHookContext` → `applySystemPromptOverrideToSession`，注入到 agent session 的 system prompt（用户不可见，且 providers 可做 prompt caching 减少每轮 input token）。Expressions 早已在 `appendSystemContext`，两者方向一致。
- Compaction 无损：run loop 每次 `continue` 重走 `runEmbeddedAttempt`，hook 重跑并重新 apply system prompt override；system prompt 本身不在被压缩的 message 历史里。实测主 gateway restart 后，user turn 不再带 protocol 前缀，LLM 仍能在 system prompt 里看到协议（问它能确认、要求 dump 能完整输出），信号提取 curl exec 链路正常（DB 新增 implicit_correction/success_confirmation 条目，`source=agent_tool_call`）。

## 2026.4.16

- `session_start` hook 真正稳定触发了。实测：`openclaw gateway call chat.send` 用全新 webchat sessionKey 跑 3 次，`SESSION_START_HOOK_FIRED` 3/3 命中，每次都 spawn 出 review worker 子进程并 completed。之前 CLI 测试（`openclaw agent -t` / `openclaw gateway call agent`）看不到 session_start 是因为 `agent` RPC 路径绕过了 `getReplyFromConfig → initSessionState`，只有 `chat.send` / dispatchInboundMessage 路径会触发；这条路径正是 WebChat UI 和 Feishu 入站消息的实际通路，所以生产流量就是跑的这条。
- 删掉 `sessionStartReviewIntervalHours` 这个 4 小时节流（`src/plugin/autoReview.js`）。OpenClaw 的 `runSessionStart` 本身只在 `isNewSession === true` 时才派发，session 级去重已经在 gateway 层做过；plugin 端不再叠一层时间窗，每个新 session 都跑一次 review。timer review 仍保留 24 小时 cadence。
- 修 review worker 在 launchd gateway 下 `OpenClaw CLI is unavailable` 的 bug。launchd 的 PATH 只有 `~/.nvm` 根目录而没有 `~/.nvm/versions/node/*/bin`，fallback 到 PATH 查找 `openclaw` 找不到。新 `resolveCliPath` 先走 `OPENCLAW_CLI_PATH` env 覆盖，再从 `require.main.filename` 回溯找 `package.json name === "openclaw"` 的目录、按 npm global 布局推导 `../../../bin/openclaw`，最后才兜底 PATH。实测 launchd gateway 下 review 真的跑通了（`status=completed`，报告长度 260–410 字节）。
- 删掉 `src/plugin/hooks.js` 和 `signals.js` 里残留的 sanitizer 代码（`stripLearningRecord` / `sanitizePayload` / `createMessageSendingSanitizer` / `createBeforeMessageWriteSanitizer`）——信号收集已经完全走 `after_tool_call` + `llm_output`，这些 helper 自 exec-tool signal 协议之后就是死码。相应 `message_sending` / `before_message_write` hook 注册也一起下线。
- `scripts/setup-runtime.sh` 里 `flock` 改成 feature-detect：stock macOS 默认没装 util-linux，测试环境下整条 setup 链会直接 `flock: command not found` 失败。`command -v flock` 不存在时降级跳过锁，setup 其余步骤本身是幂等的，并发风险可接受。
- **版本号体系重构**：砍掉双轨制。之前 `release_version="2026.04.15.1"` / `package_version="2026.4.15-hotfix.1"` 两套版本号不一致（月日补零 vs 不补零、`-hotfix.N` 是自造后缀不是 semver 标准排序语义），`versioning.py` 里 `to_package_version` 做字符串翻译层。现在统一成 `YYYY.M.D`（不补零，合法 semver），`VERSION_RE` 显式拒绝 `2026.04.15`（前导零违反 semver 2.0.0）和 `2026.4.15-N`（pre-release 后缀 semver 上排序反而**低于** `2026.4.15`，跟 hotfix 语义相反）。
- 同日重打直接覆盖 `dist/releases/YYYY.M.D/` 下的 zip 和 manifest，不引入后缀计数。`next-version` 永远返回当天日期，不再扫 git tag / dist 目录做递增。`release_version` / `package_version` 双字段从 `runtime-ready.json`、`/ready` 响应、gene event producer metadata、`helpers.py`、`RuntimeReadiness` model、`smoke-openclaw-plugin.sh` 里全部移除，统一成 `version`。
- **信号提取协议重写**：从「只抓显式评价」切到召回优先——每轮用户消息过三个判断问题（显式评价 / 行为偏离预期 / 暴露偏好约束），任一为"是"就记录信号，用较低 trust 反映不确定度。signal kind 从 4 种扩展到 9 种：新增 `implicit_correction`（重问/自改/换问法暗示不满意）、`preference_signal`（风格/工具偏好）、`context_revealed`（补充本该前置的上下文）、`silent_pivot`（忽略上一轮直接开新话题）、`pending`（信号不完整/句子未说完）。trust 下限从 0.6 降到 0.4，增加回顾式补记机制（对话收尾/话题切换时回溯补打之前的弱信号）。全栈同步更新：JS `normalizeSignalKind` + `classifyUserFeedback`、Python `SignalKind` Literal / `_normalize_signal_kind` / SQL backfill CASE / review 中文标签。

## 2026.04.15.1

- Review prompt 与 workspace patch flag 对齐：之前即使 server 端禁用了文件 patching（2026.04.15 改动），review prompt 仍然在问 reviewer「请从 binding candidates 里挑 target_file」，生成的 expression 带着 `target_file=AGENTS.md` 被 server 静默降级到 runtime_only，既费 token 又让 review 报告错写"落点 AGENTS.md"。
- 新增 `ExpressionApplyPolicy` 字段（`workspace_patch_enabled` + `apply_mode`）通过 `/reviews/{id}/workset` 下发给 prompt builder。
- `src/review/promptBuilder.js` 根据 policy 切两套 prompt：flag 关闭（默认）时走 hook-only guidance — 显式告知 reviewer 不要传 `target_file`/`binding_ref`、不要引用 workspace 文件、content 直接作为 system prompt 注入；flag 打开时保留原来的 binding-candidates 路径。报告模板同步不再提「落点文件」。
- 真实 openclaw agent E2E 验证：
  - `/reviews/{id}/workset` 返回 `expression_apply_policy={workspace_patch_enabled: false, apply_mode: "hook_only"}`
  - review 新建的 expression `apply_mode=runtime_only, target_file='', binding_ref='', apply_commit=''`
  - 规则 content 通过 hook 作用到 LLM 调用（模型在后续对话里问出「是否需要手动实现特定排序算法？是否禁止使用内置函数？」完全对应新规则）
  - 整个 review + 后续 session 期间 `~/.openclaw/workspace/AGENTS.md` md5 不变

## 2026.04.15

- 默认禁用 expression 对 workspace 文件的 patching。原来的 `_is_review_anchor_path` 只按文件名判断是否是 anchor（看到 `AGENTS.md` 就认），从来没校验过这个文件真的属于当前 instance 的 workspace；如果 `instance.workspace_root` 指向一个含有别家 AGENTS.md（Cursor / Claude Code / 其它 agent 框架）的目录，会把别人的文件改掉。新增配置 `OPENCLAW_EVOLUTION_EXPRESSION_WORKSPACE_PATCH_ENABLED`（默认 `false`），关闭时所有 expression 一律落成 `apply_mode=runtime_only`，规则只通过 `before_prompt_build` hook 注入到 LLM prompt 里，**不**写任何 workspace 文件。开关打开可恢复旧行为。
- 修一个相关的 belt-and-suspenders 设计错误。flag 关闭时，`_sync_workspace_bound_expression` 现在仍允许**移除**遗留的 tagged block（disable 路径），只拦**写入**。否则 history 里 workspace_bound 的 expression 没法被 `/learn disable` 真正清理 AGENTS.md。
- 新增真实 LLM 端到端验证（不是 mock）：用唯一标记 `PINEAPPLE-MARKER-8845` 的 expression 跑 `openclaw agent --local`，确认 marker 出现在 LLM 输出里同时 AGENTS.md 文件 md5 完全不变。修复后 hook 注入是规则唯一作用通道。
- 新增 `test_auto_enable_does_not_patch_workspace_by_default`（验证 flag 关闭时 AGENTS.md 不被碰且 expression 仍能被 `list_expressions("active")` 拉到）和 `hook-only injection: active expression content lands in appendSystemContext end-to-end`（用真实 `buildExpressionXml` 穿过 `createBeforePromptBuildHandler`，断言 content 一字不差进 `appendSystemContext`）。

## 2026.04.14.1

- 修复 auto-enable expression 不写 workspace 文件的严重 bug。`create_expression` 里 confidence/risk 门控把 status 直接改成 active 后，没有调用负责把 `<openclaw-expression>` 块写进 AGENTS.md 的 `_sync_workspace_bound_expression` —— DB 里规则是 active，但 prompt 文件从来没收到过注入，review 生成的规则实际上永远不会被 LLM 看到。现在 create 完后检查 status+apply_mode，workspace_bound 的 active expression 会立即写入目标文件并 commit 回 apply_commit。同一条修复也覆盖了调用方显式传 `status=active` 的路径。
- 新增两条回归测试 `test_auto_enable_workspace_bound_expression_writes_block_on_create` 和 `test_auto_enable_below_threshold_leaves_workspace_untouched`，锁住这个行为不再退化。
- 修复 onboard 流程 SQLite "database is locked" 错误。`onboard_instance` 在事务内触发 `_ensure_initial_gene_cache`，后者开第二条 session 批量 INSERT 64 条 bundled gene —— SQLite 单 writer 且默认 busy_timeout=0，新机器上 onboard 首次调用就 500。现在把 session 贯穿下去，create 和 gene sync 共享同一连接。
- 引擎级 PRAGMA 加固：每个连接自动启用 `journal_mode=WAL`、`busy_timeout=30000`、`synchronous=NORMAL`，给任何未来可能出现的并发写场景留出 30s 缓冲。
- `session_start` handler 改成 fire-and-forget：之前 OpenClaw 会 await handler 完成才让用户发第一条消息，而 `maybeRunAutoReview` 会 spawn 子进程跑 review 几十秒到几分钟，严重阻塞 session 启动。现在 `ensureReady` 仍然 await（便宜），review 在后台跑，失败只 logger.warn，不阻塞用户。

## 2026.04.14

- 修复自动 review 的重试风暴：`maybeRunAutoReview` 原来只在 `runReviewWorker` 返回后才更新 `lastAutoReviewAt`，review 抛错时时间戳永远不前进，导致每 5 分钟 timer tick 都重试，观察到生产上累积了 ~1100 条 `status=failed` 的 timer review。现在在 await worker 之前就 claim 时间戳，失败也按一个 interval 休眠。
- 新增 `reviews_store.cleanup_stale_reviews` + 启动时自动调用：把 `status=running` 且 `updated_at` > 30 分钟的僵尸 review 标 failed；`status=failed reason_text=timer` 只保留最近 50 条，清理历史累积。
- Expression 新增 `confidence` / `risk` 字段（DB 列 + pydantic 校验 0.0-1.0）。`create_expression` 检测到默认 `disabled` 请求且 `confidence >= 0.85 && risk <= 0.25` 时自动晋级为 `active`，阈值通过 `OPENCLAW_EVOLUTION_EXPRESSION_AUTO_ENABLE_CONFIDENCE/_RISK` 环境变量可调。显式 `status=active` 请求不被覆盖。
- Review prompt 同步更新：要求 review agent 为每条 expression 输出带校准标准的 confidence 和 risk，并告知自动启用规则；报告模板里「待你决定启用」只列 disabled 的 expression。
- 将云端 gene list 和 event report 接口的调用路径全部注释掉，插件自带 `fastapi_service/data/bundled_genes.json` 静态快照（64 条 PG-* gene，与云端 1:1 对齐）。`_ensure_initial_gene_cache` 改为从 bundle 加载；`_fetch_remote_gene_items` / `flush_pending_gene_events` 成为本地 no-op，gene events 仍落本地 outbox 不丢数据。
- `OPENCLAW_EVOLUTION_GENE_ENDPOINT` 和 `OPENCLAW_EVOLUTION_GENE_TOKEN` 的默认值改成 `None`，只从 env 读，没有就禁用云端。

## 2026.04.11

- 修复 signal 收集链路：LLM 触发的 curl 之前一直用错误的 header 名 `X-Instance-Id` / `X-Instance-Token`，后端期望的是 `x-openclaw-instance-id` / `x-openclaw-instance-token`；请求能过是因为后端在 header 缺失时只靠 body 里的 `instance_id` 放行，auth 实际上从未生效。现在头部已对齐。
- 去掉 signal exec-template 外层的 `<![CDATA[ ... ]]>` 包装。之前 LLM 会把 CDATA 标记当成 shell 命令的一部分照抄执行，第一次调用必失败，需要第二次重试才能命中。现在单次调用一次成功。
- 重写 signal 协议 prompt：加入正例/反例对照、paraphrase 判断法、`kind` 和 `trust` 的选择规则、以及「不要包 markdown / 反引号 / CDATA」的显式执行约束。解决了"我运行时报了 SyntaxError 是什么原因"这类错误汇报被误记为 correction 信号的 false positive。
- 本地完整链路回归：feedback → signal → review → expression → 下一轮 prompt 注入，全部正常跑通。新建的 expression 在下一个 session 里被 LLM 实际遵循（输出里可见"逐条验证"和"主动扩展"行为）。

## 2026.04.01.1

- review 现在只向模型暴露 `remote_gene_id`，不再泄露本地 gene 主键；创建 expression 时也支持直接用 `remote_gene_id` 完成关联。
- review complete 新增 `signal_id -> remote_gene_ids` 回传并落库：signal 会记录命中的 remote gene，gene cache 自身维护真实 `hit_count`。
- Signals、Genes 和 `/learn signals` / expression 详情展示统一切到新字段，默认优先展示 remote gene 关联和真实 gene 命中统计。

## 2026.04.01

- 修复安装脚本错误使用源码 link 安装的问题，改成默认复制安装；如果脚本已经在 `extensions/self-evolving-plugin-pro` 目录里执行，则跳过重复安装，只做 runtime setup 和 gateway restart。
- 在 `runtime-ready.json` 与 `/ready` 返回中补上 `version` 和 `release_version`，为后续 runtime migrate 和版本诊断提供稳定锚点。
- 优化 Signals 页面展示：摘要优先显示模型摘要，右侧详情单独展示 `模型摘要`、`用户回复`、`模型标签`，原始模型输出降级到调试区，避免把上一条模型输出误当成主内容。

## 2026.03.31.3

- 修复安装脚本错误使用 `openclaw plugins install -l` 的问题，源码目录安装改成默认复制安装，避免飞书/临时目录场景把 `/tmp` 路径写进 `plugins.load.paths`。
- 收紧安装脚本行为：如果脚本已经在 `extensions/<plugin-id>` 目录里执行，则跳过重复安装，只做 runtime setup 和 gateway restart。
- 在 `runtime-ready.json` 和 `/ready` 返回里补上 `version` 与 `release_version`，为后续 runtime migrate 提供明确的版本锚点。

## 2026.03.31.2

- 将聊天里的 `/learn review` 改成和 CLI 一致的同步返回模式，不再先回 queued 提示；review 结束后直接返回最终报告。
- 收紧 review 主链：`--since` 现在会真实参与 session 和 signal 过滤，同时把 disabled expressions 作为 pending 候选暴露给 review 做去重。
- 简化 workspace/expression 状态模型，彻底移除 policy snapshot 概念，统一回到 baseline commit + expression apply commit 的 git 驱动链路。
- 清理 review 和 gene 的错误设计：删除 public `POST /genes/lookup` 链路，review prompt 统一改为直接读取 `GET /genes` 候选集。

## 2026.03.31.1

- 用真实 OpenClaw CLI 补上 review E2E 回归，覆盖 plugin install、`learn status`、backend `/ready`、review prepare、真实 `openclaw agent --local` worker 和 gene list 主链路。
- 删除 fake `openclaw` E2E 依赖，旧的 spawn 错误回归改成纯进程 stub，不再用伪 CLI 可执行文件掩盖问题。
- 修复 fresh/dev 节点上的 bootstrap 与 CLI 生命周期问题：默认 agent workspace 选择、review timer `unref()`、detached backend `unref()`、默认端口占用自动重绑。
- 修复开发态 symlink state dir 与 workspace 解析问题，ready 判定和真实安装目录行为保持一致。

## 2026.03.31

- 删除 `POST /genes/lookup`，review 主链统一改为直接读取 `GET /genes` 的候选集，避免单结果假检索。
- 新增真实 OpenClaw plugin review E2E 回归，覆盖 live backend、真实命令注册和 review worker 调用链。
- 修复 backend 启动在默认 `18090` 端口被占用时的失败路径，默认 endpoint 现在会自动重绑空闲端口。
- 修复 symlink state dir 与 workspace 解析问题，ready 判定和默认 workspace 选择在开发态与 fresh 节点上一致。
- 收紧 workspace/expression tracking：baseline 序列化、锚点 diff、expression tagged apply/update/disable commit 追踪继续保持可用。

## 2026.03.30.1

- 修复旧版 OpenClaw 上 signal protocol 注入字段不兼容的问题，改用 `prependContext`。
- 修复 `llm_output` 学习记录被本地二次分类错误拦截的问题。
- 统一当天 hotfix 版本号与发版流程。

## 2026.03.30

- 发布自进化插件初始可安装 zip 包。
