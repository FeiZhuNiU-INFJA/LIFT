from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    openclaw_state_dir: str | None = None
    openclaw_workspace_root: str | None = None
    # Remote gene/event endpoints are opt-in. With both unset we ship a
    # bundled gene catalog (fastapi_service/data/bundled_genes.json) and the
    # event-report outbox becomes a local no-op. Operators can re-enable by
    # exporting OPENCLAW_EVOLUTION_GENE_ENDPOINT and _TOKEN.
    openclaw_evolution_gene_endpoint: str | None = None
    openclaw_evolution_gene_token: str | None = None
    # A new expression is auto-enabled (status forced to "active") when
    # confidence >= auto_enable_confidence AND risk <= auto_enable_risk,
    # BUT only if the request did not explicitly ask for a non-disabled
    # status. This lets the reviewer promote obvious wins without user
    # intervention while keeping risky ones gated behind /learn enable.
    openclaw_evolution_expression_auto_enable_confidence: float = 0.85
    openclaw_evolution_expression_auto_enable_risk: float = 0.25
    # Workspace file patching is off by default. When an instance's
    # workspace_root points at an unrelated project that happens to
    # contain files with names in KNOWN_OPENCLAW_FILES (e.g. another
    # agent framework's AGENTS.md), enabling this will overwrite those
    # files. The safer path is hook-only injection via
    # listExpressions("active") + buildExpressionXml in the JS plugin.
    # Flip to true only when you trust every instance's workspace_root to
    # be a real OpenClaw workspace.
    openclaw_evolution_expression_workspace_patch_enabled: bool = False
    model_config = {"env_prefix": "", "case_sensitive": False}
