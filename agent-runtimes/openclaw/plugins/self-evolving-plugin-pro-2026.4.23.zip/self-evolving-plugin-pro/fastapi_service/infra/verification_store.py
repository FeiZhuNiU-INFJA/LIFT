from __future__ import annotations

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.modules.verification.schemas import VerificationRun

from .models import VerificationRunRecord


def create_verification_run(session: Session, record: VerificationRunRecord) -> VerificationRun:
    persist(session, record)
    return VerificationRun.from_record(record)


def list_verification_runs(session: Session, instance_id: str, limit: int) -> list[VerificationRun]:
    statement = select(VerificationRunRecord).where(VerificationRunRecord.instance_id == instance_id)
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [VerificationRun.from_record(row) for row in rows[:limit]]
