from __future__ import annotations

import json

from sqlmodel import Session, select

from fastapi_service.modules.instances.schemas import RuntimeStatePayload

from .models import InstanceRecord, SignalRecord
from .paths import runtime_state_path


def get_instance_by_id(session: Session, instance_id: str) -> InstanceRecord | None:
    return session.exec(select(InstanceRecord).where(InstanceRecord.id == instance_id)).first()


def get_instance_token(session: Session, instance_id: str) -> str | None:
    row = get_instance_by_id(session, instance_id)
    return None if row is None else row.instance_token


def resolve_default_instance_id(session: Session) -> str | None:
    state_path = runtime_state_path()
    if state_path.exists():
        try:
            payload = RuntimeStatePayload.model_validate(json.loads(state_path.read_text()))
            instance_id = str(payload.instanceId or "").strip()
            if instance_id and get_instance_by_id(session, instance_id):
                return instance_id
        except Exception:
            pass
    instances = list(session.exec(select(InstanceRecord)).all())
    if not instances:
        return None
    last_seen_by_instance: dict[str, int] = {}
    for row in session.exec(select(SignalRecord)).all():
        previous = last_seen_by_instance.get(row.instance_id)
        if previous is None or row.created_at > previous:
            last_seen_by_instance[row.instance_id] = row.created_at
    latest_instance = max(
        instances,
        key=lambda row: (last_seen_by_instance.get(row.id, row.created_at), row.created_at),
    )
    return str(latest_instance.id)
