from __future__ import annotations

import json
import time

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.infra.models import SignalRecord
from fastapi_service.modules.signals.models import SessionSummary, Signal, SignalCounts


def _filtered_signal_records(
    session: Session,
    instance_id: str,
    session_id: str | None = None,
    since_seconds: int | None = None,
) -> list[SignalRecord]:
    statement = select(SignalRecord).where(SignalRecord.instance_id == instance_id)
    if session_id:
        statement = statement.where(SignalRecord.session_id == session_id)
    if since_seconds is not None:
        statement = statement.where(SignalRecord.created_at >= int(time.time()) - since_seconds)
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return rows


def create_signal(session: Session, record: SignalRecord) -> Signal:
    persist(session, record)
    return Signal.from_record(record)


def list_signals(
    session: Session,
    instance_id: str,
    limit: int = 20,
    session_id: str | None = None,
    since_seconds: int | None = None,
) -> list[Signal]:
    rows = _filtered_signal_records(session, instance_id, session_id, since_seconds)[:limit]
    return [Signal.from_record(row) for row in rows]


def signal_counts(session: Session, instance_id: str, since_seconds: int | None = None) -> SignalCounts:
    rows = _filtered_signal_records(session, instance_id, since_seconds=since_seconds)
    return SignalCounts(
        total=len(rows),
        tool_failure_count=sum(1 for row in rows if row.kind == "tool_failure"),
        correction_count=sum(1 for row in rows if row.kind == "correction"),
        success_count=sum(1 for row in rows if row.kind == "success_confirmation"),
        frustration_count=sum(1 for row in rows if row.kind == "frustration"),
    )


# def list_sessions(session: Session, instance_id: str, limit: int = 20, since_seconds: int | None = None) -> list[SessionSummary]:  # noqa: E501
def list_sessions(
    session: Session, instance_id: str, limit: int = 20, since_seconds: int | None = None
) -> list[SessionSummary]:
    rows = _filtered_signal_records(session, instance_id, since_seconds=since_seconds)
    by_session: dict[str, list[SignalRecord]] = {}
    for row in rows:
        by_session.setdefault(row.session_id, []).append(row)
    summaries = [
        SessionSummary(
            session_id=session_id,
            last_seen_at=max(item.created_at for item in session_rows),
            signal_count=len(session_rows),
            failure_count=sum(1 for item in session_rows if item.kind == "tool_failure"),
            correction_count=sum(1 for item in session_rows if item.kind == "correction"),
            success_count=sum(1 for item in session_rows if item.kind == "success_confirmation"),
        )
        for session_id, session_rows in by_session.items()
    ]
    summaries.sort(key=lambda item: item.last_seen_at, reverse=True)
    return summaries[:limit]


def session_turns(session: Session, instance_id: str, session_id: str) -> list[Signal]:
    rows = _filtered_signal_records(session, instance_id, session_id=session_id)
    rows.sort(key=lambda row: row.created_at)
    return [Signal.from_record(row) for row in rows]


def build_signal_record(
    *,
    signal_id: str,
    instance_id: str,
    session_id: str,
    user_id: str,
    kind: str,
    normalized_kind: str,
    content: str,
    tags: list[str],
    trust: float,
    source: str,
    source_ref: str | None,
    raw_payload: dict[str, object],
    classifier_note: str,
    created_at: int,
) -> SignalRecord:
    return SignalRecord(
        id=signal_id,
        instance_id=instance_id,
        session_id=session_id,
        user_id=user_id,
        kind=kind,
        normalized_kind=normalized_kind,
        content=content,
        tags_json=json.dumps(tags, ensure_ascii=False),
        trust=trust,
        source=source,
        source_ref=source_ref,
        raw_payload_json=json.dumps(raw_payload, ensure_ascii=False),
        matched_remote_gene_ids_json="[]",
        classifier_note=classifier_note,
        created_at=created_at,
    )
