from __future__ import annotations

import json

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.infra.models import (
    GeneRecord,
    ReviewMutationRecord,
    ReviewRecord,
    SignalRecord,
    WorkspaceChangeRecord,
)
from fastapi_service.modules.reviews.models import MutationMetrics, Review, ReviewMutation, WorkspaceChangeMetrics
from fastapi_service.modules.workspace.models import WorkspaceChange, WorkspaceChangeSummary


def _review_mutation_from_record(row: ReviewMutationRecord) -> ReviewMutation:
    return ReviewMutation.model_validate(row, from_attributes=True)


def _review_mutation_record_from_model(mutation: ReviewMutation) -> ReviewMutationRecord:
    return ReviewMutationRecord.model_validate(mutation, from_attributes=True)


def create_review(session: Session, payload: Review) -> Review:
    record = ReviewRecord(**payload.to_record())
    persist(session, record)
    return Review.from_record(record)


def get_review(session: Session, review_id: str) -> Review | None:
    row = session.get(ReviewRecord, review_id)
    return None if row is None else Review.from_record(row)


def list_reviews(session: Session, instance_id: str, limit: int = 20, status: str | None = None) -> list[Review]:
    statement = select(ReviewRecord).where(ReviewRecord.instance_id == instance_id)
    if status:
        statement = statement.where(ReviewRecord.status == status)
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [Review.from_record(row) for row in rows[:limit]]


def update_review(session: Session, review_id: str, payload: Review) -> Review | None:
    row = session.get(ReviewRecord, review_id)
    if row is None:
        return None
    data = payload.to_record()
    row.since_text = data["since_text"]
    row.reason_text = data["reason_text"]
    row.focus_session_id = data["focus_session_id"]
    row.workspace_change_id = data["workspace_change_id"]
    row.workspace_change_base_kind = data["workspace_change_base_kind"]
    row.status = data["status"]
    row.session_ids_json = data["session_ids_json"]
    row.matched_expression_ids_json = data["matched_expression_ids_json"]
    row.created_expression_ids_json = data["created_expression_ids_json"]
    row.updated_expression_ids_json = data["updated_expression_ids_json"]
    row.summary_text = data["summary_text"]
    row.stats_json = data["stats_json"]
    row.report_markdown = data["report_markdown"]
    row.error_text = data["error_text"]
    row.created_at = data["created_at"]
    row.updated_at = data["updated_at"]
    persist(session, row)
    return Review.from_record(row)


def list_review_mutations(session: Session, review_id: str) -> list[ReviewMutation]:
    rows = list(session.exec(select(ReviewMutationRecord).where(ReviewMutationRecord.review_id == review_id)).all())
    rows.sort(key=lambda row: row.created_at)
    return [_review_mutation_from_record(row) for row in rows]


def replace_review_mutations(session: Session, review_id: str, rows: list[ReviewMutation]) -> list[ReviewMutation]:
    existing = session.exec(select(ReviewMutationRecord).where(ReviewMutationRecord.review_id == review_id)).all()
    for item in existing:
        session.delete(item)
    for row in rows:
        session.add(_review_mutation_record_from_model(row))
    session.commit()
    return list_review_mutations(session, review_id)


def get_workspace_change(session: Session, change_id: str) -> WorkspaceChange | None:
    row = session.get(WorkspaceChangeRecord, change_id)
    return None if row is None else WorkspaceChange.from_record(row)


def dashboard_gene_total(session: Session, instance_id: str) -> int:
    rows = list(session.exec(select(GeneRecord).where(GeneRecord.instance_id == instance_id)).all())
    return len(rows)


def dashboard_session_total(session: Session, instance_id: str) -> int:
    rows = list(session.exec(select(SignalRecord).where(SignalRecord.instance_id == instance_id)).all())
    return len({row.session_id for row in rows})


def dashboard_workspace_change_summary(session: Session, instance_id: str) -> WorkspaceChangeMetrics:
    rows = list(
        session.exec(select(WorkspaceChangeRecord).where(WorkspaceChangeRecord.instance_id == instance_id)).all()
    )
    changed_file_total = 0
    for row in rows:
        summary = WorkspaceChangeSummary.model_validate(json.loads(row.summary_json or "{}"))
        changed_file_total += int(summary.changed_file_count or 0)
    return WorkspaceChangeMetrics(
        workspace_change_count=len(rows),
        workspace_changed_file_total=changed_file_total,
    )


def dashboard_mutation_summary(session: Session, instance_id: str) -> MutationMetrics:
    rows = list(session.exec(select(ReviewMutationRecord).where(ReviewMutationRecord.instance_id == instance_id)).all())
    return MutationMetrics(
        review_mutation_count=len(rows),
        applied_mutation_count=sum(1 for row in rows if row.status == "applied"),
    )


def cleanup_stale_reviews(session: Session, *, zombie_cutoff_ts: int, keep_failed: int = 50) -> dict[str, int]:
    """Reconcile review table state on startup.

    - Mark `running` reviews older than `zombie_cutoff_ts` as failed. Long-
      running reviews that outlive their host process otherwise stay in
      `running` forever.
    - Trim `failed` timer reviews beyond `keep_failed` (keeping the most
      recent ones for debugging). This is purely a disk/log hygiene fix;
      before the auto-retry flood was patched, this table could grow
      unbounded.
    """
    zombies = 0
    running_rows = session.exec(select(ReviewRecord).where(ReviewRecord.status == "running")).all()
    for row in running_rows:
        if row.updated_at and row.updated_at < zombie_cutoff_ts:
            row.status = "failed"
            row.error_text = "marked failed by startup cleanup (zombie running review)"
            row.updated_at = zombie_cutoff_ts
            session.add(row)
            zombies += 1
    failed_rows = list(
        session.exec(
            select(ReviewRecord).where(ReviewRecord.status == "failed").where(ReviewRecord.reason_text == "timer")
        ).all()
    )
    failed_rows.sort(key=lambda row: row.created_at, reverse=True)
    trimmed = 0
    for row in failed_rows[keep_failed:]:
        session.delete(row)
        trimmed += 1
    session.commit()
    return {"zombies_marked_failed": zombies, "failed_timer_trimmed": trimmed}


def get_last_completed_review(session: Session, instance_id: str) -> Review | None:
    rows = list(
        session.exec(
            select(ReviewRecord)
            .where(ReviewRecord.instance_id == instance_id)
            .where(ReviewRecord.status == "completed")
        ).all()
    )
    if not rows:
        return None
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return Review.from_record(rows[0])
