from __future__ import annotations

import json

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.infra.models import ExpressionRecord, GeneEventOutboxRecord, GeneRecord, SignalRecord
from fastapi_service.modules.genes.models import Gene, GeneEventOutbox


def get_gene_by_id(session: Session, gene_id: str, instance_id: str) -> Gene | None:
    statement = select(GeneRecord).where(GeneRecord.id == gene_id).where(GeneRecord.instance_id == instance_id).limit(1)
    row = session.exec(statement).first()
    return None if row is None else Gene.from_record(row)


def create_gene_event(session: Session, event: GeneEventOutbox) -> GeneEventOutbox:
    record = GeneEventOutboxRecord(**event.to_record())
    persist(session, record)
    return GeneEventOutbox.from_record(record)


def list_pending_gene_events(session: Session, limit: int = 100) -> list[GeneEventOutbox]:
    rows = list(session.exec(select(GeneEventOutboxRecord).where(GeneEventOutboxRecord.status == "pending")).all())
    rows.sort(key=lambda row: (row.created_at, row.event_id))
    return [GeneEventOutbox.from_record(row) for row in rows[:limit]]


def mark_gene_events_sent(session: Session, event_ids: list[str], sent_at: int) -> None:
    if not event_ids:
        return
    rows = list(session.exec(select(GeneEventOutboxRecord)).all())
    for row in rows:
        if row.event_id not in event_ids:
            continue
        row.status = "sent"
        row.attempt_count = int(row.attempt_count or 0) + 1
        row.last_error = None
        row.sent_at = sent_at
        session.add(row)
    session.commit()


def mark_gene_events_failed(session: Session, event_ids: list[str], error_text: str) -> None:
    if not event_ids:
        return
    rows = list(session.exec(select(GeneEventOutboxRecord)).all())
    for row in rows:
        if row.event_id not in event_ids:
            continue
        row.attempt_count = int(row.attempt_count or 0) + 1
        row.last_error = error_text
        row.sent_at = None
        session.add(row)
    session.commit()


def list_genes(session: Session, instance_id: str) -> list[Gene]:
    rows = list(session.exec(select(GeneRecord).where(GeneRecord.instance_id == instance_id)).all())
    rows.sort(key=lambda row: (row.hit_count, row.created_at), reverse=True)
    return [Gene.from_record(row) for row in rows]


def get_gene_by_remote_id(session: Session, instance_id: str, remote_gene_id: str) -> Gene | None:
    rows = list(
        session.exec(
            select(GeneRecord)
            .where(GeneRecord.instance_id == instance_id)
            .where(GeneRecord.remote_gene_id == remote_gene_id)
        ).all()
    )
    if not rows:
        return None
    rows.sort(
        key=lambda row: ((row.cache_refreshed_at or 0), row.created_at),
        reverse=True,
    )
    return Gene.from_record(rows[0])


def get_gene_by_pattern(session: Session, instance_id: str, pattern_key: str) -> Gene | None:
    rows = list(
        session.exec(
            select(GeneRecord).where(GeneRecord.instance_id == instance_id).where(GeneRecord.pattern_key == pattern_key)
        ).all()
    )
    if not rows:
        return None
    rows.sort(
        key=lambda row: ((row.cache_refreshed_at or 0), row.created_at),
        reverse=True,
    )
    return Gene.from_record(rows[0])


def create_gene(session: Session, gene: Gene) -> Gene:
    record = GeneRecord(**gene.to_record())
    persist(session, record)
    return Gene.from_record(record)


def update_gene(session: Session, gene_id: str, payload: Gene) -> Gene | None:
    row = session.get(GeneRecord, gene_id)
    if row is None:
        return None
    data = payload.to_record()
    row.summary = data["summary"]
    row.rule_text = data["rule_text"]
    row.pattern_key = data["pattern_key"]
    row.source = data["source"]
    row.remote_gene_id = data["remote_gene_id"]
    row.metadata_json = data["metadata_json"]
    row.hit_count = data["hit_count"]
    row.cache_refreshed_at = data["cache_refreshed_at"]
    row.created_at = data["created_at"]
    persist(session, row)
    return Gene.from_record(row)


def list_cloud_cache_genes(session: Session, instance_id: str) -> list[Gene]:
    statement = (
        select(GeneRecord).where(GeneRecord.instance_id == instance_id).where(GeneRecord.source == "cloud_cache")
    )
    rows = session.exec(statement).all()
    return [Gene.from_record(row) for row in rows]


def mark_expressions_stale_for_gene_ids(
    session: Session, instance_id: str, gene_ids: list[str], updated_at: int
) -> None:
    if not gene_ids:
        return
    rows = list(session.exec(select(ExpressionRecord).where(ExpressionRecord.instance_id == instance_id)).all())
    for row in rows:
        if row.status != "active" or row.gene_id not in gene_ids:
            continue
        row.status = "stale"
        row.updated_at = updated_at
        session.add(row)
    session.commit()


def delete_cloud_cache_genes(session: Session, instance_id: str, gene_ids: list[str]) -> None:
    if not gene_ids:
        return
    rows = list(session.exec(select(GeneRecord).where(GeneRecord.instance_id == instance_id)).all())
    for row in rows:
        if row.source != "cloud_cache" or row.id not in gene_ids:
            continue
        session.delete(row)
    session.commit()


def get_gene_name_by_id(session: Session, instance_id: str, gene_id: str) -> str | None:
    statement = (
        select(GeneRecord.summary).where(GeneRecord.id == gene_id).where(GeneRecord.instance_id == instance_id).limit(1)
    )
    return session.exec(statement).first()


def get_signal_match_ids(session: Session, signal_id: str, instance_id: str) -> list[str] | None:
    statement = (
        select(SignalRecord.matched_remote_gene_ids_json)
        .where(SignalRecord.id == signal_id)
        .where(SignalRecord.instance_id == instance_id)
        .limit(1)
    )
    value = session.exec(statement).first()
    if value is None:
        return None
    return json.loads(value or "[]")


def update_signal_match_ids(session: Session, signal_id: str, instance_id: str, remote_gene_ids: list[str]) -> None:
    row = session.exec(
        select(SignalRecord).where(SignalRecord.id == signal_id).where(SignalRecord.instance_id == instance_id).limit(1)
    ).first()
    if row is None:
        return
    row.matched_remote_gene_ids_json = json.dumps(remote_gene_ids, ensure_ascii=False)
    session.add(row)
    session.commit()


def increment_gene_hit_counts(session: Session, instance_id: str, remote_gene_ids: list[str]) -> None:
    if not remote_gene_ids:
        return
    rows = list(session.exec(select(GeneRecord).where(GeneRecord.instance_id == instance_id)).all())
    for row in rows:
        if row.remote_gene_id not in remote_gene_ids:
            continue
        row.hit_count = int(row.hit_count or 0) + 1
        session.add(row)
    session.commit()
