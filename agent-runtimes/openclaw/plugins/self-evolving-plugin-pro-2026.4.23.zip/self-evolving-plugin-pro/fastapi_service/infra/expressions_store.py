from __future__ import annotations

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.infra.models import ExpressionRecord
from fastapi_service.modules.expressions.models import Expression, ExpressionCounts


def _expression_from_record(row: ExpressionRecord) -> Expression:
    return Expression.model_validate(row, from_attributes=True)


def list_expressions(
    session: Session, instance_id: str, status: str | None = None, model_id: str | None = None
) -> list[Expression]:
    statement = select(ExpressionRecord).where(ExpressionRecord.instance_id == instance_id)
    if status:
        statement = statement.where(ExpressionRecord.status == status)
    rows = session.exec(statement).all()
    expressions = [_expression_from_record(row) for row in rows]
    if model_id:
        expressions = [
            row for row in expressions if row.model_id == model_id or row.model_id is None or row.model_id == ""
        ]
    expressions.sort(key=lambda row: (-row.hit_count, -row.created_at))
    return expressions


def expression_counts(session: Session, instance_id: str) -> ExpressionCounts:
    rows = list_expressions(session, instance_id)
    return ExpressionCounts(
        total=len(rows),
        active_count=sum(1 for row in rows if row.status == "active"),
        stale_count=sum(1 for row in rows if row.status == "stale"),
        disabled_count=sum(1 for row in rows if row.status == "disabled"),
    )


def get_expression(session: Session, expression_id: str, instance_id: str) -> Expression | None:
    statement = (
        select(ExpressionRecord)
        .where(ExpressionRecord.id == expression_id)
        .where(ExpressionRecord.instance_id == instance_id)
        .limit(1)
    )
    row = session.exec(statement).first()
    return None if row is None else _expression_from_record(row)


def get_expression_by_pattern(session: Session, instance_id: str, pattern_key: str) -> Expression | None:
    rows = list(
        session.exec(
            select(ExpressionRecord)
            .where(ExpressionRecord.instance_id == instance_id)
            .where(ExpressionRecord.pattern_key == pattern_key)
            .where(ExpressionRecord.status != "disabled")
        ).all()
    )
    if not rows:
        return None
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return _expression_from_record(rows[0])


def create_expression(session: Session, record: ExpressionRecord) -> Expression:
    persist(session, record)
    return _expression_from_record(record)


def update_expression(session: Session, expression_id: str, payload: Expression) -> Expression | None:
    row = session.get(ExpressionRecord, expression_id)
    if row is None:
        return None
    row.summary = payload.summary
    row.content = payload.content
    row.status = payload.status
    row.pattern_key = payload.pattern_key
    row.target_file = payload.target_file
    row.binding_ref = payload.binding_ref
    row.apply_mode = payload.apply_mode
    row.tag_id = payload.tag_id
    row.anchor_selector = payload.anchor_selector
    row.apply_commit = payload.apply_commit
    row.disable_commit = payload.disable_commit
    row.remote_gene_id = payload.remote_gene_id
    row.confidence = payload.confidence
    row.risk = payload.risk
    row.updated_at = payload.updated_at
    persist(session, row)
    return _expression_from_record(row)


def increment_expression_hit(session: Session, expression_id: str, hit_at: int, updated_at: int) -> Expression | None:
    row = session.get(ExpressionRecord, expression_id)
    if row is None:
        return None
    row.hit_count = int(row.hit_count or 0) + 1
    row.last_hit_at = hit_at
    row.updated_at = updated_at
    persist(session, row)
    return _expression_from_record(row)
