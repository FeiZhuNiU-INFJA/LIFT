from __future__ import annotations

from pathlib import Path

from fastapi_service.config import Settings

RUNTIME_STATE_DIR_NAME = "evolution-runtime"


def runtime_root() -> Path:
    base_state = (Settings().openclaw_state_dir or "").strip()
    if base_state:
        return Path(base_state).expanduser().resolve() / RUNTIME_STATE_DIR_NAME
    return Path.home().expanduser().resolve() / ".openclaw" / RUNTIME_STATE_DIR_NAME


def db_path() -> Path:
    return runtime_root() / "evolution-pro.db"


def runtime_state_path() -> Path:
    return runtime_root() / "runtime-state.json"


def default_workspace_root() -> Path:
    env_override = (Settings().openclaw_workspace_root or "").strip()
    if env_override:
        return Path(env_override).expanduser().resolve()
    home_workspace = Path.home() / ".openclaw" / "workspace"
    return home_workspace.expanduser().resolve()
