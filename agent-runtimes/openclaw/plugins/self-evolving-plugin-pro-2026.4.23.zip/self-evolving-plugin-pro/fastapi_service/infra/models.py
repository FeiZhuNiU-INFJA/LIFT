from __future__ import annotations

from sqlalchemy import Index, desc
from sqlmodel import Field, SQLModel


class InstanceRecord(SQLModel, table=True):
    __tablename__ = "instances"
    __table_args__ = (Index("idx_instances_workspace_root_created", "workspace_root", desc("created_at")),)

    id: str = Field(primary_key=True)
    instance_token: str
    display_name: str | None = None
    workspace_root: str | None = Field(default=None, index=True)
    git_root: str | None = None
    baseline_commit: str | None = None
    env_probe_json: str = Field(default="{}")
    onboarding_status: str = Field(default="pending")
    last_workspace_scan_at: int | None = None
    created_at: int = Field(index=True)


class SignalRecord(SQLModel, table=True):
    __tablename__ = "signals"
    __table_args__ = (
        Index("idx_signals_instance_created", "instance_id", desc("created_at")),
        Index("idx_signals_instance_session_created", "instance_id", "session_id", desc("created_at")),
        Index("idx_signals_instance_kind_created", "instance_id", "kind", desc("created_at")),
    )

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    session_id: str = Field(index=True)
    user_id: str
    kind: str = Field(index=True)
    normalized_kind: str = Field(default="user_feedback")
    content: str
    tags_json: str
    trust: float
    source: str = Field(default="plugin")
    source_ref: str | None = None
    raw_payload_json: str = Field(default="{}")
    matched_remote_gene_ids_json: str = Field(default="[]")
    classifier_note: str = Field(default="")
    created_at: int = Field(index=True)


class GeneRecord(SQLModel, table=True):
    __tablename__ = "genes"
    __table_args__ = (
        Index("idx_genes_instance_hit_created", "instance_id", desc("hit_count"), desc("created_at")),
        Index(
            "idx_genes_instance_remote_refresh_created",
            "instance_id",
            "remote_gene_id",
            desc("cache_refreshed_at"),
            desc("created_at"),
        ),
        Index(
            "idx_genes_instance_pattern_refresh_created",
            "instance_id",
            "pattern_key",
            desc("cache_refreshed_at"),
            desc("created_at"),
        ),
        Index("idx_genes_instance_source", "instance_id", "source"),
    )

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    summary: str
    rule_text: str
    pattern_key: str | None = Field(default=None, index=True)
    source: str = Field(default="local", index=True)
    remote_gene_id: str | None = Field(default=None, index=True)
    metadata_json: str = Field(default="{}")
    hit_count: int = Field(default=0, index=True)
    cache_refreshed_at: int | None = Field(default=None, index=True)
    created_at: int = Field(index=True)


class ExpressionRecord(SQLModel, table=True):
    __tablename__ = "expressions"
    __table_args__ = (
        Index("idx_expressions_instance_status_created", "instance_id", "status", desc("created_at")),
        Index("idx_expressions_instance_pattern_created", "instance_id", "pattern_key", desc("created_at")),
        Index("idx_expressions_instance_target_created", "instance_id", "target_file", desc("created_at")),
        Index("idx_expressions_instance_hit_created", "instance_id", desc("hit_count"), desc("created_at")),
    )

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    gene_id: str = Field(index=True)
    summary: str
    content: str
    status: str = Field(index=True)
    model_id: str | None = None
    pattern_key: str | None = Field(default=None, index=True)
    target_file: str | None = Field(default=None, index=True)
    binding_ref: str | None = None
    apply_mode: str = Field(default="runtime_only")
    tag_id: str | None = None
    anchor_selector: str | None = None
    apply_commit: str | None = None
    disable_commit: str | None = None
    remote_gene_id: str | None = None
    hit_count: int = Field(default=0, index=True)
    last_hit_at: int = Field(default=0)
    confidence: float | None = None
    risk: float | None = None
    created_at: int = Field(index=True)
    updated_at: int


class ReviewRecord(SQLModel, table=True):
    __tablename__ = "reviews"
    __table_args__ = (Index("idx_reviews_instance_status_created", "instance_id", "status", desc("created_at")),)

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    since_text: str
    reason_text: str = Field(default="")
    focus_session_id: str = Field(default="", index=True)
    workspace_change_id: str | None = None
    workspace_change_base_kind: str = Field(default="")
    status: str = Field(index=True)
    session_ids_json: str
    matched_expression_ids_json: str
    created_expression_ids_json: str
    updated_expression_ids_json: str = Field(default="[]")
    summary_text: str = Field(default="")
    stats_json: str = Field(default="[]")
    report_markdown: str
    error_text: str
    token_usage_json: str = Field(default="{}")
    created_at: int = Field(index=True)
    updated_at: int


class WorkspaceInventoryRecord(SQLModel, table=True):
    __tablename__ = "workspace_inventory"
    __table_args__ = (Index("idx_workspace_inventory_instance_path", "instance_id", "relative_path", unique=True),)

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    relative_path: str = Field(index=True)
    file_kind: str
    classification: str
    size_bytes: int = Field(default=0)
    scan_at: int


class SnapshotRecord(SQLModel, table=True):
    __tablename__ = "snapshots"
    __table_args__ = (
        Index("idx_snapshots_instance_created", "instance_id", desc("created_at")),
        Index(
            "idx_snapshots_instance_kind_sequence_created", "instance_id", "kind", desc("sequence"), desc("created_at")
        ),
    )

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    kind: str = Field(index=True)
    sequence: int = Field(default=0, index=True)
    storage_kind: str
    workspace_root: str
    git_root: str | None = None
    commit_hash: str = Field(index=True)
    parent_commit: str | None = None
    review_id: str | None = None
    trigger_kind: str = Field(default="")
    summary: str = Field(default="")
    created_at: int = Field(index=True)


class WorkspaceChangeRecord(SQLModel, table=True):
    __tablename__ = "workspace_changes"
    __table_args__ = (
        Index("idx_workspace_changes_instance_created", "instance_id", desc("created_at")),
        Index(
            "idx_workspace_changes_instance_base_head_created",
            "instance_id",
            "base_kind",
            "base_commit",
            "head_commit",
            desc("created_at"),
        ),
    )

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    base_kind: str = Field(index=True)
    storage_kind: str
    base_commit: str = Field(index=True)
    head_commit: str | None = Field(default=None, index=True)
    summary_json: str
    created_at: int = Field(index=True)


class ChangeAttributionRecord(SQLModel, table=True):
    __tablename__ = "change_attributions"
    __table_args__ = (
        Index("idx_change_attributions_change", "workspace_change_id", "created_at"),
        Index("idx_change_attributions_instance_change_created", "instance_id", "workspace_change_id", "created_at"),
    )

    id: str = Field(primary_key=True)
    workspace_change_id: str = Field(index=True)
    instance_id: str = Field(index=True)
    target_type: str
    target_id: str | None = None
    reason_text: str
    confidence: float
    created_at: int = Field(index=True)


class ReviewMutationRecord(SQLModel, table=True):
    __tablename__ = "review_mutations"
    __table_args__ = (
        Index("idx_review_mutations_review_created", "review_id", "created_at"),
        Index("idx_review_mutations_instance_target_created", "instance_id", "target_file", desc("created_at")),
    )

    id: str = Field(primary_key=True)
    review_id: str = Field(index=True)
    instance_id: str = Field(index=True)
    target_type: str
    target_id: str | None = None
    target_label: str | None = None
    description: str
    reason_text: str = Field(default="")
    status: str = Field(default="applied")
    before_text: str | None = None
    after_text: str | None = None
    gene_id: str | None = None
    gene_name: str | None = None
    target_file: str | None = Field(default=None, index=True)
    binding_ref: str | None = None
    created_at: int = Field(index=True)


class WorkspaceChangeEntryRecord(SQLModel, table=True):
    __tablename__ = "workspace_change_entries"
    __table_args__ = (Index("idx_workspace_change_entries_change_created", "workspace_change_id", "created_at"),)

    id: str = Field(primary_key=True)
    workspace_change_id: str = Field(index=True)
    instance_id: str = Field(index=True)
    target_file: str = Field(index=True)
    status: str
    description: str
    before_text: str | None = None
    after_text: str | None = None
    created_at: int = Field(index=True)


class VerificationRunRecord(SQLModel, table=True):
    __tablename__ = "verification_runs"
    __table_args__ = (Index("idx_verification_runs_instance_created", "instance_id", desc("created_at")),)

    id: str = Field(primary_key=True)
    instance_id: str = Field(index=True)
    name: str
    status: str
    summary: str
    details_json: str
    created_at: int = Field(index=True)


class GeneEventOutboxRecord(SQLModel, table=True):
    __tablename__ = "gene_event_outbox"
    __table_args__ = (Index("idx_gene_event_outbox_status_created", "status", "created_at"),)

    event_id: str = Field(primary_key=True)
    event_type: str
    schema_version: int = Field(default=1)
    occurred_at: str
    emitted_at: str
    instance_id: str = Field(index=True)
    session_id: str | None = Field(default=None, index=True)
    review_id: str | None = Field(default=None, index=True)
    producer_json: str = Field(default="{}")
    payload_json: str = Field(default="{}")
    status: str = Field(default="pending", index=True)
    attempt_count: int = Field(default=0)
    last_error: str | None = None
    sent_at: int | None = None
    created_at: int = Field(index=True)
