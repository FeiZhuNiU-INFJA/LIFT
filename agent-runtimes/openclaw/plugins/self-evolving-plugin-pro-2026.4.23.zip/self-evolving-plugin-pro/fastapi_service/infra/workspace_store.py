from __future__ import annotations

import json
from typing import Any

from sqlmodel import Session, select

from fastapi_service.infra.db import persist
from fastapi_service.infra.instances_store import get_instance_by_id
from fastapi_service.infra.models import (
    ChangeAttributionRecord,
    ExpressionRecord,
    InstanceRecord,
    ReviewMutationRecord,
    SnapshotRecord,
    WorkspaceChangeEntryRecord,
    WorkspaceChangeRecord,
    WorkspaceInventoryRecord,
)
from fastapi_service.modules.expressions.models import Expression
from fastapi_service.modules.reviews.models import EnvironmentProbe, ReviewMutation
from fastapi_service.modules.workspace.models import (
    Snapshot,
    WorkspaceChange,
    WorkspaceChangeAttribution,
    WorkspaceChangeEntry,
    WorkspaceChangeSummary,
    WorkspaceInventoryItem,
)


def _review_mutation_from_record(row: ReviewMutationRecord) -> ReviewMutation:
    return ReviewMutation.model_validate(row, from_attributes=True)


def _expression_from_record(row: ExpressionRecord) -> Expression:
    return Expression.model_validate(row, from_attributes=True)


def _snapshot_from_record(row: SnapshotRecord) -> Snapshot:
    return Snapshot.model_validate(row, from_attributes=True)


def _snapshot_record_from_model(snapshot: Snapshot) -> SnapshotRecord:
    return SnapshotRecord.model_validate(snapshot, from_attributes=True)


def _workspace_change_entry_from_record(row: WorkspaceChangeEntryRecord) -> WorkspaceChangeEntry:
    return WorkspaceChangeEntry(
        id=row.id,
        workspace_change_id=row.workspace_change_id,
        instance_id=row.instance_id,
        target_file=row.target_file,
        status=row.status,
        description=row.description,
        before_text=row.before_text,
        after_text=row.after_text,
        created_at=row.created_at,
        activity_label=None,
        activity_visible=None,
        activity_kind=None,
    )


def _workspace_change_entry_record_from_model(entry: WorkspaceChangeEntry) -> WorkspaceChangeEntryRecord:
    return WorkspaceChangeEntryRecord(
        id=entry.id,
        workspace_change_id=entry.workspace_change_id,
        instance_id=entry.instance_id,
        target_file=entry.target_file,
        status=entry.status,
        description=entry.description,
        before_text=entry.before_text,
        after_text=entry.after_text,
        created_at=entry.created_at,
    )


def _change_attribution_from_record(row: ChangeAttributionRecord) -> WorkspaceChangeAttribution:
    return WorkspaceChangeAttribution.model_validate(row, from_attributes=True)


def _change_attribution_record_from_model(item: WorkspaceChangeAttribution) -> ChangeAttributionRecord:
    return ChangeAttributionRecord.model_validate(item, from_attributes=True)


def list_workspace_inventory(session: Session, instance_id: str) -> list[WorkspaceInventoryItem]:
    rows = list(
        session.exec(select(WorkspaceInventoryRecord).where(WorkspaceInventoryRecord.instance_id == instance_id)).all()
    )
    rows.sort(key=lambda row: row.relative_path)
    return [
        WorkspaceInventoryItem(
            relative_path=row.relative_path,
            file_kind=row.file_kind,
            classification=row.classification,
            size_bytes=row.size_bytes,
            scan_at=row.scan_at,
        )
        for row in rows
    ]


def list_file_workspace_changes(
    session: Session, instance_id: str, target_file: str, limit: int = 20
) -> list[WorkspaceChange]:
    all_rows = list(
        session.exec(select(WorkspaceChangeRecord).where(WorkspaceChangeRecord.instance_id == instance_id)).all()
    )
    matched_change_ids = {
        row.workspace_change_id
        for row in session.exec(
            select(WorkspaceChangeEntryRecord).where(WorkspaceChangeEntryRecord.target_file == target_file)
        ).all()
    }
    rows = [row for row in all_rows if row.id in matched_change_ids]
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [WorkspaceChange.from_record(row) for row in rows[:limit]]


def list_file_review_mutations(
    session: Session, instance_id: str, target_file: str, limit: int = 20
) -> list[ReviewMutation]:
    statement = (
        select(ReviewMutationRecord)
        .where(ReviewMutationRecord.instance_id == instance_id)
        .where(ReviewMutationRecord.target_file == target_file)
    )
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [_review_mutation_from_record(row) for row in rows[:limit]]


def list_file_expressions(session: Session, instance_id: str, target_file: str, limit: int = 20) -> list[Expression]:
    statement = (
        select(ExpressionRecord)
        .where(ExpressionRecord.instance_id == instance_id)
        .where(ExpressionRecord.target_file == target_file)
    )
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [_expression_from_record(row) for row in rows[:limit]]


def list_snapshots(session: Session, instance_id: str, kind: str | None = None) -> list[Snapshot]:
    statement = select(SnapshotRecord).where(SnapshotRecord.instance_id == instance_id)
    if kind:
        statement = statement.where(SnapshotRecord.kind == kind)
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: (row.sequence, row.created_at), reverse=True)
    return [_snapshot_from_record(row) for row in rows]


def latest_snapshot(session: Session, instance_id: str, kind: str) -> Snapshot | None:
    rows = list_snapshots(session, instance_id, kind)
    return rows[0] if rows else None


def next_snapshot_sequence(session: Session, instance_id: str, kind: str) -> int:
    rows = list_snapshots(session, instance_id, kind)
    if not rows:
        return 0
    return int(rows[0].sequence or 0) + 1


def create_snapshot(session: Session, payload: Snapshot) -> Snapshot:
    record = _snapshot_record_from_model(payload)
    persist(session, record)
    return _snapshot_from_record(record)


def list_workspace_changes(session: Session, instance_id: str, limit: int = 20) -> list[WorkspaceChange]:
    rows = list(
        session.exec(select(WorkspaceChangeRecord).where(WorkspaceChangeRecord.instance_id == instance_id)).all()
    )
    rows.sort(key=lambda row: row.created_at, reverse=True)
    return [WorkspaceChange.from_record(row) for row in rows[:limit]]


def get_workspace_change(
    session: Session,
    change_id: str,
    instance_id: str | None = None,
) -> WorkspaceChange | None:
    statement = select(WorkspaceChangeRecord).where(WorkspaceChangeRecord.id == change_id)
    if instance_id:
        statement = statement.where(WorkspaceChangeRecord.instance_id == instance_id)
    statement = statement.limit(1)
    row = session.exec(statement).first()
    return None if row is None else WorkspaceChange.from_record(row)


def find_workspace_change(
    session: Session,
    *,
    instance_id: str,
    base_kind: str,
    base_commit: str,
    head_commit: str | None,
    summary: WorkspaceChangeSummary,
) -> WorkspaceChange | None:
    rows = list(
        session.exec(select(WorkspaceChangeRecord).where(WorkspaceChangeRecord.instance_id == instance_id)).all()
    )
    summary_json = json.dumps(summary.model_dump(), ensure_ascii=False)
    matches = [
        row
        for row in rows
        if row.base_kind == base_kind
        and row.base_commit == base_commit
        and row.head_commit == head_commit
        and row.summary_json == summary_json
    ]
    if not matches:
        return None
    matches.sort(key=lambda row: row.created_at, reverse=True)
    return WorkspaceChange.from_record(matches[0])


def create_workspace_change(session: Session, payload: WorkspaceChange) -> WorkspaceChange:
    record = WorkspaceChangeRecord(**payload.to_record())
    persist(session, record)
    return WorkspaceChange.from_record(record)


def create_workspace_change_entries(session: Session, rows: list[WorkspaceChangeEntry]) -> list[WorkspaceChangeEntry]:
    for row in rows:
        session.add(_workspace_change_entry_record_from_model(row))
    session.commit()
    return list_workspace_change_entries(session, rows[0].workspace_change_id) if rows else []


def list_workspace_change_entries(session: Session, change_id: str) -> list[WorkspaceChangeEntry]:
    rows = list(
        session.exec(
            select(WorkspaceChangeEntryRecord).where(WorkspaceChangeEntryRecord.workspace_change_id == change_id)
        ).all()
    )
    rows.sort(key=lambda row: (row.created_at, row.target_file))
    return [_workspace_change_entry_from_record(row) for row in rows]


def list_change_attributions(session: Session, instance_id: str, change_id: str) -> list[WorkspaceChangeAttribution]:
    statement = (
        select(ChangeAttributionRecord)
        .where(ChangeAttributionRecord.instance_id == instance_id)
        .where(ChangeAttributionRecord.workspace_change_id == change_id)
    )
    rows = list(session.exec(statement).all())
    rows.sort(key=lambda row: row.created_at)
    return [_change_attribution_from_record(row) for row in rows]


def replace_change_attributions(
    session: Session,
    change_id: str,
    instance_id: str,
    rows: list[WorkspaceChangeAttribution],
) -> list[WorkspaceChangeAttribution]:
    existing = session.exec(
        select(ChangeAttributionRecord)
        .where(ChangeAttributionRecord.workspace_change_id == change_id)
        .where(ChangeAttributionRecord.instance_id == instance_id)
    ).all()
    for item in existing:
        session.delete(item)
    for row in rows:
        session.add(_change_attribution_record_from_model(row))
    session.commit()
    return list_change_attributions(session, instance_id, change_id)


def get_instance_row(session: Session, instance_id: str) -> InstanceRecord | None:
    return get_instance_by_id(session, instance_id)


def get_instance_env_probe(session: Session, instance_id: str) -> EnvironmentProbe:
    default_payload: dict[str, Any] = {
        "workspace_root": None,
        "git_root": None,
        "baseline_commit": None,
        "status_counts": {},
        "file_registry": [],
        "editable_files": [],
        "binding_candidates": [],
        "rules": {
            "do_not_invent_paths": True,
            "target_file_must_exist_in_workspace": True,
            "prefer_prompt_hook_or_real_workspace_file": True,
            "preserve_user_owned_on_reinit": True,
        },
        "write_policy": {
            "evolvable": "section-edit",
            "user_owned": "append-only",
            "skill_owned": "skill-managed",
            "needs_review": "blocked-until-classified",
            "runtime": "read-only",
        },
    }
    row = get_instance_row(session, instance_id)
    if row is None:
        return EnvironmentProbe.model_validate(default_payload)
    payload = json.loads(row.env_probe_json or "{}")
    if not isinstance(payload, dict):
        payload = {}
    return EnvironmentProbe.model_validate({**default_payload, **payload})
