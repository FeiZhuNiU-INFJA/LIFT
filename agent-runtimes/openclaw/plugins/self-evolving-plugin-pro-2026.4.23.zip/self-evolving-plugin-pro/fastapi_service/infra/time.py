from __future__ import annotations

from datetime import datetime, timezone


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")  # noqa: UP017


def utc_now_unix() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def unix_ts_to_iso(value: int | float) -> str:
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat().replace("+00:00", "Z")  # noqa: UP017
