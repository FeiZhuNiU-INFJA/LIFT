from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from sqlalchemy import Engine, inspect, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from sqlmodel import Session, SQLModel, create_engine

from . import models as _models  # noqa: F401
from .paths import db_path

LEGACY_COLUMN_MIGRATIONS: dict[str, dict[str, str]] = {
    "instances": {
        "workspace_root": "text",
        "git_root": "text",
        "baseline_commit": "text",
        "env_probe_json": "text not null default '{}'",
        "onboarding_status": "text not null default 'pending'",
        "last_workspace_scan_at": "integer",
    },
    "genes": {
        "pattern_key": "text",
        "source": "text not null default 'local'",
        "remote_gene_id": "text",
        "metadata_json": "text not null default '{}'",
        "hit_count": "integer not null default 0",
        "cache_refreshed_at": "integer",
    },
    "signals": {
        "normalized_kind": "text not null default 'user_feedback'",
        "source": "text not null default 'plugin'",
        "source_ref": "text",
        "raw_payload_json": "text not null default '{}'",
        "matched_remote_gene_ids_json": "text not null default '[]'",
        "classifier_note": "text not null default ''",
    },
    "expressions": {
        "pattern_key": "text",
        "target_file": "text",
        "binding_ref": "text",
        "apply_mode": "text not null default 'runtime_only'",
        "tag_id": "text",
        "anchor_selector": "text",
        "apply_commit": "text",
        "disable_commit": "text",
        "remote_gene_id": "text",
        "last_hit_at": "integer not null default 0",
        "updated_at": "integer not null default 0",
        "confidence": "real",
        "risk": "real",
    },
    "reviews": {
        "reason_text": "text not null default ''",
        "focus_session_id": "text not null default ''",
        "workspace_change_id": "text",
        "workspace_change_base_kind": "text not null default ''",
        "updated_expression_ids_json": "text not null default '[]'",
        "summary_text": "text not null default ''",
        "stats_json": "text not null default '[]'",
        "token_usage_json": "text not null default '{}'",
    },
    "review_mutations": {
        "target_file": "text",
        "binding_ref": "text",
    },
    "snapshots": {
        "sequence": "integer not null default 0",
        "parent_commit": "text",
        "review_id": "text",
        "trigger_kind": "text not null default ''",
    },
    "workspace_changes": {
        "head_commit": "text",
    },
    "gene_event_outbox": {
        "schema_version": "integer not null default 1",
        "occurred_at": "text not null default ''",
        "emitted_at": "text not null default ''",
        "session_id": "text",
        "review_id": "text",
        "producer_json": "text not null default '{}'",
        "payload_json": "text not null default '{}'",
        "status": "text not null default 'pending'",
        "attempt_count": "integer not null default 0",
        "last_error": "text",
        "sent_at": "integer",
        "created_at": "integer not null default 0",
    },
}

INDEX_STATEMENTS = [
    "create unique index if not exists idx_workspace_inventory_instance_path on workspace_inventory(instance_id, relative_path)",
    "create index if not exists idx_instances_workspace_root_created on instances(workspace_root, created_at desc)",
    "create index if not exists idx_signals_instance_created on signals(instance_id, created_at desc)",
    "create index if not exists idx_signals_instance_session_created on signals(instance_id, session_id, created_at desc)",
    "create index if not exists idx_signals_instance_kind_created on signals(instance_id, kind, created_at desc)",
    "create index if not exists idx_genes_instance_hit_created on genes(instance_id, hit_count desc, created_at desc)",
    "create index if not exists idx_genes_instance_remote_refresh_created on genes(instance_id, remote_gene_id, cache_refreshed_at desc, created_at desc)",
    "create index if not exists idx_genes_instance_pattern_refresh_created on genes(instance_id, pattern_key, cache_refreshed_at desc, created_at desc)",
    "create index if not exists idx_genes_instance_source on genes(instance_id, source)",
    "create index if not exists idx_expressions_instance_status_created on expressions(instance_id, status, created_at desc)",
    "create index if not exists idx_expressions_instance_pattern_created on expressions(instance_id, pattern_key, created_at desc)",
    "create index if not exists idx_expressions_instance_target_created on expressions(instance_id, target_file, created_at desc)",
    "create index if not exists idx_expressions_instance_hit_created on expressions(instance_id, hit_count desc, created_at desc)",
    "create index if not exists idx_reviews_instance_status_created on reviews(instance_id, status, created_at desc)",
    "create index if not exists idx_snapshots_instance_created on snapshots(instance_id, created_at desc)",
    "create index if not exists idx_snapshots_instance_kind_sequence_created on snapshots(instance_id, kind, sequence desc, created_at desc)",
    "create index if not exists idx_workspace_changes_instance_created on workspace_changes(instance_id, created_at desc)",
    "create index if not exists idx_workspace_changes_instance_base_head_created on workspace_changes(instance_id, base_kind, base_commit, head_commit, created_at desc)",
    "create index if not exists idx_change_attributions_change on change_attributions(workspace_change_id, created_at asc)",
    "create index if not exists idx_change_attributions_instance_change_created on change_attributions(instance_id, workspace_change_id, created_at asc)",
    "create index if not exists idx_review_mutations_review_created on review_mutations(review_id, created_at asc)",
    "create index if not exists idx_review_mutations_instance_target_created on review_mutations(instance_id, target_file, created_at desc)",
    "create index if not exists idx_workspace_change_entries_change_created on workspace_change_entries(workspace_change_id, created_at asc)",
    "create index if not exists idx_verification_runs_instance_created on verification_runs(instance_id, created_at desc)",
    "create index if not exists idx_gene_event_outbox_status_created on gene_event_outbox(status, created_at asc)",
]


def persist(session: Session, record) -> None:
    """Add, commit, and refresh a record in one step."""
    session.add(record)
    session.commit()
    session.refresh(record)


def engine_path(path: Path | None = None) -> Path:
    return path or db_path()


@lru_cache(maxsize=4)
def _cached_engine(path_text: str) -> Engine:
    engine = create_engine(
        f"sqlite:///{path_text}",
        connect_args={"check_same_thread": False},
        poolclass=NullPool,
    )
    _install_sqlite_pragmas(engine)
    return engine


def _install_sqlite_pragmas(engine: Engine) -> None:
    """Make concurrent access from the uvicorn thread pool resilient.

    Without these PRAGMAs, two sessions writing at the same time (e.g. an
    onboarding request that opens an outer session for InstanceRecord and
    synchronously triggers gene-cache INSERTs in a second session) fails
    immediately with ``database is locked`` — SQLite's default
    busy_timeout is 0 and the rollback journal blocks any overlapping
    writer. WAL lets readers proceed during writes and serialises writers
    cleanly; busy_timeout gives the serialised writer up to 30s to get in
    (well beyond any realistic onboarding latency).
    """
    from sqlalchemy import event

    @event.listens_for(engine, "connect")
    def _configure_sqlite_connection(dbapi_connection, _connection_record) -> None:
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.execute("PRAGMA synchronous=NORMAL")
        finally:
            cursor.close()


@lru_cache(maxsize=4)
def _cached_session_factory(path_text: str):
    return sessionmaker(bind=_cached_engine(path_text), class_=Session, expire_on_commit=False)


def create_db_engine(path: Path | None = None) -> Engine:
    return _cached_engine(str(engine_path(path)))


def get_session(path: Path | None = None) -> Session:
    return _cached_session_factory(str(engine_path(path)))()


def ensure_runtime_db() -> None:
    db_file = db_path()
    db_file.parent.mkdir(parents=True, exist_ok=True)
    engine = create_db_engine(db_file)
    SQLModel.metadata.create_all(engine)
    with engine.begin() as connection:
        inspector = inspect(connection)
        for table, columns in LEGACY_COLUMN_MIGRATIONS.items():
            existing_columns = {column["name"] for column in inspector.get_columns(table)}
            for column, definition in columns.items():
                if column in existing_columns:
                    continue
                connection.execute(text(f"alter table {table} add column {column} {definition}"))
                existing_columns.add(column)
        backfill_signal_normalized_kind(connection)
        for statement in INDEX_STATEMENTS:
            connection.execute(text(statement))
    _run_startup_review_cleanup()


def _run_startup_review_cleanup() -> None:
    """Mark zombie running reviews as failed and trim the failed-timer backlog.

    Historically the auto-review timer would retry every 5 minutes on any
    error without advancing its last-run timestamp, producing hundreds of
    `status=failed reason_text=timer` rows per day and occasionally leaving
    a `running` review orphaned when the worker process died. The autoReview
    fix prevents the flood going forward; this cleanup handles the backlog.
    """
    import time

    from fastapi_service.infra.reviews_store import cleanup_stale_reviews

    zombie_cutoff_ts = int(time.time()) - 30 * 60  # running > 30min considered dead
    session = get_session()
    try:
        cleanup_stale_reviews(session, zombie_cutoff_ts=zombie_cutoff_ts, keep_failed=50)
    finally:
        session.close()


def backfill_signal_normalized_kind(connection) -> None:
    connection.execute(
        text(
            """
            update signals
            set normalized_kind = case
              when kind in ('tool_failure', 'correction', 'implicit_correction', 'frustration', 'success_confirmation', 'feature_request', 'preference_signal', 'context_revealed', 'silent_pivot', 'pending', 'user_feedback') then kind
              else 'custom'
            end
            where coalesce(normalized_kind, '') = '' or normalized_kind = 'user_feedback'
            """
        )
    )
