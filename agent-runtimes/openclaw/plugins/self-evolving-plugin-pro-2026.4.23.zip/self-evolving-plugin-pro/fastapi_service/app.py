from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from fastapi_service.api import router
from fastapi_service.infra import ensure_runtime_db
from fastapi_service.modules.instances.service import build_runtime_service
from fastapi_service.modules.verification.service import VerificationService
from fastapi_service.services.exceptions import EntityNotFoundError, ServiceUnavailableError, ValidationError
from fastapi_service.version import __version__


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_runtime_db()
    runtime = build_runtime_service()
    app.state.instance_service = runtime
    app.state.signal_service = runtime.signals
    app.state.gene_service = runtime.genes
    app.state.expression_service = runtime.expressions
    app.state.review_service = runtime.reviews
    app.state.workspace_service = runtime.workspace
    app.state.verification_service = VerificationService()
    runtime.reconcile_existing_instance_baselines()
    yield


def _error_handler(status: int):
    async def handler(request, exc):
        return JSONResponse(status_code=status, content={"detail": str(exc)})

    return handler


app = FastAPI(title="Self-Evolving Plugin Pro", version=__version__, lifespan=lifespan)
app.include_router(router)
app.add_exception_handler(EntityNotFoundError, _error_handler(404))
app.add_exception_handler(ValidationError, _error_handler(400))
app.add_exception_handler(ServiceUnavailableError, _error_handler(503))
