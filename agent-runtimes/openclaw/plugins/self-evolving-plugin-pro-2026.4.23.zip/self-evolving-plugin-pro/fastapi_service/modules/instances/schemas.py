from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from fastapi_service.modules.reviews.schemas import EnvironmentProbeResponse


class InstanceBootstrapRequest(BaseModel):
    instance_id: str
    display_name: str | None = None
    workspace_root: str | None = None


class InstanceOnboardRequest(BaseModel):
    instance_id: str
    display_name: str | None = None
    workspace_root: str | None = None


class RuntimeStatePayload(BaseModel):
    instanceId: str | None = None


class InstanceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    instance_token: str
    display_name: str
    workspace_root: str
    git_root: str | None = None
    baseline_commit: str
    onboarding_status: str
    last_workspace_scan_at: int
    created_at: int
    inventory_count: int
    baseline_storage_kind: str
    environment_probe: EnvironmentProbeResponse
