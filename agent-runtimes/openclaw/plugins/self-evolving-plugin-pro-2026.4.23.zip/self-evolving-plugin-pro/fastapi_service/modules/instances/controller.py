from fastapi import APIRouter

from fastapi_service.api.deps import InstanceServiceDep
from fastapi_service.modules.instances.schemas import InstanceBootstrapRequest, InstanceOnboardRequest, InstanceResponse

router = APIRouter()


@router.post("/instances/bootstrap", response_model=InstanceResponse)
def bootstrap_instance(request: InstanceBootstrapRequest, service: InstanceServiceDep) -> InstanceResponse:
    return InstanceResponse.model_validate(service.bootstrap_instance(request))


@router.post("/instances/onboard", response_model=InstanceResponse)
def onboard_instance(request: InstanceOnboardRequest, service: InstanceServiceDep) -> InstanceResponse:
    return InstanceResponse.model_validate(service.onboard_instance(request))
