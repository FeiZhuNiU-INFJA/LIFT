from __future__ import annotations

import json
import secrets
import threading
from pathlib import Path
from typing import Any

from sqlmodel import select

from fastapi_service.infra.db import ensure_runtime_db, get_session
from fastapi_service.infra.models import InstanceRecord, SnapshotRecord, WorkspaceInventoryRecord
from fastapi_service.infra.paths import default_workspace_root
from fastapi_service.infra.time import utc_now_unix
from fastapi_service.modules.expressions.service import ExpressionService
from fastapi_service.modules.genes.service import GeneService
from fastapi_service.modules.instances.schemas import InstanceBootstrapRequest, InstanceOnboardRequest, InstanceResponse
from fastapi_service.modules.reviews.models import EnvironmentProbe
from fastapi_service.modules.reviews.schemas import EnvironmentProbeResponse
from fastapi_service.modules.reviews.service import ReviewService
from fastapi_service.modules.signals.service import SignalService
from fastapi_service.modules.workspace.service import WorkspaceService
from fastapi_service.services.exceptions import ValidationError
from fastapi_service.services.helpers import ecs_instance_id, new_id, openclaw_version, plugin_version


class InstanceService:
    def __init__(self) -> None:
        self._baseline_reconcile_lock = threading.Lock()
        self._baseline_reconcile_running = False
        self._baseline_reconcile_completed = False
        self.workspace = WorkspaceService(id_factory=self._id, session_factory=get_session)
        self.genes = GeneService(
            id_factory=self._id,
            producer_metadata=self._gene_event_producer_metadata,
            session_factory=get_session,
        )
        self.signals = SignalService(
            id_factory=self._id,
            enqueue_gene_event=self.genes.enqueue_gene_event,
            signal_event_payload=self.genes._signal_event_payload,
            session_factory=get_session,
        )
        self.expressions = ExpressionService(
            id_factory=self._id,
            enqueue_gene_event=self.genes.enqueue_gene_event,
            expression_upsert_event_payload=self.genes._expression_upsert_event_payload,
            expression_state_change_payload=self.genes._expression_state_change_payload,
            expression_hit_event_payload=self.genes._expression_hit_event_payload,
            workspace=self.workspace,
            session_factory=get_session,
        )
        self.reviews = ReviewService(
            id_factory=self._id,
            signals=self.signals,
            genes=self.genes,
            expressions=self.expressions,
            workspace=self.workspace,
            session_factory=get_session,
        )

    def reconcile_existing_instance_baselines(self) -> None:
        with self._baseline_reconcile_lock:
            if self._baseline_reconcile_running or self._baseline_reconcile_completed:
                return
            self._baseline_reconcile_running = True
        completed = False
        try:
            self._sync_existing_instance_baselines()
            completed = True
        finally:
            with self._baseline_reconcile_lock:
                self._baseline_reconcile_running = False
                if completed:
                    self._baseline_reconcile_completed = True

    def _id(self, prefix: str) -> str:
        return new_id(prefix)

    def _plugin_version(self) -> str:
        return plugin_version()

    def _openclaw_version(self) -> str | None:
        return openclaw_version()

    def _ecs_instance_id(self) -> str | None:
        return ecs_instance_id()

    def _gene_event_producer_metadata(self) -> dict[str, Any]:
        return {
            "plugin_id": "self-evolving-plugin-pro",
            "plugin_version": self._plugin_version(),
            "openclaw_version": self._openclaw_version(),
            "ecs_instance_id": self._ecs_instance_id(),
        }

    def _mark_instance_needs_setup(self, instance_id: str) -> None:
        with get_session() as session:
            instance = session.get(InstanceRecord, instance_id)
            if instance is None:
                return
            instance.onboarding_status = "needs_setup"
            session.add(instance)
            session.commit()

    def _sync_existing_instance_baselines(self) -> None:
        with get_session() as session:
            rows = list(session.exec(select(InstanceRecord.id, InstanceRecord.workspace_root)).all())
        rows.sort(key=lambda row: row[0])
        for row in rows:
            instance_id = str(row[0] or "").strip()
            workspace_root_text = str(row[1] or "").strip()
            if not instance_id or not workspace_root_text:
                continue
            self._sync_instance_baseline_state(instance_id, Path(workspace_root_text))

    def _sync_instance_baseline_state(self, instance_id: str, workspace_root: Path) -> None:
        resolved_workspace = workspace_root.expanduser().resolve()
        if not resolved_workspace.exists() or not resolved_workspace.is_dir():
            self._mark_instance_needs_setup(instance_id)
            return
        git_root = self.workspace._workspace_git_root(resolved_workspace)
        if git_root != resolved_workspace:
            self._mark_instance_needs_setup(instance_id)
            return

        current_head = self.workspace._git_current_head(resolved_workspace)
        if not current_head:
            current_head = self.workspace._ensure_initial_workspace_head(resolved_workspace)
        if not current_head:
            self._mark_instance_needs_setup(instance_id)
            return

        latest_baseline = self.workspace._latest_snapshot(instance_id, "baseline")
        baseline_commit = current_head
        if latest_baseline:
            changed_anchor_paths = self.workspace._list_changed_anchor_paths(
                resolved_workspace, latest_baseline.commit_hash
            )
            if changed_anchor_paths:
                sequence = self.workspace._next_snapshot_sequence(instance_id, "baseline")
                baseline_commit = self.workspace._create_review_baseline_commit(resolved_workspace, sequence)
                self.workspace._insert_snapshot_row(
                    instance_id=instance_id,
                    kind="baseline",
                    sequence=sequence,
                    storage_kind="workspace_git",
                    workspace_root=str(resolved_workspace),
                    git_root=str(resolved_workspace),
                    commit_hash=baseline_commit,
                    parent_commit=latest_baseline.commit_hash,
                    review_id=None,
                    trigger_kind="runtime_sync",
                    summary="runtime baseline sync over anchor files",
                    created_at=utc_now_unix(),
                )
            else:
                baseline_commit = latest_baseline.commit_hash
        else:
            self.workspace._insert_snapshot_row(
                instance_id=instance_id,
                kind="baseline",
                sequence=0,
                storage_kind="workspace_git",
                workspace_root=str(resolved_workspace),
                git_root=str(resolved_workspace),
                commit_hash=baseline_commit,
                parent_commit=None,
                review_id=None,
                trigger_kind="runtime_sync",
                summary="runtime baseline sync",
                created_at=utc_now_unix(),
            )

        scan_at = utc_now_unix()
        baseline = self.workspace._ensure_baseline(resolved_workspace)
        inventory = self.workspace._scan_workspace_inventory(resolved_workspace, scan_at)
        env_probe = self.workspace._build_env_probe(instance_id, resolved_workspace, inventory, baseline)

        with get_session() as session:
            instance = session.get(InstanceRecord, instance_id)
            if instance is None:
                return
            instance.workspace_root = str(resolved_workspace)
            instance.git_root = str(resolved_workspace)
            instance.baseline_commit = baseline_commit
            instance.env_probe_json = json.dumps(env_probe.model_dump(), ensure_ascii=False)
            instance.onboarding_status = "ready"
            instance.last_workspace_scan_at = scan_at
            session.add(instance)
            session.commit()

    def bootstrap_instance(self, request: InstanceBootstrapRequest) -> InstanceResponse:
        return self.onboard_instance(
            InstanceOnboardRequest(
                instance_id=request.instance_id,
                display_name=request.display_name,
                workspace_root=request.workspace_root,
            )
        )

    def onboard_instance(self, request: InstanceOnboardRequest) -> InstanceResponse:
        requested_instance_id = request.instance_id.strip()
        workspace_root = Path(request.workspace_root or default_workspace_root()).expanduser().resolve()
        if not workspace_root.exists() or not workspace_root.is_dir():
            raise ValidationError("workspace_root must be an existing directory")
        scan_at = utc_now_unix()
        with get_session() as session:
            existing = session.get(InstanceRecord, requested_instance_id)
            if existing is None:
                existing = session.exec(
                    select(InstanceRecord).where(InstanceRecord.workspace_root == str(workspace_root))
                ).first()
                if existing is not None:
                    fallback_matches = [existing]
                    fallback_matches.sort(key=lambda row: row.created_at, reverse=True)
                    existing = fallback_matches[0]

            instance_id = str(existing.id) if existing else requested_instance_id
            display_name = (request.display_name or instance_id).strip()
            self.genes._ensure_initial_gene_cache(instance_id, session=session)
            inventory = self.workspace._scan_workspace_inventory(workspace_root, scan_at)
            baseline = self.workspace._ensure_baseline(workspace_root)
            env_probe = self.workspace._build_env_probe(instance_id, workspace_root, inventory, baseline)
            token = existing.instance_token if existing else secrets.token_hex(16)
            created_at = int(existing.created_at) if existing else scan_at

            instance = existing or InstanceRecord(
                id=instance_id,
                instance_token=token,
                created_at=created_at,
            )
            instance.display_name = display_name
            instance.workspace_root = str(workspace_root)
            instance.git_root = baseline.git_root
            instance.baseline_commit = baseline.commit_hash
            instance.env_probe_json = json.dumps(env_probe.model_dump(), ensure_ascii=False)
            instance.onboarding_status = "ready"
            instance.last_workspace_scan_at = scan_at
            session.add(instance)

            existing_inventory = session.exec(
                select(WorkspaceInventoryRecord).where(WorkspaceInventoryRecord.instance_id == instance_id)
            ).all()
            for existing_item in existing_inventory:
                session.delete(existing_item)
            session.flush()
            for inventory_item in inventory:
                session.add(
                    WorkspaceInventoryRecord(
                        id=self._id("inv"),
                        instance_id=instance_id,
                        relative_path=inventory_item.relative_path,
                        file_kind=inventory_item.file_kind,
                        classification=inventory_item.classification,
                        size_bytes=inventory_item.size_bytes,
                        scan_at=scan_at,
                    )
                )

            existing_snapshot = session.exec(
                select(SnapshotRecord)
                .where(SnapshotRecord.instance_id == instance_id)
                .where(SnapshotRecord.kind == "baseline")
                .where(SnapshotRecord.commit_hash == baseline.commit_hash)
                .limit(1)
            ).first()
            if existing_snapshot is None:
                session.add(
                    SnapshotRecord(
                        id=self._id("snap"),
                        instance_id=instance_id,
                        kind="baseline",
                        sequence=0,
                        storage_kind=baseline.storage_kind,
                        workspace_root=str(workspace_root),
                        git_root=baseline.git_root,
                        commit_hash=baseline.commit_hash,
                        parent_commit=None,
                        review_id=None,
                        trigger_kind="onboarding",
                        summary=baseline.summary,
                        created_at=scan_at,
                    )
                )

            session.commit()

        return InstanceResponse(
            id=instance_id,
            instance_token=token,
            display_name=display_name,
            workspace_root=str(workspace_root),
            git_root=baseline.git_root,
            baseline_commit=baseline.commit_hash,
            onboarding_status="ready",
            last_workspace_scan_at=scan_at,
            created_at=created_at,
            inventory_count=len(inventory),
            baseline_storage_kind=baseline.storage_kind,
            environment_probe=EnvironmentProbeResponse.model_validate(env_probe),
        )

    def _instance_row(self, instance_id: str):
        return self.workspace._instance_row(instance_id)

    def _instance_env_probe(self, instance_id: str) -> EnvironmentProbe:
        return self.workspace._instance_env_probe(instance_id)


def build_runtime_service() -> InstanceService:
    ensure_runtime_db()
    return InstanceService()


__all__ = ["InstanceService", "build_runtime_service"]
