from __future__ import annotations

from collections.abc import Callable
from contextlib import contextmanager

from sqlmodel import Session

from fastapi_service.infra.db import get_session
from fastapi_service.infra.signals_store import (
    build_signal_record,
)
from fastapi_service.infra.signals_store import (
    create_signal as create_signal_record,
)
from fastapi_service.infra.signals_store import (
    list_sessions as list_session_rows,
)
from fastapi_service.infra.signals_store import (
    list_signals as list_signal_rows,
)
from fastapi_service.infra.signals_store import (
    session_turns as list_session_turn_rows,
)
from fastapi_service.infra.signals_store import (
    signal_counts as signal_count_row,
)
from fastapi_service.infra.time import unix_ts_to_iso, utc_now_unix
from fastapi_service.modules.signals.models import SessionSummary, Signal, SignalCounts, SignalEventPayload
from fastapi_service.modules.signals.schemas import SignalCreateRequest

IdFactory = Callable[[str], str]
SessionFactory = Callable[[], Session]


class SignalService:
    def __init__(
        self,
        *,
        id_factory: IdFactory,
        enqueue_gene_event: Callable[..., object],
        signal_event_payload: Callable[[Signal], SignalEventPayload],
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._session_factory = session_factory or get_session
        self._id = id_factory
        self.enqueue_gene_event = enqueue_gene_event
        self._signal_event_payload = signal_event_payload

    @contextmanager
    def _session_scope(self, session=None):
        if session is not None:
            yield session
        else:
            s = self._session_factory()
            try:
                yield s
            finally:
                s.close()

    def _normalize_signal_kind(self, raw_kind: str | None) -> tuple[str, str]:
        kind = str(raw_kind or "").strip() or "user_feedback"
        normalized = (
            kind
            if kind
            in {
                "tool_failure",
                "correction",
                "implicit_correction",
                "frustration",
                "success_confirmation",
                "feature_request",
                "preference_signal",
                "context_revealed",
                "silent_pivot",
                "pending",
                "user_feedback",
            }
            else "custom"
        )
        return kind, normalized

    def create_signal(self, request: SignalCreateRequest, session: Session | None = None) -> Signal:
        created_at = utc_now_unix()
        kind, normalized_kind = self._normalize_signal_kind(request.kind)
        record = build_signal_record(
            signal_id=self._id("sig"),
            instance_id=request.instance_id,
            session_id=request.session_id,
            user_id=request.user_id,
            kind=kind,
            normalized_kind=normalized_kind,
            content=request.content,
            tags=request.tags,
            trust=request.trust,
            source=str(getattr(request, "source", None) or "plugin"),
            source_ref=str(getattr(request, "source_ref", None) or "").strip() or None,
            raw_payload=getattr(request, "raw_payload", None) or {},
            classifier_note=str(getattr(request, "classifier_note", None) or ""),
            created_at=created_at,
        )
        with self._session_scope(session) as db_session:
            signal = create_signal_record(db_session, record)
        self.enqueue_gene_event(
            event_type="signal_observed",
            instance_id=request.instance_id,
            session_id=request.session_id,
            occurred_at=unix_ts_to_iso(created_at),
            payload=self._signal_event_payload(signal),
        )
        return signal

    def list_signals(
        self,
        instance_id: str,
        limit: int = 20,
        session_id: str | None = None,
        since_seconds: int | None = None,
        session: Session | None = None,
    ) -> list[Signal]:
        with self._session_scope(session) as db_session:
            return list_signal_rows(db_session, instance_id, limit, session_id, since_seconds)

    def signal_counts(
        self, instance_id: str, since_seconds: int | None = None, session: Session | None = None
    ) -> SignalCounts:
        with self._session_scope(session) as db_session:
            return signal_count_row(db_session, instance_id, since_seconds)

    def list_sessions(
        self, instance_id: str, limit: int = 20, since_seconds: int | None = None, session: Session | None = None
    ) -> list[SessionSummary]:
        with self._session_scope(session) as db_session:
            return list_session_rows(db_session, instance_id, limit, since_seconds)

    def session_turns(self, instance_id: str, session_id: str, session: Session | None = None) -> list[Signal]:
        with self._session_scope(session) as db_session:
            return list_session_turn_rows(db_session, instance_id, session_id)
