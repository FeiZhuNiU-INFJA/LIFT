from fastapi import APIRouter, Query

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    ResolvedInstanceIdDep,
    SignalServiceDep,
    VerifiedInstanceIdDep,
    assert_instance_access_session,
)
from fastapi_service.modules.signals.schemas import (
    SessionSummaryResponse,
    SessionTurnsResponse,
    SignalCountsResponse,
    SignalCreateRequest,
    SignalResponse,
)

router = APIRouter()


@router.post("/signals", response_model=SignalResponse)
def create_signal(
    request: SignalCreateRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: SignalServiceDep,
) -> SignalResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return SignalResponse.model_validate(service.create_signal(request, session=session))


@router.get("/signals", response_model=list[SignalResponse])
def list_signals(
    instance_id: ResolvedInstanceIdDep,
    session: DbSessionDep,
    service: SignalServiceDep,
    limit: int = Query(20, ge=1, le=200),
    session_id: str | None = Query(default=None),
) -> list[SignalResponse]:
    rows = service.list_signals(instance_id, limit, session_id, session=session)
    return [SignalResponse.model_validate(row) for row in rows]


@router.get("/signals/counts", response_model=SignalCountsResponse)
def get_signal_counts(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: SignalServiceDep,
) -> SignalCountsResponse:
    return SignalCountsResponse.model_validate(service.signal_counts(instance_id, session=session))


@router.get("/sessions", response_model=list[SessionSummaryResponse])
def list_sessions(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: SignalServiceDep,
    limit: int = Query(20, ge=1, le=200),
) -> list[SessionSummaryResponse]:
    rows = service.list_sessions(instance_id, limit, session=session)
    return [SessionSummaryResponse.model_validate(row) for row in rows]


@router.get("/sessions/{session_id}/turns", response_model=SessionTurnsResponse)
def session_turns(
    session_id: str,
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: SignalServiceDep,
) -> SessionTurnsResponse:
    turns = service.session_turns(instance_id, session_id, session=session)
    return SessionTurnsResponse(
        session_id=session_id,
        turns=[SignalResponse.model_validate(turn) for turn in turns],
    )
