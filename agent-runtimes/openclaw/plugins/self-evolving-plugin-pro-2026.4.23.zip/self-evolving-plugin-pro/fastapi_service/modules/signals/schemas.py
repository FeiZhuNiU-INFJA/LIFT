from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from fastapi_service.modules.signals.models import SessionSummary, Signal, SignalCounts

SignalKind = Literal[
    "tool_failure",
    "correction",
    "implicit_correction",
    "frustration",
    "success_confirmation",
    "feature_request",
    "preference_signal",
    "context_revealed",
    "silent_pivot",
    "pending",
    "user_feedback",
]


class SignalCreateRequest(BaseModel):
    instance_id: str
    session_id: str
    user_id: str
    kind: str
    content: str
    tags: list[str] = Field(default_factory=list)
    trust: float = Field(default=0.5, ge=0.0, le=1.0)
    source: str | None = None
    source_ref: str | None = None
    raw_payload: dict[str, object] = Field(default_factory=dict)
    classifier_note: str | None = None


class SignalResponse(Signal):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class SessionSummaryResponse(SessionSummary):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class SessionTurnsResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    session_id: str
    turns: list[SignalResponse] = Field(default_factory=list)


class SignalCountsResponse(SignalCounts):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
