from __future__ import annotations

import json
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field
from sqlmodel import SQLModel

if TYPE_CHECKING:
    from fastapi_service.infra.models import SignalRecord


class Signal(SQLModel):
    id: str
    instance_id: str
    session_id: str
    user_id: str
    kind: str
    normalized_kind: str
    content: str
    tags: list[str] = Field(default_factory=list)
    trust: float
    source: str
    source_ref: str | None = None
    raw_payload: dict[str, object] = Field(default_factory=dict)
    matched_remote_gene_ids: list[str] = Field(default_factory=list)
    classifier_note: str
    created_at: int

    @classmethod
    def from_record(cls, row: SignalRecord) -> Signal:
        return cls(
            id=row.id,
            instance_id=row.instance_id,
            session_id=row.session_id,
            user_id=row.user_id,
            kind=row.kind,
            normalized_kind=row.normalized_kind,
            content=row.content,
            tags=json.loads(row.tags_json or "[]"),
            trust=row.trust,
            source=row.source,
            source_ref=row.source_ref,
            raw_payload=json.loads(row.raw_payload_json or "{}"),
            matched_remote_gene_ids=json.loads(row.matched_remote_gene_ids_json or "[]"),
            classifier_note=row.classifier_note,
            created_at=row.created_at,
        )


class SignalCounts(SQLModel):
    total: int = 0
    tool_failure_count: int = 0
    correction_count: int = 0
    success_count: int = 0
    frustration_count: int = 0


class SessionSummary(SQLModel):
    session_id: str
    last_seen_at: int
    signal_count: int
    failure_count: int
    correction_count: int
    success_count: int


class SignalEventPayload(BaseModel):
    signal_id: str
    user_id: str
    kind: str
    content: str
    tags: list[str] = Field(default_factory=list)
    trust: float
    source: str
    source_ref: str | None = None
    classifier_note: str = ""
    raw_payload: dict[str, object] = Field(default_factory=dict)
    signal_created_at: str
