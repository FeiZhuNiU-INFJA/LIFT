from __future__ import annotations

import json

from pydantic import BaseModel
from sqlmodel import select

from fastapi_service.infra.db import get_session
from fastapi_service.infra.paths import db_path, runtime_root


class RuntimeReadiness(BaseModel):
    status: str
    plugin_id: str
    runtime_root: str
    runtime_ready: bool
    db_ready: bool
    db_path: str
    db_error: str
    version: str


def runtime_readiness() -> RuntimeReadiness:
    current_runtime_root = runtime_root()
    ready_file = current_runtime_root / "runtime-ready.json"
    runtime_ready = ready_file.exists()
    ready_payload: dict[str, object] = {}
    if runtime_ready:
        try:
            raw_ready = json.loads(ready_file.read_text(encoding="utf8"))
            if isinstance(raw_ready, dict):
                ready_payload = raw_ready
        except Exception:
            ready_payload = {}
    db_ready = False
    db_error = ""
    try:
        with get_session() as session:
            session.exec(select(1)).one()
        db_ready = True
    except Exception as error:
        db_error = str(error)
    return RuntimeReadiness(
        status="ok" if runtime_ready and db_ready else "not_ready",
        plugin_id="self-evolving-plugin-pro",
        runtime_root=str(current_runtime_root),
        runtime_ready=runtime_ready,
        db_ready=db_ready,
        db_path=str(db_path()),
        db_error=db_error,
        version=str(ready_payload.get("version") or ""),
    )
