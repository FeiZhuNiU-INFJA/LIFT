from __future__ import annotations

from pathlib import Path
from typing import Literal

from fastapi import APIRouter
from fastapi.responses import FileResponse
from pydantic import BaseModel

from fastapi_service.modules.health.logic import runtime_readiness

router = APIRouter()


class HealthResponse(BaseModel):
    status: Literal["ok"]


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/ready")
def ready() -> dict[str, object]:
    return runtime_readiness().model_dump()


@router.get("/")
def dashboard_page() -> FileResponse:
    dashboard_path = Path(__file__).resolve().parents[2] / "static" / "index.html"
    return FileResponse(dashboard_path)
