from __future__ import annotations

import json

from sqlmodel import Session

from fastapi_service.infra.models import VerificationRunRecord
from fastapi_service.infra.time import utc_now_unix
from fastapi_service.infra.verification_store import create_verification_run as create_verification_run_record
from fastapi_service.infra.verification_store import list_verification_runs as list_verification_run_records
from fastapi_service.modules.verification.schemas import (
    VerificationRun,
    VerificationRunCreateRequest,
    VerificationRunStatus,
)
from fastapi_service.services.helpers import new_id


class VerificationService:
    def create_verification_run(self, session: Session, request: VerificationRunCreateRequest) -> VerificationRun:
        record = VerificationRunRecord(
            id=new_id("vrun"),
            instance_id=request.instance_id,
            name=request.name,
            status=request.status,
            summary=request.summary,
            details_json=json.dumps(request.details, ensure_ascii=False),
            created_at=utc_now_unix(),
        )
        return create_verification_run_record(session, record)

    def list_verification_runs(self, session: Session, instance_id: str, limit: int) -> list[VerificationRun]:
        return list_verification_run_records(session, instance_id, limit)


__all__ = ["VerificationRunStatus", "VerificationService"]
