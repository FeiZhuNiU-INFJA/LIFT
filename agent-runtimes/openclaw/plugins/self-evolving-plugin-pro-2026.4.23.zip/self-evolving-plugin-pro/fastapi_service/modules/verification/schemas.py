from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from sqlmodel import SQLModel

if TYPE_CHECKING:
    from fastapi_service.infra.models import VerificationRunRecord

VerificationRunStatus = Literal["pending", "running", "passed", "failed"]


class VerificationRunCreateRequest(BaseModel):
    instance_id: str
    name: str
    status: VerificationRunStatus | str
    summary: str
    details: dict[str, Any] = Field(default_factory=dict)


class VerificationRun(SQLModel):
    id: str
    instance_id: str
    name: str
    status: VerificationRunStatus | str
    summary: str
    details: dict[str, Any] = Field(default_factory=dict)
    created_at: int

    @classmethod
    def from_record(cls, row: VerificationRunRecord) -> VerificationRun:
        return cls(
            id=row.id,
            instance_id=row.instance_id,
            name=row.name,
            status=row.status,
            summary=row.summary,
            details=json.loads(row.details_json or "{}"),
            created_at=row.created_at,
        )


class VerificationRunResponse(VerificationRun):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
