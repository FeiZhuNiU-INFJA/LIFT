from fastapi import APIRouter, Query

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    VerificationServiceDep,
    VerifiedInstanceIdDep,
    assert_instance_access_session,
)
from fastapi_service.modules.verification.schemas import (
    VerificationRunCreateRequest,
    VerificationRunResponse,
)

router = APIRouter()


@router.post("/verification-runs", response_model=VerificationRunResponse)
def create_verification_run(
    request: VerificationRunCreateRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: VerificationServiceDep,
) -> VerificationRunResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return VerificationRunResponse.model_validate(service.create_verification_run(session, request))


@router.get("/verification-runs", response_model=list[VerificationRunResponse])
def list_verification_runs(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: VerificationServiceDep,
    limit: int = Query(10, ge=1, le=100),
) -> list[VerificationRunResponse]:
    rows = service.list_verification_runs(session, instance_id, limit)
    return [VerificationRunResponse.model_validate(row) for row in rows]
