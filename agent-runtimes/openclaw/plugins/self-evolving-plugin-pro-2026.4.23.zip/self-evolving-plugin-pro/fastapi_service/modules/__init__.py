# Modular MVC packages for FastAPI domains.
