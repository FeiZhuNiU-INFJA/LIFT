from __future__ import annotations

from pydantic import BaseModel, Field
from sqlmodel import SQLModel


class Expression(SQLModel):
    id: str
    instance_id: str
    gene_id: str
    summary: str
    content: str
    status: str
    model_id: str | None = None
    pattern_key: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    apply_mode: str
    tag_id: str | None = None
    anchor_selector: str | None = None
    apply_commit: str | None = None
    disable_commit: str | None = None
    remote_gene_id: str | None = None
    hit_count: int
    last_hit_at: int
    confidence: float | None = None
    risk: float | None = None
    created_at: int
    updated_at: int


class ExpressionCounts(SQLModel):
    total: int = 0
    active_count: int = 0
    stale_count: int = 0
    disabled_count: int = 0


class ExpressionEventSnapshot(BaseModel):
    expression_id: str
    summary: str
    content: str
    status: str
    pattern_key: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    apply_mode: str
    created_at: str
    updated_at: str


class ExpressionUpsertEventPayload(BaseModel):
    operation: str
    signal_ids: list[str] = Field(default_factory=list)
    remote_gene_id: str
    expression: ExpressionEventSnapshot


class ExpressionStateChangeEventPayload(BaseModel):
    expression_id: str
    remote_gene_id: str | None = None
    from_status: str
    to_status: str
    target_file: str | None = None
    binding_ref: str | None = None
    apply_mode: str | None = None
    apply_commit: str | None = None
    disable_commit: str | None = None
    changed_at: str


class ExpressionHitEventPayload(BaseModel):
    expression_id: str
    remote_gene_id: str | None = None
    hit_source: str | None = None
    observed_at: str
