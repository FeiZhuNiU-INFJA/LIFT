from __future__ import annotations

import re
from collections.abc import Callable
from contextlib import contextmanager
from html import escape as html_escape
from pathlib import Path

from sqlmodel import Session

from fastapi_service.config import Settings
from fastapi_service.infra.db import get_session
from fastapi_service.infra.expressions_store import (
    create_expression as create_expression_record,
)
from fastapi_service.infra.expressions_store import (
    expression_counts as expression_count_row,
)
from fastapi_service.infra.expressions_store import (
    get_expression,
    get_expression_by_pattern,
    increment_expression_hit,
)
from fastapi_service.infra.expressions_store import (
    list_expressions as list_expression_rows,
)
from fastapi_service.infra.expressions_store import (
    update_expression as update_expression_record,
)
from fastapi_service.infra.genes_store import get_gene_by_id, get_gene_by_remote_id
from fastapi_service.infra.models import ExpressionRecord
from fastapi_service.infra.time import unix_ts_to_iso, utc_now_unix
from fastapi_service.modules.expressions.models import (
    Expression,
    ExpressionCounts,
    ExpressionHitEventPayload,
    ExpressionStateChangeEventPayload,
    ExpressionUpsertEventPayload,
)
from fastapi_service.modules.expressions.schemas import (
    ExpressionCreateRequest,
    ExpressionHitRequest,
    ExpressionUpdateRequest,
)
from fastapi_service.services.exceptions import EntityNotFoundError, ValidationError

IdFactory = Callable[[str], str]
SessionFactory = Callable[[], Session]


class ExpressionService:
    def __init__(
        self,
        *,
        id_factory: IdFactory,
        enqueue_gene_event: Callable[..., object],
        expression_upsert_event_payload: Callable[..., ExpressionUpsertEventPayload | None],
        expression_state_change_payload: Callable[[Expression, Expression], ExpressionStateChangeEventPayload],
        expression_hit_event_payload: Callable[[Expression, ExpressionHitRequest], ExpressionHitEventPayload],
        workspace,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._id = id_factory
        self.enqueue_gene_event = enqueue_gene_event
        self._expression_upsert_event_payload = expression_upsert_event_payload
        self._expression_state_change_payload = expression_state_change_payload
        self._expression_hit_event_payload = expression_hit_event_payload
        self.workspace = workspace
        self._session_factory = session_factory or get_session

    @contextmanager
    def _session_scope(self, session=None):
        if session is not None:
            yield session
        else:
            s = self._session_factory()
            try:
                yield s
            finally:
                s.close()

    def list_expressions(
        self,
        instance_id: str,
        status: str | None = None,
        model_id: str | None = None,
        session: Session | None = None,
    ) -> list[Expression]:
        with self._session_scope(session) as db_session:
            return list_expression_rows(db_session, instance_id, status, model_id)

    def expression_counts(self, instance_id: str, session: Session | None = None) -> ExpressionCounts:
        with self._session_scope(session) as db_session:
            return expression_count_row(db_session, instance_id)

    def create_expression(self, request: ExpressionCreateRequest, session: Session | None = None) -> Expression:
        with self._session_scope(session) as db_session:
            pattern_key = (request.pattern_key or "").strip() or None
            gene_id = str(request.gene_id or "").strip()
            remote_gene_id = str(request.remote_gene_id or "").strip()
            gene = None
            if gene_id:
                gene = get_gene_by_id(db_session, gene_id, request.instance_id)
            elif remote_gene_id:
                gene = get_gene_by_remote_id(db_session, request.instance_id, remote_gene_id)
                gene_id = str(gene.id) if gene else ""
            else:
                raise ValidationError("gene_id or remote_gene_id is required")
            if not gene:
                raise EntityNotFoundError("gene not found")
            if pattern_key:
                existing = get_expression_by_pattern(db_session, request.instance_id, pattern_key)
                if existing:
                    return existing
            now = utc_now_unix()
            expression_id = self._id("expr")
            target_file = self._normalize_target_file(request.instance_id, request.target_file)
            binding_ref = str(request.binding_ref or "").strip() or None
            apply_meta = self._expression_apply_metadata(
                expression_id=expression_id,
                gene_row=gene,
                target_file=target_file,
                binding_ref=binding_ref,
            )
            requested_status = request.status or "disabled"
            effective_status = self._auto_enable_status(requested_status, request.confidence, request.risk)
            record = ExpressionRecord(
                id=expression_id,
                instance_id=request.instance_id,
                gene_id=gene_id,
                summary=request.summary,
                content=request.content,
                status=effective_status,
                model_id=request.model_id,
                pattern_key=pattern_key,
                target_file=target_file,
                binding_ref=binding_ref,
                apply_mode=apply_meta.apply_mode,
                tag_id=None,
                anchor_selector=apply_meta.anchor_selector,
                apply_commit=apply_meta.apply_commit,
                disable_commit=apply_meta.disable_commit,
                remote_gene_id=apply_meta.remote_gene_id,
                hit_count=0,
                last_hit_at=0,
                confidence=request.confidence,
                risk=request.risk,
                created_at=now,
                updated_at=now,
            )
            expression = create_expression_record(db_session, record)
            # If the expression was created active (either explicitly or by
            # auto-enable) and is workspace_bound, we must write the tagged
            # block into the target file now — otherwise DB status is
            # "active" but the prompt file never receives the injection.
            # update_expression already does this for state transitions; for
            # first-time active creates we synthesize a disabled "previous"
            # so _sync_workspace_bound_expression treats it as an enable.
            if expression.status == "active" and expression.apply_mode == "workspace_bound":
                synthetic_previous = expression.model_copy(
                    update={"status": "disabled", "apply_commit": None, "disable_commit": None}
                )
                apply_commit, disable_commit = self._sync_workspace_bound_expression(
                    instance_id=request.instance_id,
                    previous=synthetic_previous,
                    payload=expression,
                )
                if apply_commit != expression.apply_commit or disable_commit != expression.disable_commit:
                    expression.apply_commit = apply_commit
                    expression.disable_commit = disable_commit
                    updated = update_expression_record(db_session, expression_id, expression)
                    if updated is not None:
                        expression = updated
        upsert_payload = self._expression_upsert_event_payload(
            operation="create",
            expression=expression,
            signal_ids=request.signal_ids,
        )
        if upsert_payload:
            self.enqueue_gene_event(
                event_type="expression_upserted",
                instance_id=request.instance_id,
                review_id=str(request.review_id or "").strip() or None,
                occurred_at=unix_ts_to_iso(expression.updated_at),
                payload=upsert_payload,
            )
        return expression

    def update_expression(
        self,
        expression_id: str,
        request: ExpressionUpdateRequest,
        session: Session | None = None,
    ) -> Expression:
        with self._session_scope(session) as db_session:
            row = get_expression(db_session, expression_id, request.instance_id)
            if not row:
                raise EntityNotFoundError("expression not found")
            summary = request.summary if request.summary is not None else row.summary
            content = request.content if request.content is not None else row.content
            status = request.status if request.status is not None else row.status
            pattern_key = request.pattern_key if request.pattern_key is not None else row.pattern_key
            target_file = (
                self._normalize_target_file(request.instance_id, request.target_file)
                if request.target_file is not None
                else row.target_file
            )
            binding_ref = request.binding_ref if request.binding_ref is not None else row.binding_ref
            gene_row = get_gene_by_id(db_session, row.gene_id, request.instance_id)
            apply_meta = self._expression_apply_metadata(
                expression_id=expression_id,
                gene_row=gene_row,
                target_file=target_file,
                binding_ref=binding_ref,
                existing=row,
            )
            payload = Expression(
                id=expression_id,
                instance_id=request.instance_id,
                gene_id=row.gene_id,
                summary=summary,
                content=content,
                status=status,
                model_id=row.model_id,
                pattern_key=pattern_key,
                target_file=target_file,
                binding_ref=binding_ref,
                apply_mode=apply_meta.apply_mode,
                tag_id=None,
                anchor_selector=apply_meta.anchor_selector,
                apply_commit=apply_meta.apply_commit,
                disable_commit=apply_meta.disable_commit,
                remote_gene_id=apply_meta.remote_gene_id,
                hit_count=row.hit_count,
                last_hit_at=row.last_hit_at,
                confidence=row.confidence,
                risk=row.risk,
                created_at=row.created_at,
                updated_at=utc_now_unix(),
            )
            if row.apply_mode == "workspace_bound" or payload.apply_mode == "workspace_bound":
                apply_commit, disable_commit = self._sync_workspace_bound_expression(
                    instance_id=request.instance_id,
                    previous=row,
                    payload=payload,
                )
                payload.apply_commit = apply_commit
                payload.disable_commit = disable_commit
            previous_status = row.status
            updated_payload = update_expression_record(db_session, expression_id, payload)
        if updated_payload is None:
            raise EntityNotFoundError("expression not found")
        upsert_payload = self._expression_upsert_event_payload(
            operation="update",
            expression=updated_payload,
            signal_ids=request.signal_ids,
        )
        if upsert_payload:
            self.enqueue_gene_event(
                event_type="expression_upserted",
                instance_id=request.instance_id,
                review_id=str(request.review_id or "").strip() or None,
                occurred_at=unix_ts_to_iso(updated_payload.updated_at),
                payload=upsert_payload,
            )
        if previous_status != updated_payload.status:
            self.enqueue_gene_event(
                event_type="expression_state_changed",
                instance_id=request.instance_id,
                occurred_at=unix_ts_to_iso(updated_payload.updated_at),
                payload=self._expression_state_change_payload(row, updated_payload),
            )
        return updated_payload

    def log_expression_hit(self, request: ExpressionHitRequest, session: Session | None = None) -> Expression:
        if not request.expression_id:
            raise ValidationError("expression_id is required")
        with self._session_scope(session) as db_session:
            row = get_expression(db_session, request.expression_id, request.instance_id)
            if not row:
                raise EntityNotFoundError("expression not found")
            now = utc_now_unix()
            updated_payload = increment_expression_hit(
                db_session,
                request.expression_id,
                now,
                now,
            )
        if updated_payload is None:
            raise EntityNotFoundError("expression not found")
        self.enqueue_gene_event(
            event_type="expression_hit_observed",
            instance_id=request.instance_id,
            session_id=str(request.session_id or "").strip() or None,
            occurred_at=unix_ts_to_iso(updated_payload.last_hit_at),
            payload=self._expression_hit_event_payload(updated_payload, request),
        )
        return updated_payload

    def _get_expression_row(
        self, instance_id: str, expression_id: str, session: Session | None = None
    ) -> Expression | None:
        with self._session_scope(session) as db_session:
            return get_expression(db_session, expression_id, instance_id)

    def _instance_workspace_root(self, instance_id: str) -> Path | None:
        return self.workspace._instance_workspace_root(instance_id)

    def _auto_enable_status(self, requested_status: str, confidence: float | None, risk: float | None) -> str:
        """Promote a freshly created expression to active when confidence is
        high and risk is low. Only applies if the caller asked for the default
        disabled status; explicit non-disabled requests are respected as-is.
        Requires both scores to be present — a half-scored expression stays
        gated behind manual /learn enable.
        """
        if str(requested_status or "").lower() != "disabled":
            return requested_status
        if confidence is None or risk is None:
            return requested_status
        settings = Settings()
        if (
            confidence >= settings.openclaw_evolution_expression_auto_enable_confidence
            and risk <= settings.openclaw_evolution_expression_auto_enable_risk
        ):
            return "active"
        return requested_status

    def _normalize_target_file(self, instance_id: str, target_file: str | None) -> str | None:
        raw = str(target_file or "").strip()
        if not raw:
            return None
        workspace_root = self._instance_workspace_root(instance_id)
        if not workspace_root:
            return None
        candidate = Path(raw)
        if candidate.is_absolute():
            try:
                resolved = candidate.expanduser().resolve()
                relative = resolved.relative_to(workspace_root)
            except Exception:
                return None
            return relative.as_posix() if resolved.exists() and resolved.is_file() else None
        resolved = (workspace_root / candidate).resolve()
        try:
            resolved.relative_to(workspace_root)
        except Exception:
            return None
        return candidate.as_posix() if resolved.exists() and resolved.is_file() else None

    def _expression_apply_metadata(
        self,
        *,
        expression_id: str,
        gene_row,
        target_file: str | None,
        binding_ref: str | None,
        existing: Expression | None = None,
    ) -> Expression:
        normalized_binding = str(binding_ref or "").strip() or None
        normalized_target = str(target_file or "").strip() or None
        existing_payload = existing or Expression(
            id=expression_id,
            instance_id="",
            gene_id="",
            summary="",
            content="",
            status="disabled",
            apply_mode="runtime_only",
            hit_count=0,
            last_hit_at=0,
            created_at=0,
            updated_at=0,
        )
        # Workspace file patching is gated by a config flag. When disabled
        # (default), every expression is runtime_only regardless of the
        # target_file the reviewer picked — the rule still reaches the LLM
        # via the before_prompt_build hook (listExpressions("active") ->
        # buildExpressionXml), so behavior is preserved; we just don't
        # write to files on disk. See config.Settings docstring for why.
        workspace_patch_enabled = Settings().openclaw_evolution_expression_workspace_patch_enabled
        workspace_bound = bool(
            workspace_patch_enabled and normalized_target and self.workspace._is_review_anchor_path(normalized_target)
        )
        return Expression(
            id=expression_id,
            instance_id=existing_payload.instance_id,
            gene_id=existing_payload.gene_id,
            summary=existing_payload.summary,
            content=existing_payload.content,
            status=existing_payload.status,
            model_id=existing_payload.model_id,
            pattern_key=existing_payload.pattern_key,
            target_file=normalized_target,
            binding_ref=normalized_binding,
            apply_mode="workspace_bound" if workspace_bound else "runtime_only",
            tag_id=None,
            anchor_selector=normalized_binding or normalized_target or existing_payload.anchor_selector,
            apply_commit=existing_payload.apply_commit,
            disable_commit=existing_payload.disable_commit,
            remote_gene_id=str(
                (gene_row.remote_gene_id if gene_row else "") or existing_payload.remote_gene_id or ""
            ).strip()
            or None,
            hit_count=existing_payload.hit_count,
            last_hit_at=existing_payload.last_hit_at,
            created_at=existing_payload.created_at,
            updated_at=existing_payload.updated_at,
        )

    def _expression_tag_pattern(self, expression_id: str) -> re.Pattern[str]:
        return re.compile(
            rf"\n?<openclaw-expression\b[^>]*\bid=\"{re.escape(expression_id)}\"[^>]*>.*?</openclaw-expression>\n?",
            re.DOTALL,
        )

    def _render_expression_tag_block(self, payload: Expression) -> str:
        attrs = [
            ("id", payload.id),
            ("remote_gene_id", payload.remote_gene_id or ""),
            ("binding_ref", payload.binding_ref or ""),
            ("target_file", payload.target_file or ""),
            ("pattern_key", payload.pattern_key or ""),
        ]
        attr_text = " ".join(f'{name}="{html_escape(value, quote=True)}"' for name, value in attrs if value)
        summary = payload.summary.strip()
        content = payload.content.rstrip()
        body_lines: list[str] = []
        if summary:
            body_lines.append(f"summary: {summary}")
        if content:
            if body_lines:
                body_lines.append("")
            body_lines.append(content)
        body = "\n".join(body_lines).strip("\n")
        if body:
            return f"<openclaw-expression {attr_text}>\n{body}\n</openclaw-expression>\n"
        return f"<openclaw-expression {attr_text}></openclaw-expression>\n"

    def _remove_expression_tag_block(self, text: str, expression_id: str) -> tuple[str, bool]:
        pattern = self._expression_tag_pattern(expression_id)
        updated, count = pattern.subn("\n", text)
        updated = re.sub(r"\n{3,}", "\n\n", updated).strip("\n")
        if updated:
            updated += "\n"
        return updated, count > 0

    def _upsert_expression_tag_block(self, text: str, payload: Expression) -> tuple[str, bool]:
        block = self._render_expression_tag_block(payload)
        pattern = self._expression_tag_pattern(payload.id)
        if pattern.search(text):
            updated = pattern.sub(block, text, count=1)
            return updated, updated != text
        base = text.rstrip("\n")
        if base:
            return f"{base}\n\n{block}", True
        return block, True

    def _sync_workspace_bound_expression(
        self,
        *,
        instance_id: str,
        previous: Expression,
        payload: Expression,
    ) -> tuple[str | None, str | None]:
        workspace_root = self._instance_workspace_root(instance_id)
        if not workspace_root:
            raise EntityNotFoundError("workspace root not found")

        previous_target = str(previous.target_file or "").strip() or None
        next_target = str(payload.target_file or "").strip() or None
        previous_workspace_bound = previous.apply_mode == "workspace_bound" and bool(previous_target)
        next_workspace_bound = payload.apply_mode == "workspace_bound" and bool(next_target)
        previous_active = previous.status == "active"
        next_active = payload.status == "active"

        # The patch flag gates *writes* (creating/updating a tag block in a
        # workspace file). *Removals* always run so we can clean up legacy
        # tag blocks that were written before the flag existed — otherwise
        # disabling an old workspace_bound row would silently leave stale
        # rules in AGENTS.md et al.
        patch_writes_enabled = Settings().openclaw_evolution_expression_workspace_patch_enabled

        touched_paths: list[str] = []

        if previous_workspace_bound and previous_active and previous_target:
            previous_path = workspace_root / previous_target
            previous_text = previous_path.read_text(encoding="utf8", errors="replace") if previous_path.exists() else ""
            updated_text, changed = self._remove_expression_tag_block(previous_text, previous.id)
            if changed:
                previous_path.write_text(updated_text, encoding="utf8")
                touched_paths.append(previous_target)

        if patch_writes_enabled and next_workspace_bound and next_active and next_target:
            next_path = workspace_root / next_target
            current_text = next_path.read_text(encoding="utf8", errors="replace") if next_path.exists() else ""
            updated_text, changed = self._upsert_expression_tag_block(current_text, payload)
            if changed:
                next_path.write_text(updated_text, encoding="utf8")
                touched_paths.append(next_target)

        commit_hash: str | None = None
        if touched_paths:
            action = "update"
            if next_active and not previous_active:
                action = "enable"
            elif previous_active and not next_active:
                action = "disable"
            commit_hash = self.workspace._commit_selected_workspace_paths(
                workspace_root,
                touched_paths,
                f"openclaw {action} expression {payload.id}",
            )

        apply_commit = payload.apply_commit
        disable_commit = payload.disable_commit
        if next_active and next_workspace_bound and commit_hash:
            apply_commit = commit_hash
        if previous_active and not next_active and previous_workspace_bound and commit_hash:
            disable_commit = commit_hash
        return apply_commit, disable_commit
