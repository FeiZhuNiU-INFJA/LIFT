from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from fastapi_service.modules.expressions.models import Expression, ExpressionCounts


class ExpressionCreateRequest(BaseModel):
    instance_id: str
    gene_id: str | None = None
    remote_gene_id: str | None = None
    summary: str
    content: str
    status: str = "disabled"
    model_id: str | None = None
    pattern_key: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    signal_ids: list[str] = Field(default_factory=list)
    review_id: str | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    risk: float | None = Field(default=None, ge=0.0, le=1.0)


class ExpressionUpdateRequest(BaseModel):
    instance_id: str
    status: str | None = None
    summary: str | None = None
    content: str | None = None
    pattern_key: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    signal_ids: list[str] = Field(default_factory=list)
    review_id: str | None = None


class ExpressionHitRequest(BaseModel):
    instance_id: str
    expression_id: str
    session_id: str | None = None
    hit_source: str | None = None


class ExpressionResponse(Expression):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class ExpressionCountsResponse(ExpressionCounts):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
