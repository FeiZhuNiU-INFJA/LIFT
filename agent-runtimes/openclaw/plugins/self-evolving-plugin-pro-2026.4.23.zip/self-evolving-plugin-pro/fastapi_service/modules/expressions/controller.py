from fastapi import APIRouter, Query

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    ExpressionServiceDep,
    VerifiedInstanceIdDep,
    assert_instance_access_session,
)
from fastapi_service.modules.expressions.schemas import (
    ExpressionCreateRequest,
    ExpressionHitRequest,
    ExpressionResponse,
    ExpressionUpdateRequest,
)

router = APIRouter()


@router.get("/expressions", response_model=list[ExpressionResponse])
def list_expressions(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: ExpressionServiceDep,
    status: str | None = Query(default=None),
    model_id: str | None = Query(default=None),
) -> list[ExpressionResponse]:
    rows = service.list_expressions(instance_id, status, model_id, session=session)
    return [ExpressionResponse.model_validate(row) for row in rows]


@router.post("/expressions", response_model=ExpressionResponse)
def create_expression(
    request: ExpressionCreateRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ExpressionServiceDep,
) -> ExpressionResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ExpressionResponse.model_validate(service.create_expression(request, session=session))


@router.patch("/expressions/{expression_id}", response_model=ExpressionResponse)
def update_expression(
    expression_id: str,
    request: ExpressionUpdateRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ExpressionServiceDep,
) -> ExpressionResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ExpressionResponse.model_validate(service.update_expression(expression_id, request, session=session))


@router.post("/expressions/activate-log", response_model=ExpressionResponse)
def activate_log(
    request: ExpressionHitRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ExpressionServiceDep,
) -> ExpressionResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ExpressionResponse.model_validate(service.log_expression_hit(request, session=session))
