from fastapi import APIRouter, Query

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    ResolvedInstanceIdDep,
    ReviewServiceDep,
    assert_instance_access_session,
)
from fastapi_service.modules.reviews.schemas import (
    DashboardSummaryResponse,
    ReviewCompleteRequest,
    ReviewFailRequest,
    ReviewPrepareRequest,
    ReviewResponse,
    ReviewTokenUsageRequest,
    ReviewWorksetResponse,
)

router = APIRouter()


@router.post("/reviews/prepare", response_model=ReviewResponse)
def prepare_review(
    request: ReviewPrepareRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ReviewResponse.model_validate(service.prepare_review(request, session=session))


@router.get("/reviews/{review_id}/workset", response_model=ReviewWorksetResponse)
def review_workset(
    review_id: str,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewWorksetResponse:
    review = service.get_review(review_id, session=session)
    assert_instance_access_session(session, headers, review.instance_id)
    return ReviewWorksetResponse.model_validate(service.review_workset(review_id, session=session))


@router.post("/reviews/{review_id}/complete", response_model=ReviewResponse)
def complete_review(
    review_id: str,
    request: ReviewCompleteRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ReviewResponse.model_validate(service.complete_review(review_id, request, session=session))


@router.post("/reviews/{review_id}/fail", response_model=ReviewResponse)
def fail_review(
    review_id: str,
    request: ReviewFailRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ReviewResponse.model_validate(service.fail_review(review_id, request, session=session))


@router.post("/reviews/{review_id}/token-usage", response_model=ReviewResponse)
def update_review_token_usage(
    review_id: str,
    request: ReviewTokenUsageRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return ReviewResponse.model_validate(service.update_token_usage(review_id, request, session=session))


@router.get("/reviews/{review_id}", response_model=ReviewResponse)
def get_review(
    review_id: str,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> ReviewResponse:
    review = service.get_review(review_id, session=session)
    assert_instance_access_session(session, headers, review.instance_id)
    return ReviewResponse.model_validate(review)


@router.get("/reviews", response_model=list[ReviewResponse])
def list_reviews(
    instance_id: ResolvedInstanceIdDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
    limit: int = Query(10, ge=1, le=100),
    status: str | None = Query(default=None),
) -> list[ReviewResponse]:
    rows = service.list_reviews(instance_id, limit, status, session=session)
    return [ReviewResponse.model_validate(row) for row in rows]


@router.get("/dashboard/summary", response_model=DashboardSummaryResponse)
def dashboard_summary(
    instance_id: ResolvedInstanceIdDep,
    session: DbSessionDep,
    service: ReviewServiceDep,
) -> DashboardSummaryResponse:
    return DashboardSummaryResponse.model_validate(service.dashboard_summary(instance_id, session=session))
