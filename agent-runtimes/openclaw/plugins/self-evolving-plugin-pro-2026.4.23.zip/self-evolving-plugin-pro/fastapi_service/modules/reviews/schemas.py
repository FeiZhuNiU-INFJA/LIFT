from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from fastapi_service.modules.genes.models import ReviewGeneView
from fastapi_service.modules.reviews.models import (
    DashboardSummary,
    EnvironmentProbe,
    EnvironmentProbeFile,
    EnvironmentProbeRuleSet,
    EnvironmentProbeWritePolicy,
    ExpressionGenerationCase,
    ExpressionGenerationContext,
    ExpressionGenerationTargetCandidate,
    GeneLookupPolicy,
    GlobalView,
    Review,
    ReviewBindingCandidate,
    ReviewMutation,
    ReviewWorkset,
)

ReviewReason = Literal["timer", "session_start", "manual"]
ReviewStatus = Literal["running", "completed", "failed"]


class ReviewPrepareRequest(BaseModel):
    instance_id: str
    since: str = "24h"
    limit: int = Field(default=20, ge=1, le=100)
    reason: ReviewReason | str | None = None
    focus_session_id: str | None = None


class ReviewGeneMatchItem(BaseModel):
    signal_id: str
    remote_gene_ids: list[str] = Field(default_factory=list)


class ReviewMutationItem(BaseModel):
    target_type: str
    target_id: str | None = None
    target_label: str | None = None
    description: str
    reason_text: str | None = None
    status: str = "applied"
    before_text: str | None = None
    after_text: str | None = None
    gene_id: str | None = None
    gene_name: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None


class ReviewCompleteRequest(BaseModel):
    instance_id: str
    matched_expression_ids: list[str] = Field(default_factory=list)
    created_expression_ids: list[str] = Field(default_factory=list)
    updated_expression_ids: list[str] = Field(default_factory=list)
    report_markdown: str = ""
    summary_text: str | None = None
    stats: list[dict[str, Any]] = Field(default_factory=list)
    mutations: list[ReviewMutationItem] = Field(default_factory=list)
    matched_genes: list[ReviewGeneMatchItem] = Field(default_factory=list)
    token_usage: dict[str, Any] = Field(default_factory=dict)


class ReviewTokenUsageRequest(BaseModel):
    instance_id: str
    token_usage: dict[str, Any] = Field(default_factory=dict)


class ReviewFailRequest(BaseModel):
    instance_id: str
    error: str


class ReviewMutationResponse(ReviewMutation):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class ReviewResponse(Review):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class GeneLookupPolicyResponse(GeneLookupPolicy):
    model_config = ConfigDict(from_attributes=True)


class ReviewGeneResponse(ReviewGeneView):
    model_config = ConfigDict(from_attributes=True)


class ReviewBindingCandidateResponse(ReviewBindingCandidate):
    model_config = ConfigDict(from_attributes=True)


class ExpressionGenerationCaseResponse(ExpressionGenerationCase):
    model_config = ConfigDict(from_attributes=True)


class ExpressionGenerationTargetCandidateResponse(ExpressionGenerationTargetCandidate):
    model_config = ConfigDict(from_attributes=True)


class ExpressionGenerationContextResponse(ExpressionGenerationContext):
    model_config = ConfigDict(from_attributes=True)


class EnvironmentProbeRuleSetResponse(EnvironmentProbeRuleSet):
    model_config = ConfigDict(from_attributes=True)


class EnvironmentProbeWritePolicyResponse(EnvironmentProbeWritePolicy):
    model_config = ConfigDict(from_attributes=True)


class EnvironmentProbeFileResponse(EnvironmentProbeFile):
    model_config = ConfigDict(from_attributes=True)


class EnvironmentProbeResponse(EnvironmentProbe):
    model_config = ConfigDict(extra="allow", from_attributes=True)


class GlobalViewResponse(GlobalView):
    model_config = ConfigDict(from_attributes=True)


class ReviewWorksetResponse(ReviewWorkset):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class DashboardSummaryResponse(DashboardSummary):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
