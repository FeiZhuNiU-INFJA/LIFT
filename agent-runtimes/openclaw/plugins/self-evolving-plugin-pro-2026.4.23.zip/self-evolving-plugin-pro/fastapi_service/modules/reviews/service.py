from __future__ import annotations

from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path

from sqlmodel import Session

from fastapi_service.infra.db import get_session
from fastapi_service.infra.paths import default_workspace_root
from fastapi_service.infra.reviews_store import create_review as create_review_record
from fastapi_service.infra.reviews_store import (
    dashboard_gene_total,
    dashboard_mutation_summary,
    dashboard_session_total,
    dashboard_workspace_change_summary,
    get_last_completed_review,
    get_workspace_change,
    replace_review_mutations,
)
from fastapi_service.infra.reviews_store import get_review as get_review_record
from fastapi_service.infra.reviews_store import list_review_mutations as list_review_mutation_rows
from fastapi_service.infra.reviews_store import list_reviews as list_review_rows
from fastapi_service.infra.reviews_store import update_review as update_review_record
from fastapi_service.infra.time import utc_now_unix
from fastapi_service.modules.reviews.models import (
    DashboardSummary,
    ExpressionApplyPolicy,
    ExpressionGenerationCase,
    ExpressionGenerationContext,
    ExpressionGenerationTargetCandidate,
    GeneLookupPolicy,
    GlobalView,
    Review,
    ReviewBindingCandidate,
    ReviewMutation,
    ReviewWorkset,
)
from fastapi_service.modules.reviews.schemas import (
    ReviewCompleteRequest,
    ReviewFailRequest,
    ReviewPrepareRequest,
    ReviewTokenUsageRequest,
)
from fastapi_service.modules.signals.models import SessionSummary, Signal
from fastapi_service.services.exceptions import EntityNotFoundError
from fastapi_service.services.helpers import parse_since_seconds

IdFactory = Callable[[str], str]
SessionFactory = Callable[[], Session]


class ReviewService:
    def __init__(
        self,
        *,
        id_factory: IdFactory,
        signals,
        genes,
        expressions,
        workspace,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._id = id_factory
        self.signals = signals
        self.genes = genes
        self.expressions = expressions
        self.workspace = workspace
        self._session_factory = session_factory or get_session

    @contextmanager
    def _session_scope(self, session=None):
        if session is not None:
            yield session
        else:
            s = self._session_factory()
            try:
                yield s
            finally:
                s.close()

    def prepare_review(self, request: ReviewPrepareRequest, session: Session | None = None) -> Review:
        since_seconds = parse_since_seconds(request.since)
        sessions = self._select_review_sessions(
            request.instance_id,
            request.limit,
            reason=request.reason,
            focus_session_id=request.focus_session_id,
            since_seconds=since_seconds,
            session=session,
        )
        previous_baseline = self.workspace._latest_snapshot(request.instance_id, "baseline", session=session)
        if not previous_baseline:
            raise EntityNotFoundError("baseline snapshot not found")
        current_baseline = self.workspace._capture_review_baseline_snapshot(
            request.instance_id, request.reason, session=session
        )
        workspace_root = (
            Path(
                self.workspace._instance_row(request.instance_id, session=session).workspace_root
                or default_workspace_root()
            )
            .expanduser()
            .resolve()
        )
        workspace_change = self.workspace._capture_baseline_workspace_change(
            request.instance_id,
            base_commit=previous_baseline.commit_hash,
            head_commit=current_baseline.commit_hash,
            workspace_root=workspace_root,
            storage_kind=current_baseline.storage_kind,
            session=session,
        )
        now = utc_now_unix()
        payload = Review(
            id=self._id("review"),
            instance_id=request.instance_id,
            since_text=request.since,
            reason_text=request.reason or "",
            focus_session_id=request.focus_session_id or "",
            workspace_change_id=workspace_change.id,
            workspace_change_base_kind="baseline",
            status="running",
            session_ids=[row.session_id for row in sessions],
            matched_expression_ids=[],
            created_expression_ids=[],
            updated_expression_ids=[],
            summary_text="",
            stats=[],
            report_markdown="",
            error_text="",
            created_at=now,
            updated_at=now,
            session_count=len(sessions),
            mutations=[],
        )
        with self._session_scope(session) as db_session:
            row = create_review_record(db_session, payload)
        return self._review_with_mutations(row, session=session)

    def _select_review_sessions(
        self,
        instance_id: str,
        limit: int,
        reason: str | None = None,
        focus_session_id: str | None = None,
        since_seconds: int | None = None,
        session: Session | None = None,
    ) -> list[SessionSummary]:
        sessions = self.signals.list_sessions(
            instance_id, max(limit * 3, limit), since_seconds=since_seconds, session=session
        )
        if reason == "session_start":
            sessions = sorted(
                sessions,
                key=lambda row: (
                    int(row.correction_count or 0) + int(row.failure_count or 0),
                    int(row.last_seen_at or 0),
                ),
                reverse=True,
            )
        selected: list[SessionSummary] = []
        if focus_session_id:
            focus = next((row for row in sessions if row.session_id == focus_session_id), None)
            if focus:
                selected.append(focus)
        selected_ids = {item.session_id for item in selected}
        for row in sessions:
            if row.session_id in selected_ids:
                continue
            selected.append(row)
            selected_ids.add(row.session_id)
            if len(selected) >= limit:
                break
        return selected[:limit]

    def _review_with_mutations(self, review: Review, session: Session | None = None) -> Review:
        if not review.id:
            return review
        return review.model_copy(update={"mutations": self.list_review_mutations(review.id, session=session)})

    def list_review_mutations(self, review_id: str, session: Session | None = None) -> list[ReviewMutation]:
        with self._session_scope(session) as db_session:
            return list_review_mutation_rows(db_session, review_id)

    def _fallback_review_mutations(
        self, request, review_id: str, session: Session | None = None
    ) -> list[ReviewMutation]:
        now = utc_now_unix()
        rows: list[ReviewMutation] = []
        for expression_id in request.created_expression_ids or []:
            expression = self.expressions._get_expression_row(request.instance_id, expression_id, session=session)
            rows.append(
                ReviewMutation(
                    id=self._id("mut"),
                    review_id=review_id,
                    instance_id=request.instance_id,
                    target_type="expression",
                    target_id=expression_id,
                    target_label=expression.summary if expression else expression_id,
                    description="新增 expression",
                    reason_text="review apply created expression",
                    status="applied",
                    before_text=None,
                    after_text=expression.content if expression else None,
                    gene_id=expression.gene_id if expression else None,
                    gene_name=self.genes._gene_name_for_id(request.instance_id, expression.gene_id)
                    if expression
                    else None,
                    target_file=expression.target_file if expression else None,
                    binding_ref=expression.binding_ref if expression else None,
                    created_at=now,
                )
            )
        for expression_id in request.updated_expression_ids or []:
            expression = self.expressions._get_expression_row(request.instance_id, expression_id, session=session)
            rows.append(
                ReviewMutation(
                    id=self._id("mut"),
                    review_id=review_id,
                    instance_id=request.instance_id,
                    target_type="expression",
                    target_id=expression_id,
                    target_label=expression.summary if expression else expression_id,
                    description="更新 expression",
                    reason_text="review apply updated expression",
                    status="applied",
                    before_text=None,
                    after_text=expression.content if expression else None,
                    gene_id=expression.gene_id if expression else None,
                    gene_name=self.genes._gene_name_for_id(request.instance_id, expression.gene_id)
                    if expression
                    else None,
                    target_file=expression.target_file if expression else None,
                    binding_ref=expression.binding_ref if expression else None,
                    created_at=now,
                )
            )
        return rows

    def _store_review_mutations(self, review_id: str, request, session: Session | None = None) -> list[ReviewMutation]:
        provided: list[ReviewMutation] = []
        now = utc_now_unix()
        for item in getattr(request, "mutations", None) or []:
            provided.append(
                ReviewMutation(
                    id=self._id("mut"),
                    review_id=review_id,
                    instance_id=request.instance_id,
                    target_type=item.target_type,
                    target_id=item.target_id,
                    target_label=item.target_label,
                    description=item.description,
                    reason_text=item.reason_text or "",
                    status=item.status,
                    before_text=item.before_text,
                    after_text=item.after_text,
                    gene_id=item.gene_id,
                    gene_name=item.gene_name,
                    target_file=self.expressions._normalize_target_file(request.instance_id, item.target_file),
                    binding_ref=item.binding_ref,
                    created_at=now,
                )
            )
        rows = provided or self._fallback_review_mutations(request, review_id, session=session)
        with self._session_scope(session) as db_session:
            return replace_review_mutations(db_session, review_id, rows)

    def get_review(self, review_id: str, session: Session | None = None) -> Review:
        with self._session_scope(session) as db_session:
            row = get_review_record(db_session, review_id)
        if not row:
            raise EntityNotFoundError("review not found")
        return self._review_with_mutations(row, session=session)

    def list_reviews(
        self, instance_id: str, limit: int = 20, status: str | None = None, session: Session | None = None
    ) -> list[Review]:
        with self._session_scope(session) as db_session:
            rows = list_review_rows(db_session, instance_id, limit, status)
        return [self._review_with_mutations(row, session=session) for row in rows]

    def dashboard_summary(self, instance_id: str, session: Session | None = None) -> DashboardSummary:
        with self._session_scope(session) as db_session:
            gene_total = dashboard_gene_total(db_session, instance_id)
            session_total = dashboard_session_total(db_session, instance_id)
            workspace_change_row = dashboard_workspace_change_summary(db_session, instance_id)
            mutation_row = dashboard_mutation_summary(db_session, instance_id)
            last_review = get_last_completed_review(db_session, instance_id)
        expression_counts = self.expressions.expression_counts(instance_id, session=session)
        signals_total = self.signals.signal_counts(instance_id, session=session)
        signals_24h = self.signals.signal_counts(instance_id, since_seconds=24 * 3600, session=session)
        env_probe = self.workspace._instance_env_probe(instance_id, session=session)
        global_view = GlobalView(
            editable_file_count=len(env_probe.editable_files),
            binding_candidate_count=len(env_probe.binding_candidates),
            status_counts=env_probe.status_counts,
            workspace_change_count=int(workspace_change_row.workspace_change_count or 0),
            workspace_changed_file_total=int(workspace_change_row.workspace_changed_file_total or 0),
            review_mutation_count=int(mutation_row.review_mutation_count or 0),
            applied_mutation_count=int(mutation_row.applied_mutation_count or 0),
            active_expression_count=int(expression_counts.active_count or 0),
            pending_expression_count=int(expression_counts.disabled_count or 0),
            stale_expression_count=int(expression_counts.stale_count or 0),
        )
        return DashboardSummary(
            instance_id=instance_id,
            sessions_total=session_total,
            genes_total=gene_total,
            signals_total=int(signals_total.total or 0),
            signals_24h=signals_24h,
            expressions=expression_counts,
            environment_probe=env_probe,
            global_view=global_view,
            last_completed_review=self._review_with_mutations(last_review, session=session) if last_review else None,
        )

    def _build_expression_generation_context(
        self, signals: list[Signal], binding_candidates: list[ReviewBindingCandidate]
    ) -> ExpressionGenerationContext:
        ranked_signals = sorted(
            signals,
            key=lambda item: (float(item.trust or 0), int(item.created_at or 0)),
            reverse=True,
        )
        primary_signal = ranked_signals[0] if ranked_signals else None
        primary_code = (
            str(primary_signal.normalized_kind if primary_signal else "")
            or str(primary_signal.kind if primary_signal else "")
            or "user_feedback"
        )
        bad_score = round(float(primary_signal.trust if primary_signal else 0.5), 2)
        error_evidence = [
            f"{str(item.normalized_kind or item.kind or 'signal')}: {str(item.content or '').strip()[:180]}"
            for item in ranked_signals[:3]
            if str(item.content or "").strip()
        ]
        user_input_excerpt = "\n".join(
            [str(item.content or "").strip() for item in ranked_signals[:2] if str(item.content or "").strip()]
        )[:600]
        target_candidates = [
            ExpressionGenerationTargetCandidate(
                file=item.target_file,
                section=item.binding_ref or "workspace.prompt_instructions",
                operation="append",
                confidence=item.confidence,
            )
            for item in binding_candidates[:6]
        ]
        return ExpressionGenerationContext(
            case=ExpressionGenerationCase(
                primary_code=primary_code,
                primary_label=self._signal_case_label(primary_code),
                bad_score=bad_score,
            ),
            error_evidence=error_evidence,
            user_input_excerpt=user_input_excerpt,
            target_candidates=target_candidates,
        )

    def _signal_case_label(self, code: str) -> str:
        labels = {
            "tool_failure": "工具失败",
            "correction": "用户纠正",
            "implicit_correction": "隐式纠正",
            "frustration": "用户挫败",
            "success_confirmation": "成功确认",
            "feature_request": "能力缺口",
            "preference_signal": "用户偏好",
            "context_revealed": "上下文补充",
            "silent_pivot": "话题切换",
            "pending": "待定信号",
            "change_attribution": "用户改动归因",
            "user_feedback": "一般反馈",
        }
        return labels.get(code, code or "unknown")

    def review_workset(self, review_id: str, session: Session | None = None) -> ReviewWorkset:
        review = self.get_review(review_id, session=session)
        since_seconds = parse_since_seconds(review.since_text)
        signals: list[Signal] = []
        sessions: list[SessionSummary] = []
        for session_id in review.session_ids:
            turns = self.signals.list_signals(
                review.instance_id,
                limit=50,
                session_id=session_id,
                since_seconds=since_seconds,
                session=session,
            )
            if turns:
                sessions.append(
                    SessionSummary(
                        session_id=session_id,
                        signal_count=len(turns),
                        last_seen_at=max(turn.created_at for turn in turns),
                        failure_count=sum(1 for turn in turns if turn.kind == "tool_failure"),
                        correction_count=sum(1 for turn in turns if turn.kind == "correction"),
                        success_count=sum(1 for turn in turns if turn.kind == "success_confirmation"),
                    )
                )
            signals.extend(turns)
        workspace_change = None
        if review.workspace_change_id:
            with self._session_scope(session) as db_session:
                row = get_workspace_change(db_session, review.workspace_change_id)
            workspace_change = self.workspace._workspace_change_with_entries(row, session=session) if row else None
        environment_probe = self.workspace._instance_env_probe(review.instance_id, session=session)
        binding_candidates = list(environment_probe.binding_candidates)
        return ReviewWorkset(
            review=review,
            sessions=sessions,
            signals=signals,
            genes=[
                self.genes._review_gene_view(gene)
                for gene in self.genes.list_genes(review.instance_id, session=session)
            ],
            expressions=self.expressions.list_expressions(review.instance_id, status="active", session=session),
            pending_expressions=self.expressions.list_expressions(
                review.instance_id, status="disabled", session=session
            ),
            workspace_change=workspace_change,
            binding_candidates=binding_candidates,
            expression_generation_context=self._build_expression_generation_context(signals, binding_candidates),
            gene_lookup_policy=GeneLookupPolicy(
                mode="cloud_readonly_with_local_cache",
                fallback="if no cloud gene is available, do not create an expression",
            ),
            expression_apply_policy=self._expression_apply_policy(),
        )

    def _expression_apply_policy(self) -> ExpressionApplyPolicy:
        from fastapi_service.config import Settings

        enabled = bool(Settings().openclaw_evolution_expression_workspace_patch_enabled)
        return ExpressionApplyPolicy(
            workspace_patch_enabled=enabled,
            apply_mode="workspace_or_hook" if enabled else "hook_only",
        )

    def _derive_review_summary(self, report_markdown: str) -> str:
        value = str(report_markdown or "").strip()
        if not value:
            return ""
        for line in value.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                return stripped[:240]
        return value[:240]

    def complete_review(self, review_id: str, request: ReviewCompleteRequest, session: Session | None = None) -> Review:
        review = self.get_review(review_id, session=session)
        summary_text = str(getattr(request, "summary_text", None) or "").strip() or self._derive_review_summary(
            request.report_markdown
        )
        signal_count = sum(
            len(self.signals.list_signals(request.instance_id, limit=50, session_id=session_id, session=session))
            for session_id in review.session_ids
        )
        stats = list(getattr(request, "stats", None) or []) or [
            {"label": "signals", "value": signal_count},
            {
                "label": "changes",
                "value": len(request.created_expression_ids or []) + len(request.updated_expression_ids or []),
            },
            {
                "label": "applied",
                "value": len(request.created_expression_ids or []) + len(request.updated_expression_ids or []),
            },
            {"label": "sessions", "value": len(review.session_ids)},
        ]
        mutations = self._store_review_mutations(review_id, request, session=session)
        self.genes._record_review_gene_matches(request, session=session)
        updated_review = review.model_copy(
            update={
                "status": "completed",
                "matched_expression_ids": list(request.matched_expression_ids or []),
                "created_expression_ids": list(request.created_expression_ids or []),
                "updated_expression_ids": list(request.updated_expression_ids or []),
                "summary_text": summary_text,
                "stats": stats,
                "report_markdown": request.report_markdown,
                "token_usage": dict(getattr(request, "token_usage", None) or {}),
                "updated_at": utc_now_unix(),
                "mutations": mutations,
            }
        )
        with self._session_scope(session) as db_session:
            update_review_record(db_session, review_id, updated_review)
        return self.get_review(review_id, session=session)

    def fail_review(self, review_id: str, request: ReviewFailRequest, session: Session | None = None) -> Review:
        review = self.get_review(review_id, session=session)
        failed_review = review.model_copy(
            update={
                "status": "failed",
                "error_text": request.error,
                "updated_at": utc_now_unix(),
            }
        )
        with self._session_scope(session) as db_session:
            update_review_record(db_session, review_id, failed_review)
        return self.get_review(review_id, session=session)

    def update_token_usage(
        self, review_id: str, request: ReviewTokenUsageRequest, session: Session | None = None
    ) -> Review:
        review = self.get_review(review_id, session=session)
        updated = review.model_copy(
            update={
                "token_usage": dict(request.token_usage or {}),
                "updated_at": utc_now_unix(),
            }
        )
        with self._session_scope(session) as db_session:
            update_review_record(db_session, review_id, updated)
        return self.get_review(review_id, session=session)
