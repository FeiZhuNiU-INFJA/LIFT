from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field
from sqlmodel import SQLModel

from fastapi_service.modules.expressions.models import Expression, ExpressionCounts
from fastapi_service.modules.genes.models import ReviewGeneView
from fastapi_service.modules.signals.models import SessionSummary, Signal, SignalCounts
from fastapi_service.modules.workspace.models import WorkspaceChange

if TYPE_CHECKING:
    from fastapi_service.infra.models import ReviewRecord


class ReviewMutation(SQLModel):
    id: str
    review_id: str
    instance_id: str
    target_type: str
    target_id: str | None = None
    target_label: str | None = None
    description: str
    reason_text: str
    status: str
    before_text: str | None = None
    after_text: str | None = None
    gene_id: str | None = None
    gene_name: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    created_at: int


class Review(SQLModel):
    id: str
    instance_id: str
    since_text: str
    reason_text: str
    focus_session_id: str
    workspace_change_id: str | None = None
    workspace_change_base_kind: str
    status: str
    session_ids: list[str] = Field(default_factory=list)
    matched_expression_ids: list[str] = Field(default_factory=list)
    created_expression_ids: list[str] = Field(default_factory=list)
    updated_expression_ids: list[str] = Field(default_factory=list)
    summary_text: str
    stats: list[dict[str, Any]] = Field(default_factory=list)
    report_markdown: str
    error_text: str
    token_usage: dict[str, Any] = Field(default_factory=dict)
    created_at: int
    updated_at: int
    session_count: int = 0
    mutations: list[ReviewMutation] = Field(default_factory=list)

    @classmethod
    def from_record(cls, row: ReviewRecord) -> Review:
        session_ids = json.loads(row.session_ids_json or "[]")
        return cls(
            id=row.id,
            instance_id=row.instance_id,
            since_text=row.since_text,
            reason_text=row.reason_text,
            focus_session_id=row.focus_session_id,
            workspace_change_id=row.workspace_change_id,
            workspace_change_base_kind=row.workspace_change_base_kind,
            status=row.status,
            session_ids=session_ids,
            matched_expression_ids=json.loads(row.matched_expression_ids_json or "[]"),
            created_expression_ids=json.loads(row.created_expression_ids_json or "[]"),
            updated_expression_ids=json.loads(row.updated_expression_ids_json or "[]"),
            summary_text=row.summary_text,
            stats=json.loads(row.stats_json or "[]"),
            report_markdown=row.report_markdown,
            error_text=row.error_text,
            token_usage=json.loads(getattr(row, "token_usage_json", None) or "{}"),
            created_at=row.created_at,
            updated_at=row.updated_at,
            session_count=len(session_ids),
            mutations=[],
        )

    def to_record(self) -> dict[str, Any]:
        data = self.model_dump(
            exclude={
                "session_ids",
                "matched_expression_ids",
                "created_expression_ids",
                "updated_expression_ids",
                "stats",
                "token_usage",
                "session_count",
                "mutations",
            }
        )
        data["session_ids_json"] = json.dumps(self.session_ids, ensure_ascii=False)
        data["matched_expression_ids_json"] = json.dumps(self.matched_expression_ids, ensure_ascii=False)
        data["created_expression_ids_json"] = json.dumps(self.created_expression_ids, ensure_ascii=False)
        data["updated_expression_ids_json"] = json.dumps(self.updated_expression_ids, ensure_ascii=False)
        data["stats_json"] = json.dumps(self.stats, ensure_ascii=False)
        data["token_usage_json"] = json.dumps(self.token_usage, ensure_ascii=False)
        return data


class ReviewBindingCandidate(BaseModel):
    binding_ref: str
    target_file: str
    kind: str
    confidence: str


class ExpressionGenerationCase(BaseModel):
    primary_code: str
    primary_label: str
    bad_score: float


class ExpressionGenerationTargetCandidate(BaseModel):
    file: str | None = None
    section: str
    operation: str
    confidence: str | None = None


class ExpressionGenerationContext(BaseModel):
    case: ExpressionGenerationCase
    error_evidence: list[str] = Field(default_factory=list)
    user_input_excerpt: str = ""
    target_candidates: list[ExpressionGenerationTargetCandidate] = Field(default_factory=list)


class GeneLookupPolicy(BaseModel):
    mode: str
    fallback: str


class ExpressionApplyPolicy(BaseModel):
    """Surfaces server-side rules about how an expression actually reaches
    the LLM, so the review prompt can avoid asking the reviewer to pick a
    target_file when patching is disabled. ``workspace_patch_enabled``
    mirrors openclaw_evolution_expression_workspace_patch_enabled.
    """

    workspace_patch_enabled: bool
    apply_mode: str  # "hook_only" when patching disabled, "workspace_or_hook" when enabled


class EnvironmentProbeRuleSet(BaseModel):
    do_not_invent_paths: bool
    target_file_must_exist_in_workspace: bool
    prefer_prompt_hook_or_real_workspace_file: bool
    preserve_user_owned_on_reinit: bool


class EnvironmentProbeWritePolicy(BaseModel):
    evolvable: str
    user_owned: str = "append-only"
    skill_owned: str = "skill-managed"
    needs_review: str
    runtime: str


class EnvironmentProbeFile(BaseModel):
    path: str
    priority: str
    role: str
    status: str
    classification: str | None = None
    layer: str | None = None
    governs: list[str] = Field(default_factory=list)
    write_risk: str
    write_policy: str
    size_bytes: int


class EnvironmentProbe(BaseModel):
    model_config = ConfigDict(extra="allow")

    workspace_root: str | None = None
    git_root: str | None = None
    baseline_commit: str | None = None
    status_counts: dict[str, int] = Field(default_factory=dict)
    file_registry: list[EnvironmentProbeFile] = Field(default_factory=list)
    editable_files: list[EnvironmentProbeFile] = Field(default_factory=list)
    binding_candidates: list[ReviewBindingCandidate] = Field(default_factory=list)
    rules: EnvironmentProbeRuleSet
    write_policy: EnvironmentProbeWritePolicy


class GlobalView(BaseModel):
    editable_file_count: int
    binding_candidate_count: int
    status_counts: dict[str, int] = Field(default_factory=dict)
    workspace_change_count: int
    workspace_changed_file_total: int
    review_mutation_count: int
    applied_mutation_count: int
    active_expression_count: int
    pending_expression_count: int
    stale_expression_count: int


class WorkspaceChangeMetrics(SQLModel):
    workspace_change_count: int = 0
    workspace_changed_file_total: int = 0


class MutationMetrics(SQLModel):
    review_mutation_count: int = 0
    applied_mutation_count: int = 0


class ReviewWorkset(SQLModel):
    review: Review
    sessions: list[SessionSummary] = Field(default_factory=list)
    signals: list[Signal] = Field(default_factory=list)
    genes: list[ReviewGeneView] = Field(default_factory=list)
    expressions: list[Expression] = Field(default_factory=list)
    pending_expressions: list[Expression] = Field(default_factory=list)
    workspace_change: WorkspaceChange | None = None
    binding_candidates: list[ReviewBindingCandidate] = Field(default_factory=list)
    expression_generation_context: ExpressionGenerationContext
    gene_lookup_policy: GeneLookupPolicy
    expression_apply_policy: ExpressionApplyPolicy


class DashboardSummary(SQLModel):
    instance_id: str
    sessions_total: int
    genes_total: int
    signals_total: int
    signals_24h: SignalCounts
    expressions: ExpressionCounts
    environment_probe: EnvironmentProbe
    global_view: GlobalView
    last_completed_review: Review | None = None
