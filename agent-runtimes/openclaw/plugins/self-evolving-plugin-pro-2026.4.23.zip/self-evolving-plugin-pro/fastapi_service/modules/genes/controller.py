from fastapi import APIRouter

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    GeneServiceDep,
    VerifiedInstanceIdDep,
    assert_instance_access_session,
)
from fastapi_service.modules.genes.schemas import (
    GeneCreateRequest,
    GeneEventFlushRequest,
    GeneEventFlushResponse,
    GeneResponse,
)

router = APIRouter()


@router.get("/genes", response_model=list[GeneResponse])
def list_genes(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: GeneServiceDep,
) -> list[GeneResponse]:
    rows = service.list_genes(instance_id, session=session)
    return [GeneResponse.model_validate(row) for row in rows]


@router.post("/genes", response_model=GeneResponse)
def create_gene(
    request: GeneCreateRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: GeneServiceDep,
) -> GeneResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return GeneResponse.model_validate(service.create_gene(request, session=session))


@router.post("/genes/events/flush", response_model=GeneEventFlushResponse)
def flush_gene_events(
    request: GeneEventFlushRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: GeneServiceDep,
) -> GeneEventFlushResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return GeneEventFlushResponse.model_validate(service.flush_pending_gene_events(limit=max(1, request.limit)))
