from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from fastapi_service.modules.genes.models import Gene, GeneEventFlushResult


class GeneCreateRequest(BaseModel):
    instance_id: str
    summary: str
    rule_text: str
    pattern_key: str | None = None
    source: str | None = None
    remote_gene_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class GeneLookupRequest(BaseModel):
    instance_id: str
    summary: str = ""
    rule_text: str = ""
    pattern_key: str | None = None


class GeneResponse(Gene):
    model_config = ConfigDict(from_attributes=True)


class GeneEventFlushRequest(BaseModel):
    instance_id: str
    limit: int = Field(default=100, ge=1, le=500)


class GeneEventFlushResponse(GeneEventFlushResult):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
