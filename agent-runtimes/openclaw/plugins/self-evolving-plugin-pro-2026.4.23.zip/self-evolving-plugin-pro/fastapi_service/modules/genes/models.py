from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field
from sqlmodel import SQLModel

if TYPE_CHECKING:
    from fastapi_service.infra.models import GeneEventOutboxRecord, GeneRecord


class RemoteGeneAction(BaseModel):
    action_type: str = ""
    action_description: str = ""
    action_template: str = ""
    intervention_point: Any = None
    fallback_description: str = ""


class RemoteGenePayload(BaseModel):
    id: str | None = None
    gene_id: str | None = None
    summary: str | None = None
    gene_name: str | None = None
    rule_text: str | None = None
    pattern_key: str | None = None
    gene_category: str | None = None
    layer: str | None = None
    version: str | None = None
    status: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    action: RemoteGeneAction = Field(default_factory=RemoteGeneAction)
    match_criteria: dict[str, Any] = Field(default_factory=dict)
    validation_guidance: dict[str, Any] = Field(default_factory=dict)


class RemoteGeneItemsEnvelope(BaseModel):
    items: list[RemoteGenePayload] = Field(default_factory=list)


class RemoteGeneLookupResponse(BaseModel):
    data: RemoteGeneItemsEnvelope | None = None
    Result: RemoteGeneItemsEnvelope | None = None


class RemoteGeneEventReportResult(BaseModel):
    accepted: int = 0
    inserted: int = 0
    deduplicated: int = 0


class RemoteGeneEventReportResponse(BaseModel):
    Result: RemoteGeneEventReportResult | None = None
    accepted: int = 0
    deduplicated: int = 0

    @property
    def resolved_accepted(self) -> int:
        return self.Result.accepted if self.Result else self.accepted

    @property
    def resolved_deduplicated(self) -> int:
        return self.Result.deduplicated if self.Result else self.deduplicated


class Gene(BaseModel):
    id: str
    instance_id: str
    summary: str
    rule_text: str
    pattern_key: str | None = None
    source: str
    remote_gene_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    hit_count: int
    cache_refreshed_at: int | None = None
    created_at: int

    @classmethod
    def from_record(cls, row: GeneRecord) -> Gene:
        return cls(
            id=row.id,
            instance_id=row.instance_id,
            summary=row.summary,
            rule_text=row.rule_text,
            pattern_key=row.pattern_key,
            source=row.source,
            remote_gene_id=row.remote_gene_id,
            metadata=json.loads(row.metadata_json or "{}"),
            hit_count=row.hit_count,
            cache_refreshed_at=row.cache_refreshed_at,
            created_at=row.created_at,
        )

    def to_record(self) -> dict[str, Any]:
        data = self.model_dump(exclude={"metadata"})
        data["metadata_json"] = json.dumps(self.metadata, ensure_ascii=False)
        return data


class GeneDraft(BaseModel):
    summary: str
    rule_text: str
    pattern_key: str | None = None
    source: str = "local"
    remote_gene_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ReviewGeneView(BaseModel):
    remote_gene_id: str | None = None
    summary: str | None = None
    rule_text: str | None = None
    pattern_key: str | None = None
    source: str | None = None
    hit_count: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


class GeneEventOutbox(SQLModel):
    event_id: str
    event_type: str
    schema_version: int = 1
    occurred_at: str
    emitted_at: str
    instance_id: str
    session_id: str | None = None
    review_id: str | None = None
    producer: dict[str, Any] = Field(default_factory=dict)
    payload: dict[str, Any] = Field(default_factory=dict)
    status: str = "pending"
    attempt_count: int = 0
    last_error: str | None = None
    sent_at: int | None = None
    created_at: int

    @classmethod
    def from_record(cls, row: GeneEventOutboxRecord) -> GeneEventOutbox:
        return cls(
            event_id=row.event_id,
            event_type=row.event_type,
            schema_version=row.schema_version,
            occurred_at=row.occurred_at,
            emitted_at=row.emitted_at,
            instance_id=row.instance_id,
            session_id=row.session_id,
            review_id=row.review_id,
            producer=json.loads(row.producer_json or "{}"),
            payload=json.loads(row.payload_json or "{}"),
            status=row.status,
            attempt_count=row.attempt_count,
            last_error=row.last_error,
            sent_at=row.sent_at,
            created_at=row.created_at,
        )

    def to_record(self) -> dict[str, Any]:
        data = self.model_dump(exclude={"producer", "payload"})
        data["producer_json"] = json.dumps(self.producer, ensure_ascii=False)
        data["payload_json"] = json.dumps(self.payload, ensure_ascii=False)
        return data


class GeneEventFlushResult(SQLModel):
    accepted: int = 0
    sent: int = 0
    deduplicated: int = 0
    error: str | None = None
