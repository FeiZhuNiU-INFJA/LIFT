from __future__ import annotations

import uuid
from collections.abc import Callable
from contextlib import contextmanager
from typing import Any

from sqlmodel import Session

from fastapi_service.config import Settings
from fastapi_service.infra.db import get_session
from fastapi_service.infra.genes_store import (
    create_gene as create_gene_record,
)
from fastapi_service.infra.genes_store import (
    create_gene_event as create_gene_event_record,
)
from fastapi_service.infra.genes_store import (
    delete_cloud_cache_genes,
    get_gene_by_pattern,
    get_gene_by_remote_id,
    get_gene_name_by_id,
    get_signal_match_ids,
    increment_gene_hit_counts,
    list_cloud_cache_genes,
    mark_expressions_stale_for_gene_ids,
    update_gene,
    update_signal_match_ids,
)
from fastapi_service.infra.genes_store import (
    list_genes as list_gene_rows,
)
from fastapi_service.infra.genes_store import (
    list_pending_gene_events as list_pending_gene_event_rows,
)
from fastapi_service.infra.time import unix_ts_to_iso, utc_now_iso, utc_now_unix
from fastapi_service.modules.expressions.models import (
    Expression,
    ExpressionEventSnapshot,
    ExpressionHitEventPayload,
    ExpressionStateChangeEventPayload,
    ExpressionUpsertEventPayload,
)
from fastapi_service.modules.expressions.schemas import ExpressionHitRequest
from fastapi_service.modules.genes.models import (
    Gene,
    GeneDraft,
    GeneEventFlushResult,
    GeneEventOutbox,
    RemoteGenePayload,
    ReviewGeneView,
)
from fastapi_service.modules.genes.schemas import GeneCreateRequest, GeneLookupRequest
from fastapi_service.modules.reviews.schemas import ReviewCompleteRequest
from fastapi_service.modules.signals.models import Signal, SignalEventPayload
from fastapi_service.services.exceptions import ServiceUnavailableError

IdFactory = Callable[[str], str]
ProducerMetadataFactory = Callable[[], dict[str, Any]]
SessionFactory = Callable[[], Session]


class GeneService:
    def __init__(
        self,
        *,
        id_factory: IdFactory,
        producer_metadata: ProducerMetadataFactory,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._id = id_factory
        self._producer_metadata = producer_metadata
        self._session_factory = session_factory or get_session

    @contextmanager
    def _session_scope(self, session=None):
        if session is not None:
            yield session
        else:
            s = self._session_factory()
            try:
                yield s
            finally:
                s.close()

    def _gene_event_producer_metadata(self) -> dict[str, Any]:
        return self._producer_metadata()

    def _gene_lookup_endpoint(self) -> tuple[str, str | None] | None:
        settings = Settings()
        endpoint = (settings.openclaw_evolution_gene_endpoint or "").strip()
        if not endpoint:
            return None
        token = (settings.openclaw_evolution_gene_token or "").strip() or None
        return endpoint, token

    def _is_remote_gene_list_endpoint(self, endpoint: str) -> bool:
        return endpoint.rstrip("/").lower().endswith("/pilot-studio/gene/list")

    def _gene_event_report_endpoint(self) -> tuple[str, str | None] | None:
        resolved = self._gene_lookup_endpoint()
        if not resolved:
            return None
        gene_endpoint, gene_token = resolved
        if self._is_remote_gene_list_endpoint(gene_endpoint):
            report_endpoint = (
                f"{gene_endpoint.rstrip('/')[: -len('/pilot-studio/gene/list')]}/pilot-studio/gene/event/report"
            )
        else:
            report_endpoint = f"{gene_endpoint.rstrip('/')}/event/report"
        return report_endpoint, gene_token

    def _gene_event_outbox_row(self, row: GeneEventOutbox) -> GeneEventOutbox:
        return row

    def _signal_event_payload(self, signal: Signal) -> SignalEventPayload:
        return SignalEventPayload(
            signal_id=signal.id,
            user_id=signal.user_id,
            kind=signal.kind,
            content=signal.content,
            tags=signal.tags,
            trust=signal.trust,
            source=signal.source,
            source_ref=signal.source_ref,
            classifier_note=signal.classifier_note,
            raw_payload=signal.raw_payload,
            signal_created_at=unix_ts_to_iso(signal.created_at),
        )

    def _expression_state_change_payload(
        self,
        before: Expression,
        after: Expression,
    ) -> ExpressionStateChangeEventPayload:
        return ExpressionStateChangeEventPayload(
            expression_id=after.id,
            remote_gene_id=str(after.remote_gene_id or "").strip() or None,
            from_status=before.status,
            to_status=after.status,
            target_file=after.target_file,
            binding_ref=after.binding_ref,
            apply_mode=after.apply_mode,
            apply_commit=after.apply_commit,
            disable_commit=after.disable_commit,
            changed_at=unix_ts_to_iso(after.updated_at),
        )

    def _expression_hit_event_payload(
        self,
        expression: Expression,
        request: ExpressionHitRequest,
    ) -> ExpressionHitEventPayload:
        return ExpressionHitEventPayload(
            expression_id=expression.id,
            remote_gene_id=str(expression.remote_gene_id or "").strip() or None,
            hit_source=str(request.hit_source or "").strip() or None,
            observed_at=unix_ts_to_iso(expression.last_hit_at),
        )

    def _normalize_signal_ids(self, values: list[str] | None) -> list[str]:
        normalized: list[str] = []
        seen: set[str] = set()
        for value in values or []:
            signal_id = str(value or "").strip()
            if not signal_id or signal_id in seen:
                continue
            seen.add(signal_id)
            normalized.append(signal_id)
        return normalized

    def _expression_event_snapshot(self, expression: Expression) -> ExpressionEventSnapshot:
        return ExpressionEventSnapshot(
            expression_id=expression.id,
            summary=expression.summary,
            content=expression.content,
            status=expression.status,
            pattern_key=expression.pattern_key,
            target_file=expression.target_file,
            binding_ref=expression.binding_ref,
            apply_mode=expression.apply_mode,
            created_at=unix_ts_to_iso(expression.created_at),
            updated_at=unix_ts_to_iso(expression.updated_at),
        )

    def _expression_upsert_event_payload(
        self,
        *,
        operation: str,
        expression: Expression,
        signal_ids: list[str] | None,
    ) -> ExpressionUpsertEventPayload | None:
        remote_gene_id = str(expression.remote_gene_id or "").strip()
        normalized_signal_ids = self._normalize_signal_ids(signal_ids)
        if not remote_gene_id or not normalized_signal_ids:
            return None
        return ExpressionUpsertEventPayload(
            operation=operation,
            signal_ids=normalized_signal_ids,
            remote_gene_id=remote_gene_id,
            expression=self._expression_event_snapshot(expression),
        )

    def enqueue_gene_event(
        self,
        *,
        event_type: str,
        instance_id: str,
        payload: dict[str, Any],
        session_id: str | None = None,
        review_id: str | None = None,
        occurred_at: str | None = None,
        schema_version: int = 1,
    ) -> GeneEventOutbox:
        event = GeneEventOutbox(
            event_id=str(uuid.uuid4()),
            event_type=str(event_type or "").strip(),
            schema_version=int(schema_version or 1),
            occurred_at=str(occurred_at or utc_now_iso()),
            emitted_at=utc_now_iso(),
            instance_id=str(instance_id or "").strip(),
            session_id=str(session_id or "").strip() or None,
            review_id=str(review_id or "").strip() or None,
            producer=self._gene_event_producer_metadata() or {},
            payload=payload.model_dump(mode="json") if hasattr(payload, "model_dump") else (payload or {}),
            status="pending",
            attempt_count=0,
            last_error=None,
            sent_at=None,
            created_at=utc_now_unix(),
        )
        with self._session_scope() as db_session:
            saved = create_gene_event_record(db_session, event)
        return self._gene_event_outbox_row(saved)

    def list_pending_gene_events(self, limit: int = 100) -> list[GeneEventOutbox]:
        with self._session_scope() as db_session:
            rows = list_pending_gene_event_rows(db_session, int(limit or 100))
        return [self._gene_event_outbox_row(row) for row in rows]

    def flush_pending_gene_events(self, limit: int = 100) -> GeneEventFlushResult:
        # Cloud event-report endpoint is disabled. Events still accumulate in
        # the local outbox (gene_event_outbox table) so no signal/expression
        # data is lost; they just never leave the host. To re-enable cloud
        # sync, set OPENCLAW_EVOLUTION_GENE_ENDPOINT (and optionally _TOKEN)
        # and restore the HTTP post below.
        resolved = self._gene_event_report_endpoint()
        if not resolved:
            return GeneEventFlushResult(accepted=0, sent=0, deduplicated=0)
        # endpoint, token = resolved
        # pending = self.list_pending_gene_events(limit=limit)
        # if not pending:
        #     return GeneEventFlushResult(accepted=0, sent=0, deduplicated=0)
        # payload = {
        #     "events": [
        #         {
        #             "event_id": item.event_id,
        #             "event_type": item.event_type,
        #             "schema_version": item.schema_version,
        #             "occurred_at": item.occurred_at,
        #             "emitted_at": item.emitted_at,
        #             "instance_id": item.instance_id,
        #             "session_id": item.session_id,
        #             "review_id": item.review_id,
        #             "producer": item.producer,
        #             "payload": item.payload,
        #         }
        #         for item in pending
        #     ]
        # }
        # headers = {"content-type": "application/json"}
        # if token:
        #     headers["authorization"] = f"Bearer {token}"
        # event_ids = [item.event_id for item in pending]
        # with self._session_scope() as db_session:
        #     try:
        #         resp = httpx.post(endpoint, json=payload, headers=headers, timeout=5)
        #         resp.raise_for_status()
        #         result = RemoteGeneEventReportResponse.model_validate(resp.json())
        #         sent_at = utc_now_unix()
        #         mark_gene_events_sent(db_session, event_ids, sent_at)
        #     except Exception as error:
        #         mark_gene_events_failed(db_session, event_ids, str(error))
        #         return GeneEventFlushResult(accepted=0, sent=0, deduplicated=0, error=str(error))
        # return GeneEventFlushResult(
        #     accepted=int(result.resolved_accepted or len(event_ids)),
        #     sent=len(event_ids),
        #     deduplicated=int(result.resolved_deduplicated or 0),
        # )
        return GeneEventFlushResult(accepted=0, sent=0, deduplicated=0)

    def _ensure_initial_gene_cache(self, instance_id: str, session: Session | None = None) -> None:
        # Cloud gene-list endpoint is disabled. Bootstrap from the bundled
        # snapshot shipped with the plugin (fastapi_service/data/bundled_genes.json).
        # To re-enable remote sync, export OPENCLAW_EVOLUTION_GENE_ENDPOINT and
        # restore the remote call below.
        # resolved = self._gene_lookup_endpoint()
        # if not resolved or not self._is_remote_gene_list_endpoint(resolved[0]):
        #     raise ServiceUnavailableError("initial gene sync requires a remote gene list endpoint")
        # remote_genes = self._fetch_remote_gene_items(
        #     GeneLookupRequest(instance_id=instance_id, summary="", rule_text="", pattern_key=None)
        # )
        remote_genes = self._load_bundled_genes()
        if not remote_genes:
            raise ServiceUnavailableError("bundled gene snapshot is empty or missing")
        # Callers (e.g. onboard_instance) already hold a session; piping it
        # through lets the 64 bundled gene INSERTs reuse the same SQLite
        # connection instead of opening a second writer and hitting
        # "database is locked".
        self._sync_remote_gene_cache(instance_id, remote_genes, session=session)

    def _load_bundled_genes(self) -> list[GeneDraft]:
        """Load the repo-bundled gene snapshot. Falls back to [] if the
        file is missing so this stays a pure-runtime change and tests that
        mock out gene data don't have to ship the JSON.
        """
        import json
        from pathlib import Path

        bundle_path = Path(__file__).resolve().parents[2] / "data" / "bundled_genes.json"
        if not bundle_path.exists():
            return []
        try:
            rows = json.loads(bundle_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        drafts: list[GeneDraft] = []
        for row in rows:
            remote_id = str(row.get("remote_gene_id") or "").strip()
            if not remote_id:
                continue
            drafts.append(
                GeneDraft(
                    summary=str(row.get("summary") or "").strip(),
                    rule_text=str(row.get("rule_text") or "").strip(),
                    pattern_key=(row.get("pattern_key") or None),
                    source="cloud_cache",
                    remote_gene_id=remote_id,
                    metadata=row.get("metadata") or {},
                )
            )
        return drafts

    def list_genes(self, instance_id: str, session: Session | None = None) -> list[Gene]:
        with self._session_scope(session) as db_session:
            return list_gene_rows(db_session, instance_id)

    def _gene_row_by_remote_id(self, instance_id: str, remote_gene_id: str | None) -> Gene | None:
        key = str(remote_gene_id or "").strip()
        if not key:
            return None
        with self._session_scope() as db_session:
            return get_gene_by_remote_id(db_session, instance_id, key)

    def _cached_gene_by_pattern(self, instance_id: str, pattern_key: str | None) -> Gene | None:
        if not pattern_key:
            return None
        with self._session_scope() as db_session:
            return get_gene_by_pattern(db_session, instance_id, pattern_key)

    def _gene_lookup_payload(self, endpoint: str, request: GeneLookupRequest) -> dict[str, Any]:
        if self._is_remote_gene_list_endpoint(endpoint):
            return {}
        return {
            "instance_id": request.instance_id,
            "summary": request.summary,
            "rule_text": request.rule_text,
            "pattern_key": (request.pattern_key or "").strip() or None,
        }

    def _normalize_remote_gene(
        self, payload: RemoteGenePayload | None, request: GeneLookupRequest | None
    ) -> GeneDraft | None:
        if payload is None:
            return None
        request_summary = str(request.summary if request else "").strip()
        request_rule_text = str(request.rule_text if request else "").strip()
        request_pattern_key = str(request.pattern_key if request else "").strip() or None
        remote_id = str(payload.id or payload.gene_id or "").strip()
        if not remote_id:
            return None
        metadata = payload.metadata or {}
        action = payload.action
        match_criteria = payload.match_criteria or {}
        validation_guidance = payload.validation_guidance or {}
        summary = str(payload.summary or payload.gene_name or request_summary or "").strip()
        action_description = str(action.action_description or "").strip()
        action_template = str(action.action_template or "").strip()
        rule_text = str(payload.rule_text or action_description or action_template or request_rule_text or "").strip()
        pattern_key = str(payload.pattern_key or request_pattern_key or "").strip() or None
        merged_metadata = {
            **metadata,
            "gene_name": str(payload.gene_name or summary or "").strip(),
            "gene_category": str(payload.gene_category or "").strip(),
            "layer": str(payload.layer or "").strip(),
            "version": str(payload.version or "").strip(),
            "status": str(payload.status or "").strip(),
            "match_criteria": match_criteria,
            "action_type": str(action.action_type or "").strip(),
            "action_template": str(action.action_template or "").strip(),
            "intervention_point": action.intervention_point,
            "fallback_description": str(action.fallback_description or "").strip(),
            "validation_guidance": validation_guidance,
        }
        return GeneDraft(
            summary=summary or request_summary,
            rule_text=rule_text or request_rule_text,
            pattern_key=pattern_key,
            metadata=merged_metadata,
            source="cloud_cache",
            remote_gene_id=remote_id,
        )

    def _fetch_remote_gene_items(self, request: GeneLookupRequest) -> list[GeneDraft] | None:
        # Cloud gene-lookup is disabled. Historically this POSTed to
        # OPENCLAW_EVOLUTION_GENE_ENDPOINT; we now ship a static gene catalog
        # and no longer depend on the remote. To restore, uncomment below.
        resolved = self._gene_lookup_endpoint()
        if not resolved:
            return None
        # endpoint, token = resolved
        # payload = self._gene_lookup_payload(endpoint, request)
        # headers = {"content-type": "application/json"}
        # if token:
        #     headers["authorization"] = f"Bearer {token}"
        # try:
        #     resp = httpx.post(endpoint, json=payload, headers=headers, timeout=5)
        #     resp.raise_for_status()
        # except (httpx.HTTPError, TimeoutError, ValueError):
        #     return None
        # data = resp.json()
        # if not isinstance(data, dict):
        #     return None
        # response_payload = RemoteGeneLookupResponse.model_validate(data)
        # normalized = self._normalize_remote_gene(RemoteGenePayload.model_validate(data), request)
        # if normalized:
        #     return [normalized]
        # result = response_payload.data or response_payload.Result
        # items = list(result.items) if result else []
        # prioritized = sorted(items, key=lambda item: (str(item.status or "").lower() != "active",))
        # return [
        #     normalized for normalized in (self._normalize_remote_gene(item, None) for item in prioritized) if normalized
        # ]
        return None

    def _sync_remote_gene_cache(
        self,
        instance_id: str,
        remote_genes: list[GeneDraft],
        session: Session | None = None,
    ) -> dict[str, Gene]:
        now = utc_now_unix()
        with self._session_scope(session) as session:
            existing_rows = list_cloud_cache_genes(session, instance_id)
            existing_by_remote = {
                str(row.remote_gene_id): row for row in existing_rows if str(row.remote_gene_id or "").strip()
            }
            synced: dict[str, Gene] = {}
            incoming_remote_ids = {
                str(item.remote_gene_id) for item in remote_genes if str(item.remote_gene_id or "").strip()
            }
            for gene_data in remote_genes:
                remote_id = str(gene_data.remote_gene_id or "").strip()
                if not remote_id:
                    continue
                existing = existing_by_remote.get(remote_id)
                if existing:
                    row = update_gene(
                        session,
                        existing.id,
                        Gene(
                            id=existing.id,
                            instance_id=instance_id,
                            summary=gene_data.summary,
                            rule_text=gene_data.rule_text,
                            pattern_key=gene_data.pattern_key
                            if gene_data.pattern_key is not None
                            else existing.pattern_key,
                            source="cloud_cache",
                            remote_gene_id=remote_id,
                            metadata=gene_data.metadata,
                            hit_count=existing.hit_count,
                            cache_refreshed_at=now,
                            created_at=existing.created_at,
                        ),
                    )
                    if row is not None:
                        synced[remote_id] = row
                else:
                    synced[remote_id] = create_gene_record(
                        session,
                        Gene(
                            id=self._id("gene"),
                            instance_id=instance_id,
                            summary=gene_data.summary,
                            rule_text=gene_data.rule_text,
                            pattern_key=gene_data.pattern_key,
                            source="cloud_cache",
                            remote_gene_id=remote_id,
                            metadata=gene_data.metadata,
                            hit_count=0,
                            cache_refreshed_at=now,
                            created_at=now,
                        ),
                    )
            stale_remote_ids = [
                remote_id for remote_id in existing_by_remote.keys() if remote_id not in incoming_remote_ids
            ]
            stale_local_gene_ids = [existing_by_remote[remote_id].id for remote_id in stale_remote_ids]
            if stale_local_gene_ids:
                mark_expressions_stale_for_gene_ids(
                    session, instance_id, [str(item) for item in stale_local_gene_ids], now
                )
                delete_cloud_cache_genes(session, instance_id, [str(item) for item in stale_local_gene_ids])
        return synced

    def _upsert_cached_gene(self, instance_id: str, gene_data: GeneDraft) -> Gene:
        pattern_key = gene_data.pattern_key
        existing = self._cached_gene_by_pattern(instance_id, pattern_key) if pattern_key else None
        now = utc_now_unix()
        with self._session_scope() as session:
            if existing:
                row = update_gene(
                    session,
                    existing.id,
                    Gene(
                        id=existing.id,
                        instance_id=instance_id,
                        summary=gene_data.summary,
                        rule_text=gene_data.rule_text,
                        pattern_key=existing.pattern_key,
                        source=gene_data.source or "cloud_cache",
                        remote_gene_id=gene_data.remote_gene_id,
                        metadata=gene_data.metadata,
                        hit_count=existing.hit_count,
                        cache_refreshed_at=now,
                        created_at=existing.created_at,
                    ),
                )
                return row if row is not None else existing
            return create_gene_record(
                session,
                Gene(
                    id=self._id("gene"),
                    instance_id=instance_id,
                    summary=gene_data.summary,
                    rule_text=gene_data.rule_text,
                    pattern_key=pattern_key,
                    source=gene_data.source or "cloud_cache",
                    remote_gene_id=gene_data.remote_gene_id,
                    metadata=gene_data.metadata,
                    hit_count=0,
                    cache_refreshed_at=now,
                    created_at=now,
                ),
            )

    def create_gene(self, request: GeneCreateRequest, session: Session | None = None) -> Gene:
        pattern_key = (request.pattern_key or "").strip() or None
        cached = self._cached_gene_by_pattern(request.instance_id, pattern_key)
        if cached:
            return cached
        created_at = utc_now_unix()
        payload = Gene(
            id=self._id("gene"),
            instance_id=request.instance_id,
            summary=request.summary,
            rule_text=request.rule_text,
            pattern_key=pattern_key,
            source=str(request.source or "local"),
            remote_gene_id=str(request.remote_gene_id or "") or None,
            metadata=request.metadata or {},
            hit_count=0,
            cache_refreshed_at=created_at if request.remote_gene_id else None,
            created_at=created_at,
        )
        with self._session_scope(session) as db_session:
            return create_gene_record(db_session, payload)

    def _gene_name_for_id(self, instance_id: str, gene_id: str | None) -> str | None:
        key = str(gene_id or "").strip()
        if not key:
            return None
        with self._session_scope() as db_session:
            summary = get_gene_name_by_id(db_session, instance_id, key)
        return None if summary is None else str(summary)

    def _normalize_remote_gene_ids(self, values: list[str] | None) -> list[str]:
        normalized: list[str] = []
        seen: set[str] = set()
        for value in values or []:
            remote_id = str(value or "").strip()
            if not remote_id or remote_id in seen:
                continue
            seen.add(remote_id)
            normalized.append(remote_id)
        return normalized

    def _record_review_gene_matches(self, request: ReviewCompleteRequest, session: Session | None = None) -> None:
        matches = list(request.matched_genes or [])
        if not matches:
            return
        with self._session_scope(session) as db_session:
            for item in matches:
                signal_id = str(item.signal_id or "").strip()
                remote_gene_ids = self._normalize_remote_gene_ids(item.remote_gene_ids or [])
                if not signal_id:
                    continue
                existing_remote_gene_ids = get_signal_match_ids(db_session, signal_id, request.instance_id)
                if existing_remote_gene_ids is None:
                    continue
                merged_remote_gene_ids = self._normalize_remote_gene_ids(existing_remote_gene_ids + remote_gene_ids)
                update_signal_match_ids(db_session, signal_id, request.instance_id, merged_remote_gene_ids)
                increment_gene_hit_counts(db_session, request.instance_id, remote_gene_ids)

    def _review_gene_view(self, gene: Gene) -> ReviewGeneView:
        return ReviewGeneView(
            remote_gene_id=str(gene.remote_gene_id or "").strip() or None,
            summary=gene.summary,
            rule_text=gene.rule_text,
            pattern_key=gene.pattern_key,
            source=gene.source,
            hit_count=int(gene.hit_count or 0),
            metadata=gene.metadata or {},
        )
