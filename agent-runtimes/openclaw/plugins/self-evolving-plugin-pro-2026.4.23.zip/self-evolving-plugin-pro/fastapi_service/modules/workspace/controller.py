from fastapi import APIRouter, Query

from fastapi_service.api.deps import (
    AuthHeadersDep,
    DbSessionDep,
    VerifiedInstanceIdDep,
    WorkspaceServiceDep,
    assert_instance_access_session,
)
from fastapi_service.modules.workspace.schemas import (
    SnapshotResponse,
    WorkspaceChangeAttributionRequest,
    WorkspaceChangeAttributionResponse,
    WorkspaceChangeResponse,
    WorkspaceChangeScanRequest,
    WorkspaceFileDetailResponse,
    WorkspaceFileDiffResponse,
    WorkspaceInventoryItemResponse,
)

router = APIRouter()


@router.get("/workspace/inventory", response_model=list[WorkspaceInventoryItemResponse])
def list_workspace_inventory(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
) -> list[WorkspaceInventoryItemResponse]:
    rows = service.list_workspace_inventory(instance_id, session=session)
    return [WorkspaceInventoryItemResponse.model_validate(row) for row in rows]


@router.get("/workspace/files/detail", response_model=WorkspaceFileDetailResponse)
def workspace_file_detail(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
    path: str = Query(...),
    limit: int = Query(10, ge=1, le=100),
) -> WorkspaceFileDetailResponse:
    return WorkspaceFileDetailResponse.model_validate(
        service.workspace_file_detail(instance_id, path, limit, session=session)
    )


@router.get("/workspace/files/diff", response_model=WorkspaceFileDiffResponse)
def workspace_file_diff(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
    path: str = Query(...),
    commit: str = Query(...),
) -> WorkspaceFileDiffResponse:
    return WorkspaceFileDiffResponse.model_validate(
        service.workspace_file_diff(instance_id, path, commit, session=session)
    )


@router.post("/workspace/changes/scan", response_model=WorkspaceChangeResponse)
def scan_workspace_changes(
    request: WorkspaceChangeScanRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
) -> WorkspaceChangeResponse:
    assert_instance_access_session(session, headers, request.instance_id)
    return WorkspaceChangeResponse.model_validate(
        service.capture_workspace_change(request.instance_id, base_kind=request.base_kind, session=session)
    )


@router.get("/workspace/changes", response_model=list[WorkspaceChangeResponse])
def list_workspace_changes(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
    limit: int = Query(20, ge=1, le=100),
) -> list[WorkspaceChangeResponse]:
    rows = service.list_workspace_changes(instance_id, limit, session=session)
    return [WorkspaceChangeResponse.model_validate(row) for row in rows]


@router.get("/workspace/changes/{change_id}/attributions", response_model=list[WorkspaceChangeAttributionResponse])
def list_workspace_change_attributions(
    change_id: str,
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
) -> list[WorkspaceChangeAttributionResponse]:
    rows = service.list_change_attributions(instance_id, change_id, session=session)
    return [WorkspaceChangeAttributionResponse.model_validate(row) for row in rows]


@router.post("/workspace/changes/{change_id}/attributions", response_model=list[WorkspaceChangeAttributionResponse])
def create_workspace_change_attributions(
    change_id: str,
    request: WorkspaceChangeAttributionRequest,
    headers: AuthHeadersDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
) -> list[WorkspaceChangeAttributionResponse]:
    assert_instance_access_session(session, headers, request.instance_id)
    rows = service.replace_change_attributions(change_id, request, session=session)
    return [WorkspaceChangeAttributionResponse.model_validate(row) for row in rows]


@router.get("/snapshots", response_model=list[SnapshotResponse])
def list_snapshots(
    instance_id: VerifiedInstanceIdDep,
    session: DbSessionDep,
    service: WorkspaceServiceDep,
    kind: str | None = Query(default=None),
) -> list[SnapshotResponse]:
    rows = service.list_snapshots(instance_id, kind, session=session)
    return [SnapshotResponse.model_validate(row) for row in rows]
