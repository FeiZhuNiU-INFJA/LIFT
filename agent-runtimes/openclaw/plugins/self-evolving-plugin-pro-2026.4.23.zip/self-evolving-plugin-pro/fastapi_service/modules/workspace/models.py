from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from pydantic import Field
from sqlmodel import SQLModel

from fastapi_service.modules.expressions.models import Expression

if TYPE_CHECKING:
    from fastapi_service.infra.models import WorkspaceChangeRecord


class WorkspaceInventoryItem(SQLModel):
    relative_path: str
    file_kind: str
    classification: str
    size_bytes: int
    scan_at: int


class WorkspaceChangedFileActivity(SQLModel):
    activity_status: str
    activity_category: str
    activity_visible: bool
    activity_layer: str | None = None


class WorkspaceChangedFile(SQLModel):
    path: str
    status: str
    priority: str
    activity_status: str | None = None
    activity_category: str | None = None
    activity_visible: bool | None = None
    activity_layer: str | None = None


class WorkspaceChangeSummary(SQLModel):
    changed_files: list[WorkspaceChangedFile] = Field(default_factory=list)
    p0_files: list[str] = Field(default_factory=list)
    changed_file_count: int
    total_changed_file_count: int
    hidden_file_count: int


class WorkspaceChangeEntry(SQLModel):
    id: str
    workspace_change_id: str
    instance_id: str
    target_file: str
    status: str
    description: str
    before_text: str | None = None
    after_text: str | None = None
    created_at: int
    activity_label: str | None = None
    activity_visible: bool | None = None
    activity_kind: str | None = None


class WorkspaceChange(SQLModel):
    id: str
    instance_id: str
    base_kind: str
    storage_kind: str
    base_commit: str
    head_commit: str | None = None
    summary: WorkspaceChangeSummary
    created_at: int
    entries: list[WorkspaceChangeEntry] = Field(default_factory=list)

    @classmethod
    def from_record(cls, row: WorkspaceChangeRecord) -> WorkspaceChange:
        return cls(
            id=row.id,
            instance_id=row.instance_id,
            base_kind=row.base_kind,
            storage_kind=row.storage_kind,
            base_commit=row.base_commit,
            head_commit=row.head_commit,
            summary=WorkspaceChangeSummary.model_validate(json.loads(row.summary_json or "{}")),
            created_at=row.created_at,
            entries=[],
        )

    def to_record(self) -> dict[str, Any]:
        data = self.model_dump(exclude={"summary", "entries"})
        data["summary_json"] = json.dumps(self.summary.model_dump(), ensure_ascii=False)
        return data


class WorkspaceChangeAttribution(SQLModel):
    id: str
    workspace_change_id: str
    instance_id: str
    target_type: str
    target_id: str | None = None
    reason_text: str
    confidence: float
    created_at: int


class WorkspaceGitHistoryEntry(SQLModel):
    commit: str
    created_at: int
    summary: str


class WorkspaceFileDiff(SQLModel):
    path: str
    commit: str
    patch: str


class WorkspaceReviewMutation(SQLModel):
    """Review mutation view used by the workspace module.

    Structurally identical to ReviewMutation in reviews/models.py;
    duplicated here to avoid a circular import between workspace and reviews.
    """

    id: str
    review_id: str
    instance_id: str
    target_type: str
    target_id: str | None = None
    target_label: str | None = None
    description: str
    reason_text: str
    status: str
    before_text: str | None = None
    after_text: str | None = None
    gene_id: str | None = None
    gene_name: str | None = None
    target_file: str | None = None
    binding_ref: str | None = None
    created_at: int


class WorkspaceFileDetail(SQLModel):
    path: str
    classification: str
    file_kind: str
    size_bytes: int
    scan_at: int
    status: str | None = None
    layer: str | None = None
    role: str | None = None
    write_risk: str | None = None
    write_policy: str | None = None
    git_history: list[WorkspaceGitHistoryEntry] = Field(default_factory=list)
    workspace_change_count: int
    review_mutation_count: int
    expression_count: int
    workspace_changes: list[WorkspaceChange] = Field(default_factory=list)
    review_mutations: list[WorkspaceReviewMutation] = Field(default_factory=list)
    expressions: list[Expression] = Field(default_factory=list)


class Snapshot(SQLModel):
    id: str
    instance_id: str
    kind: str
    sequence: int
    storage_kind: str
    workspace_root: str
    git_root: str | None = None
    commit_hash: str
    parent_commit: str | None = None
    review_id: str | None = None
    trigger_kind: str
    summary: str
    created_at: int
