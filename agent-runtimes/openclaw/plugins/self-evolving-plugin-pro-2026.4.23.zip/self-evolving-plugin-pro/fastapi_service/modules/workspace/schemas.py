from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from fastapi_service.modules.workspace.models import (
    Snapshot,
    WorkspaceChange,
    WorkspaceChangeAttribution,
    WorkspaceChangedFile,
    WorkspaceChangeEntry,
    WorkspaceChangeSummary,
    WorkspaceFileDetail,
    WorkspaceFileDiff,
    WorkspaceGitHistoryEntry,
    WorkspaceInventoryItem,
    WorkspaceReviewMutation,
)

WorkspaceBaseKind = Literal["baseline", "onboarding"]


class WorkspaceChangeScanRequest(BaseModel):
    instance_id: str
    base_kind: WorkspaceBaseKind | str = "baseline"


class WorkspaceChangeAttributionItem(BaseModel):
    target_type: str
    target_id: str | None = None
    reason_text: str
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class WorkspaceChangeAttributionRequest(BaseModel):
    instance_id: str
    attributions: list[WorkspaceChangeAttributionItem] = Field(default_factory=list)


class WorkspaceInventoryItemResponse(WorkspaceInventoryItem):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceFileDiffResponse(WorkspaceFileDiff):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceChangedFileResponse(WorkspaceChangedFile):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceChangeSummaryResponse(WorkspaceChangeSummary):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceChangeEntryResponse(WorkspaceChangeEntry):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceChangeResponse(WorkspaceChange):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceChangeAttributionResponse(WorkspaceChangeAttribution):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceGitHistoryEntryResponse(WorkspaceGitHistoryEntry):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceReviewMutationResponse(WorkspaceReviewMutation):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class WorkspaceFileDetailResponse(WorkspaceFileDetail):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]


class SnapshotResponse(Snapshot):
    model_config = ConfigDict(from_attributes=True)  # type: ignore[assignment]
