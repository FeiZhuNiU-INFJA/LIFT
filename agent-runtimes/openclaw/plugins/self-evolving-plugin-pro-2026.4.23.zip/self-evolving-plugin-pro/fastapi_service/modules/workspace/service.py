from __future__ import annotations

import os
import subprocess
import tempfile
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from sqlmodel import Session

from fastapi_service.infra.db import get_session
from fastapi_service.infra.models import InstanceRecord
from fastapi_service.infra.paths import default_workspace_root
from fastapi_service.infra.time import utc_now_unix
from fastapi_service.infra.workspace_store import create_snapshot as create_snapshot_record
from fastapi_service.infra.workspace_store import create_workspace_change as create_workspace_change_record
from fastapi_service.infra.workspace_store import (
    create_workspace_change_entries,
    find_workspace_change,
    get_instance_env_probe,
    get_instance_row,
    list_file_expressions,
    list_file_review_mutations,
    list_file_workspace_changes,
)
from fastapi_service.infra.workspace_store import get_workspace_change as get_workspace_change_record
from fastapi_service.infra.workspace_store import latest_snapshot as latest_snapshot_row
from fastapi_service.infra.workspace_store import list_change_attributions as list_change_attribution_rows
from fastapi_service.infra.workspace_store import list_snapshots as list_snapshot_rows
from fastapi_service.infra.workspace_store import list_workspace_change_entries as list_workspace_change_entry_rows
from fastapi_service.infra.workspace_store import list_workspace_changes as list_workspace_change_rows
from fastapi_service.infra.workspace_store import list_workspace_inventory as list_workspace_inventory_rows
from fastapi_service.infra.workspace_store import next_snapshot_sequence as next_snapshot_sequence_value
from fastapi_service.infra.workspace_store import replace_change_attributions as replace_change_attribution_rows
from fastapi_service.modules.reviews.models import (
    EnvironmentProbe,
    EnvironmentProbeFile,
    EnvironmentProbeRuleSet,
    EnvironmentProbeWritePolicy,
    ReviewBindingCandidate,
)
from fastapi_service.modules.workspace.models import (
    Snapshot,
    WorkspaceChange,
    WorkspaceChangeAttribution,
    WorkspaceChangedFile,
    WorkspaceChangedFileActivity,
    WorkspaceChangeEntry,
    WorkspaceChangeSummary,
    WorkspaceFileDetail,
    WorkspaceFileDiff,
    WorkspaceGitHistoryEntry,
    WorkspaceInventoryItem,
)
from fastapi_service.modules.workspace.schemas import WorkspaceChangeAttributionRequest
from fastapi_service.services.exceptions import EntityNotFoundError, ValidationError

KNOWN_OPENCLAW_FILES = {
    "SOUL.md": {
        "layer": "identity",
        "governs": ["tone", "values", "style", "boundaries"],
        "write_risk": "high",
        "baseline_lines": 37,
    },
    "IDENTITY.md": {
        "layer": "identity",
        "governs": ["name", "persona", "appearance"],
        "write_risk": "high",
        "baseline_lines": 24,
    },
    "USER.md": {
        "layer": "context",
        "governs": ["user-prefs", "timezone", "conventions"],
        "write_risk": "medium",
        "baseline_lines": 20,
    },
    "MEMORY.md": {"layer": "context", "governs": ["long-term-memory"], "write_risk": "medium", "baseline_lines": 10},
    "AGENTS.md": {
        "layer": "protocol",
        "governs": ["rules", "permissions", "workflows", "red-lines"],
        "write_risk": "high",
        "baseline_lines": 210,
    },
    "TOOLS.md": {
        "layer": "protocol",
        "governs": ["device-config", "search-prefs", "local-env"],
        "write_risk": "low",
        "baseline_lines": 41,
    },
    "HEARTBEAT.md": {
        "layer": "protocol",
        "governs": ["periodic-checks", "proactive-tasks"],
        "write_risk": "low",
        "baseline_lines": 10,
    },
    "BOOTSTRAP.md": {"layer": "protocol", "governs": ["first-run-setup"], "write_risk": "low", "baseline_lines": 30},
}

KNOWN_OPENCLAW_PATTERNS = {
    "memory/": {"layer": "context", "governs": ["daily-logs", "short-term-memory"], "write_risk": "low"},
    "skills/evolution/": {
        "status_override": "skill-owned",
        "layer": "capability",
        "governs": ["evolution-logic"],
        "write_risk": "medium",
    },
    "skills/": {"layer": "capability", "governs": ["skill-logic"], "write_risk": "medium"},
}

PLACEHOLDER_MARKERS = {
    "_(待定)_",
    "_(optional)_",
    "_(未设置)_",
    "Fill this in",
    "Add whatever helps",
    "_(What do they care about?",
    "Make it yours",
    "This is a starting point",
}

IdFactory = Callable[[str], str]
SessionFactory = Callable[[], Session]


@dataclass
class SnapshotBaseline:
    storage_kind: str
    git_root: str | None
    commit_hash: str
    summary: str


class WorkspaceService:
    def __init__(
        self,
        *,
        id_factory: IdFactory,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._id = id_factory
        self._session_factory = session_factory or get_session

    @contextmanager
    def _session_scope(self, session=None):
        if session is not None:
            yield session
        else:
            s = self._session_factory()
            try:
                yield s
            finally:
                s.close()

    def list_workspace_inventory(
        self, instance_id: str, session: Session | None = None
    ) -> list[WorkspaceInventoryItem]:
        with self._session_scope(session) as db_session:
            return list_workspace_inventory_rows(db_session, instance_id)

    def workspace_file_diff(
        self, instance_id: str, relative_path: str, commit_hash: str, session: Session | None = None
    ) -> WorkspaceFileDiff:
        target_path = str(relative_path or "").strip().lstrip("/")
        commit = str(commit_hash or "").strip()
        if not target_path:
            raise ValidationError("path is required")
        if not commit:
            raise ValidationError("commit is required")
        inventory = {item.relative_path: item for item in self.list_workspace_inventory(instance_id, session=session)}
        if target_path not in inventory:
            raise EntityNotFoundError("workspace file not found")
        repo_root = self._history_repo_root(instance_id, session=session)
        if not repo_root:
            raise EntityNotFoundError("git history not available")
        try:
            patch = self._run_git(["show", "--stat", "--patch", commit, "--", target_path], cwd=repo_root)
        except Exception as exc:
            raise EntityNotFoundError(f"diff not available: {exc}") from exc
        return WorkspaceFileDiff(path=target_path, commit=commit, patch=patch)

    def workspace_file_detail(
        self, instance_id: str, relative_path: str, history_limit: int = 10, session: Session | None = None
    ) -> WorkspaceFileDetail:
        target_path = str(relative_path or "").strip().lstrip("/")
        if not target_path:
            raise ValidationError("path is required")
        inventory = {item.relative_path: item for item in self.list_workspace_inventory(instance_id, session=session)}
        item = inventory.get(target_path)
        if not item:
            raise EntityNotFoundError("workspace file not found")
        env_probe = self._instance_env_probe(instance_id, session=session)
        registry = {entry.path: entry for entry in env_probe.file_registry}
        registry_entry = registry.get(target_path)

        repo_root = self._history_repo_root(instance_id, session=session)
        git_history = self._git_file_history(repo_root, target_path, limit=history_limit)

        with self._session_scope(session) as db_session:
            workspace_change_rows = list_file_workspace_changes(db_session, instance_id, target_path, limit=20)
            mutation_rows = list_file_review_mutations(db_session, instance_id, target_path, limit=20)
            expression_rows = list_file_expressions(db_session, instance_id, target_path, limit=20)

        workspace_changes = [self._workspace_change_with_entries(row, session=session) for row in workspace_change_rows]
        return WorkspaceFileDetail(
            path=target_path,
            classification=item.classification,
            file_kind=item.file_kind,
            size_bytes=item.size_bytes,
            scan_at=item.scan_at,
            status=registry_entry.status if registry_entry else None,
            layer=registry_entry.layer if registry_entry else None,
            role=registry_entry.role if registry_entry else None,
            write_risk=registry_entry.write_risk if registry_entry else None,
            write_policy=registry_entry.write_policy if registry_entry else None,
            git_history=git_history,
            workspace_change_count=len(workspace_changes),
            review_mutation_count=len(mutation_rows),
            expression_count=len(expression_rows),
            workspace_changes=workspace_changes,
            review_mutations=mutation_rows,
            expressions=expression_rows,
        )

    def list_snapshots(
        self, instance_id: str, kind: str | None = None, session: Session | None = None
    ) -> list[Snapshot]:
        with self._session_scope(session) as db_session:
            return list_snapshot_rows(db_session, instance_id, kind)

    def _latest_snapshot(self, instance_id: str, kind: str, session: Session | None = None) -> Snapshot | None:
        with self._session_scope(session) as db_session:
            return latest_snapshot_row(db_session, instance_id, kind)

    def _next_snapshot_sequence(self, instance_id: str, kind: str, session: Session | None = None) -> int:
        with self._session_scope(session) as db_session:
            return next_snapshot_sequence_value(db_session, instance_id, kind)

    def _insert_snapshot_row(
        self,
        *,
        instance_id: str,
        kind: str,
        sequence: int,
        storage_kind: str,
        workspace_root: str,
        git_root: str | None,
        commit_hash: str,
        parent_commit: str | None,
        review_id: str | None,
        trigger_kind: str,
        summary: str,
        created_at: int,
        session: Session | None = None,
    ) -> Snapshot:
        payload = Snapshot(
            id=self._id("snap"),
            instance_id=instance_id,
            kind=kind,
            sequence=sequence,
            storage_kind=storage_kind,
            workspace_root=workspace_root,
            git_root=git_root,
            commit_hash=commit_hash,
            parent_commit=parent_commit,
            review_id=review_id,
            trigger_kind=trigger_kind or "",
            summary=summary or "",
            created_at=created_at,
        )
        with self._session_scope(session) as db_session:
            return create_snapshot_record(db_session, payload)

    def _workspace_change_with_entries(self, row: WorkspaceChange, session: Session | None = None) -> WorkspaceChange:
        return row.model_copy(update={"entries": self.list_workspace_change_entries(row.id, session=session)})

    def list_workspace_changes(
        self, instance_id: str, limit: int = 20, session: Session | None = None
    ) -> list[WorkspaceChange]:
        with self._session_scope(session) as db_session:
            rows = list_workspace_change_rows(db_session, instance_id, limit)
        return [self._workspace_change_with_entries(row, session=session) for row in rows]

    def list_change_attributions(
        self, instance_id: str, change_id: str, session: Session | None = None
    ) -> list[WorkspaceChangeAttribution]:
        with self._session_scope(session) as db_session:
            return list_change_attribution_rows(db_session, instance_id, change_id)

    def list_workspace_change_entries(
        self, change_id: str, session: Session | None = None
    ) -> list[WorkspaceChangeEntry]:
        with self._session_scope(session) as db_session:
            rows = list_workspace_change_entry_rows(db_session, change_id)
        return [
            WorkspaceChangeEntry.model_validate(
                {**row.model_dump(), **self._workspace_change_activity_meta(row.target_file).model_dump()}
            )
            for row in rows
        ]

    def capture_workspace_change(
        self, instance_id: str, base_kind: str = "baseline", session: Session | None = None
    ) -> WorkspaceChange:
        instance = self._instance_row(instance_id, session=session)
        workspace_root = Path(instance.workspace_root or default_workspace_root()).expanduser().resolve()
        baseline = self._latest_snapshot(instance_id, base_kind, session=session)
        if not baseline:
            raise EntityNotFoundError(f"{base_kind} snapshot not found")
        head_commit, files = self._workspace_git_diff_summary(workspace_root, baseline.commit_hash)
        visible_files = [item for item in files if item.activity_visible is not False]
        summary = WorkspaceChangeSummary(
            changed_files=visible_files,
            p0_files=[item.path for item in visible_files if item.priority == "p0"],
            changed_file_count=len(visible_files),
            total_changed_file_count=len(files),
            hidden_file_count=max(len(files) - len(visible_files), 0),
        )
        with self._session_scope(session) as db_session:
            existing = find_workspace_change(
                db_session,
                instance_id=instance_id,
                base_kind=base_kind,
                base_commit=baseline.commit_hash,
                head_commit=head_commit,
                summary=summary,
            )
            if existing:
                return self._workspace_change_with_entries(existing, session=session)
            row = create_workspace_change_record(
                db_session,
                WorkspaceChange(
                    id=self._id("wchg"),
                    instance_id=instance_id,
                    base_kind=base_kind,
                    storage_kind=baseline.storage_kind,
                    base_commit=baseline.commit_hash,
                    head_commit=head_commit,
                    summary=summary,
                    created_at=utc_now_unix(),
                    entries=[],
                ),
            )
            entries = [
                entry.model_copy(update={"workspace_change_id": row.id})
                for entry in self._build_workspace_change_entries(
                    instance_id, workspace_root, baseline.commit_hash, files
                )
            ]
            create_workspace_change_entries(db_session, entries)
            row = row.model_copy(update={"entries": entries})
        return row

    def _capture_baseline_workspace_change(
        self,
        instance_id: str,
        *,
        base_commit: str,
        head_commit: str,
        workspace_root: Path,
        storage_kind: str,
        session: Session | None = None,
    ) -> WorkspaceChange:
        _, files = self._workspace_git_diff_summary(
            workspace_root, base_commit, head_commit=head_commit, anchor_only=True
        )
        visible_files = [item for item in files if item.activity_visible is not False]
        summary = WorkspaceChangeSummary(
            changed_files=visible_files,
            p0_files=[item.path for item in visible_files if item.priority == "p0"],
            changed_file_count=len(visible_files),
            total_changed_file_count=len(files),
            hidden_file_count=max(len(files) - len(visible_files), 0),
        )
        with self._session_scope(session) as db_session:
            existing = find_workspace_change(
                db_session,
                instance_id=instance_id,
                base_kind="baseline",
                base_commit=base_commit,
                head_commit=head_commit,
                summary=summary,
            )
            if existing:
                return self._workspace_change_with_entries(existing, session=session)
            row = create_workspace_change_record(
                db_session,
                WorkspaceChange(
                    id=self._id("wchg"),
                    instance_id=instance_id,
                    base_kind="baseline",
                    storage_kind=storage_kind,
                    base_commit=base_commit,
                    head_commit=head_commit,
                    summary=summary,
                    created_at=utc_now_unix(),
                    entries=[],
                ),
            )
            entries = [
                entry.model_copy(update={"workspace_change_id": row.id})
                for entry in self._build_workspace_change_entries(
                    instance_id, workspace_root, base_commit, files, head_commit=head_commit
                )
            ]
            create_workspace_change_entries(db_session, entries)
            row = row.model_copy(update={"entries": entries})
        return row

    def _capture_review_baseline_snapshot(
        self, instance_id: str, review_reason: str | None = None, session: Session | None = None
    ) -> Snapshot:
        instance = self._instance_row(instance_id, session=session)
        workspace_root = Path(instance.workspace_root or default_workspace_root()).expanduser().resolve()
        baseline = self._ensure_baseline(workspace_root)
        previous = self._latest_snapshot(instance_id, "baseline", session=session)
        sequence = self._next_snapshot_sequence(instance_id, "baseline", session=session)
        commit_hash = self._create_review_baseline_commit(workspace_root, sequence)
        return self._insert_snapshot_row(
            instance_id=instance_id,
            kind="baseline",
            sequence=sequence,
            storage_kind=baseline.storage_kind,
            workspace_root=str(workspace_root),
            git_root=baseline.git_root,
            commit_hash=commit_hash,
            parent_commit=(previous.commit_hash if previous else None),
            review_id=None,
            trigger_kind=(review_reason or "review").strip() or "review",
            summary="review baseline commit over anchor files",
            created_at=utc_now_unix(),
            session=session,
        )

    def replace_change_attributions(
        self, change_id: str, request: WorkspaceChangeAttributionRequest, session: Session | None = None
    ) -> list[WorkspaceChangeAttribution]:
        with self._session_scope(session) as db_session:
            row = get_workspace_change_record(db_session, change_id, request.instance_id)
            if not row:
                raise EntityNotFoundError("workspace change not found")
            now = utc_now_unix()
            rows = [
                WorkspaceChangeAttribution(
                    id=self._id("attr"),
                    workspace_change_id=change_id,
                    instance_id=request.instance_id,
                    target_type=item.target_type,
                    target_id=item.target_id,
                    reason_text=item.reason_text,
                    confidence=item.confidence,
                    created_at=now,
                )
                for item in request.attributions
            ]
            return replace_change_attribution_rows(db_session, change_id, request.instance_id, rows)

    def _instance_row(self, instance_id: str, session: Session | None = None) -> InstanceRecord:
        with self._session_scope(session) as db_session:
            row = get_instance_row(db_session, instance_id)
        if not row:
            raise EntityNotFoundError("instance not found")
        return row

    def _instance_env_probe(self, instance_id: str, session: Session | None = None) -> EnvironmentProbe:
        with self._session_scope(session) as db_session:
            row = get_instance_row(db_session, instance_id)
            if not row:
                raise EntityNotFoundError("instance not found")
            probe = get_instance_env_probe(db_session, instance_id)
        return EnvironmentProbe.model_validate(probe)

    def _history_repo_root(self, instance_id: str, session: Session | None = None) -> Path | None:
        row = self._instance_row(instance_id, session=session)
        workspace_root = Path(row.workspace_root or default_workspace_root()).expanduser().resolve()
        if (workspace_root / ".git").exists():
            return workspace_root
        return None

    def _git_file_history(
        self, repo_root: Path | None, relative_path: str, limit: int = 10
    ) -> list[WorkspaceGitHistoryEntry]:
        if not repo_root:
            return []
        try:
            output = self._run_git(
                ["log", f"-n{limit}", "--date=unix", "--format=%H%x1f%ct%x1f%s", "--", relative_path],
                cwd=repo_root,
            )
        except Exception:
            return []
        rows: list[WorkspaceGitHistoryEntry] = []
        for raw_line in output.splitlines():
            if not raw_line.strip():
                continue
            parts = raw_line.split("\x1f")
            if len(parts) != 3:
                continue
            rows.append(
                WorkspaceGitHistoryEntry(
                    commit=parts[0],
                    created_at=int(parts[1] or 0),
                    summary=parts[2],
                )
            )
        return rows

    def _review_anchor_pathspecs(self) -> list[str]:
        return [*sorted(KNOWN_OPENCLAW_FILES.keys()), "skills"]

    def _is_review_anchor_path(self, relative_path: str) -> bool:
        path = str(relative_path or "").strip()
        if not path:
            return False
        if Path(path).name in KNOWN_OPENCLAW_FILES:
            return True
        return path == "skills" or path.startswith("skills/")

    def _git_output_lines(self, args: list[str], cwd: Path) -> list[str]:
        output = self._run_git(args, cwd=cwd)
        return [line.strip() for line in output.splitlines() if line.strip()]

    def _list_changed_anchor_paths(self, workspace_root: Path, base_commit: str | None = None) -> list[str]:
        pathspecs = self._review_anchor_pathspecs()
        changed: set[str] = set()
        diff_args = ["-C", str(workspace_root), "diff", "--name-only"]
        if base_commit:
            diff_args.append(base_commit)
        if pathspecs:
            diff_args.extend(["--", *pathspecs])
        changed.update(self._git_output_lines(diff_args, cwd=workspace_root))
        deleted_args = ["-C", str(workspace_root), "ls-files", "--deleted"]
        if pathspecs:
            deleted_args.extend(["--", *pathspecs])
        changed.update(self._git_output_lines(deleted_args, cwd=workspace_root))
        untracked_args = ["-C", str(workspace_root), "ls-files", "--others", "--exclude-standard"]
        if pathspecs:
            untracked_args.extend(["--", *pathspecs])
        changed.update(self._git_output_lines(untracked_args, cwd=workspace_root))
        return sorted(path for path in changed if self._is_review_anchor_path(path))

    def _git_head_ref(self, workspace_root: Path) -> str:
        try:
            ref = self._run_git(
                ["-C", str(workspace_root), "symbolic-ref", "--quiet", "HEAD"], cwd=workspace_root
            ).strip()
        except Exception:
            return "HEAD"
        return ref or "HEAD"

    def _key_file_priority(self, relative_path: str) -> str:
        name = Path(relative_path).name
        suffix = Path(relative_path).suffix.lower()
        if name in {"package.json", "package-lock.json", "requirements.txt", "pyproject.toml", "openclaw.plugin.json"}:
            return "p0"
        if suffix in {".js", ".jsx", ".ts", ".tsx", ".py", ".go", ".rs", ".java", ".rb", ".php", ".sh"}:
            return "p0"
        if suffix in {".json", ".yml", ".yaml", ".toml", ".ini", ".env"}:
            return "p1"
        if suffix in {".md", ".txt"}:
            return "p2"
        return "p3"

    def _parse_name_status(self, output: str) -> list[WorkspaceChangedFile]:
        items: list[WorkspaceChangedFile] = []
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            parts = line.split("\t")
            status = parts[0].strip()
            path = parts[-1].strip() if len(parts) > 1 else ""
            if not path:
                continue
            items.append(
                WorkspaceChangedFile(
                    path=path,
                    status=status,
                    priority=self._key_file_priority(path),
                )
            )
        return items

    def _workspace_change_activity_meta(self, relative_path: str) -> WorkspaceChangedFileActivity:
        classification = self._classify_workspace_path(relative_path)
        activity_status = "needs_review"
        layer = None
        if classification == "runtime":
            activity_status = "runtime"
        elif classification != "workspace_file":
            activity_status = classification
        else:
            for pattern, meta in KNOWN_OPENCLAW_PATTERNS.items():
                if relative_path.startswith(pattern):
                    activity_status = str(meta.get("status_override") or "user-owned")
                    layer = str(meta.get("layer") or "") or None
                    break
            else:
                file_meta = KNOWN_OPENCLAW_FILES.get(Path(relative_path).name)
                if file_meta:
                    activity_status = "evolvable"
                    layer = str(file_meta.get("layer") or "") or None
                else:
                    activity_status = "needs_review"

        activity_visible = activity_status in {"evolvable", "user-owned", "needs_review"}
        if activity_status == "evolvable":
            activity_category = "evolution"
        elif activity_visible:
            activity_category = "user"
        else:
            activity_category = "ignored"
        return WorkspaceChangedFileActivity(
            activity_status=activity_status,
            activity_category=activity_category,
            activity_visible=activity_visible,
            activity_layer=layer,
        )

    def _read_workspace_file_text(self, workspace_root: Path, relative_path: str) -> str | None:
        path = workspace_root / relative_path
        if not path.exists() or path.is_dir():
            return None
        try:
            return path.read_text(encoding="utf8")
        except Exception:
            return None

    def _git_show_file_text(self, repo_root: Path, commit_hash: str, relative_path: str) -> str | None:
        try:
            return self._run_git(["show", f"{commit_hash}:{relative_path}"], cwd=repo_root)
        except Exception:
            return None

    def _clip_text(self, value: str | None, max_lines: int = 12, max_chars: int = 800) -> str | None:
        if value is None:
            return None
        text = str(value)
        if len(text) > max_chars:
            text = text[:max_chars] + "\n..."
        lines = text.splitlines()
        if len(lines) > max_lines:
            lines = lines[:max_lines] + ["..."]
        return "\n".join(lines).strip() or None

    def _workspace_change_entry_description(self, status: str, path: str) -> str:
        normalized = str(status or "").upper()
        if normalized.startswith("A") or normalized == "??":
            return f"用户新增文件 {path}"
        if normalized.startswith("D"):
            return f"用户删除文件 {path}"
        if normalized.startswith("R"):
            return f"用户重命名或替换文件 {path}"
        return f"用户修改文件 {path}"

    def _build_workspace_change_entries(
        self,
        instance_id: str,
        workspace_root: Path,
        base_commit: str,
        files: list[WorkspaceChangedFile],
        head_commit: str | None = None,
    ) -> list[WorkspaceChangeEntry]:
        repo_root = workspace_root
        rows: list[WorkspaceChangeEntry] = []
        now = utc_now_unix()
        for item in files:
            relative_path = item.path
            status = item.status
            before_text = self._git_show_file_text(repo_root, base_commit, relative_path)
            after_text = (
                self._git_show_file_text(repo_root, head_commit, relative_path)
                if head_commit
                else self._read_workspace_file_text(workspace_root, relative_path)
            )
            rows.append(
                WorkspaceChangeEntry(
                    id=self._id("wentry"),
                    workspace_change_id="",
                    instance_id=instance_id,
                    target_file=relative_path,
                    status=status,
                    description=self._workspace_change_entry_description(status, relative_path),
                    before_text=self._clip_text(before_text),
                    after_text=self._clip_text(after_text),
                    created_at=now,
                )
            )
        return rows

    def _workspace_git_diff_summary(
        self,
        workspace_root: Path,
        base_commit: str,
        head_commit: str | None = None,
        *,
        anchor_only: bool = False,
    ) -> tuple[str | None, list[WorkspaceChangedFile]]:
        current_head = head_commit or self._git_current_head(workspace_root)
        pathspecs = self._review_anchor_pathspecs() if anchor_only else []
        diff_args = ["-C", str(workspace_root), "diff", "--name-status", base_commit]
        if head_commit:
            diff_args.append(head_commit)
        if pathspecs:
            diff_args.extend(["--", *pathspecs])
        diff_output = self._run_git(diff_args, cwd=workspace_root)
        files = self._parse_name_status(diff_output)
        if not head_commit:
            untracked_args = ["-C", str(workspace_root), "ls-files", "--others", "--exclude-standard"]
            if pathspecs:
                untracked_args.extend(["--", *pathspecs])
            untracked_output = self._run_git(untracked_args, cwd=workspace_root)
            for raw_path in untracked_output.splitlines():
                path = raw_path.strip()
                if not path:
                    continue
                files.append(WorkspaceChangedFile(path=path, status="??", priority=self._key_file_priority(path)))
        deduped: dict[str, WorkspaceChangedFile] = {}
        for item in files:
            deduped[item.path] = item.model_copy(update=self._workspace_change_activity_meta(item.path).model_dump())
        return current_head, list(sorted(deduped.values(), key=lambda item: (item.priority, item.path)))

    def _scan_workspace_inventory(self, workspace_root: Path, scan_at: int) -> list[WorkspaceInventoryItem]:
        items: list[WorkspaceInventoryItem] = []
        for path in sorted(workspace_root.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(workspace_root).as_posix()
            classification = self._classify_workspace_path(rel)
            if classification == "git_metadata":
                continue
            try:
                size_bytes = path.stat().st_size
            except OSError:
                size_bytes = 0
            items.append(
                WorkspaceInventoryItem(
                    relative_path=rel,
                    file_kind="symlink" if path.is_symlink() else "file",
                    classification=classification,
                    size_bytes=size_bytes,
                    scan_at=scan_at,
                )
            )
        return items

    def _classify_workspace_path(self, relative_path: str) -> str:
        parts = [part for part in relative_path.split("/") if part]
        if not parts:
            return "workspace_file"
        if any(part == ".git" for part in parts):
            return "git_metadata"
        if parts[0] == ".openclaw":
            return "runtime"
        if parts[0] in {"node_modules", ".venv", "venv", "__pycache__"}:
            return "generated_or_dependency"
        if relative_path == "openclaw.json":
            return "runtime"
        if parts[-1].endswith((".pyc", ".pyo")):
            return "generated_or_dependency"
        return "workspace_file"

    def _read_text_for_probe(self, workspace_root: Path, relative_path: str) -> str:
        try:
            return (workspace_root / relative_path).read_text(encoding="utf8", errors="replace")
        except Exception:
            return ""

    def _line_count_for_probe(self, workspace_root: Path, relative_path: str) -> int:
        return len(self._read_text_for_probe(workspace_root, relative_path).splitlines())

    def _has_placeholder_markers(self, workspace_root: Path, relative_path: str) -> bool:
        content = self._read_text_for_probe(workspace_root, relative_path)
        return any(marker in content for marker in PLACEHOLDER_MARKERS)

    def _registry_entry_status(
        self, workspace_root: Path, relative_path: str, classification: str, previous_status: str | None
    ) -> tuple[str, dict | None]:
        if classification == "runtime":
            return "runtime", None
        if classification != "workspace_file":
            return classification, None
        for pattern, meta in KNOWN_OPENCLAW_PATTERNS.items():
            if relative_path.startswith(pattern):
                if meta.get("status_override"):
                    return str(meta["status_override"]), meta
                return "user-owned", meta
        file_meta = KNOWN_OPENCLAW_FILES.get(Path(relative_path).name)
        if file_meta:
            lines = self._line_count_for_probe(workspace_root, relative_path)
            raw_baseline_lines = file_meta.get("baseline_lines")
            baseline_lines = int(raw_baseline_lines) if isinstance(raw_baseline_lines, int | float | str) else 0
            is_template = self._has_placeholder_markers(workspace_root, relative_path) or lines < baseline_lines * 1.2
            status = "evolvable" if is_template else "user-owned"
            if previous_status == "user-owned" and status == "evolvable":
                status = "user-owned"
            return status, file_meta
        return "needs_review", None

    def _previous_registry_statuses(self, instance_id: str) -> dict[str, str]:
        with self._session_scope() as session:
            row = get_instance_row(session, instance_id)
            if not row:
                return {}
            probe = self._instance_env_probe(instance_id, session=session)
        rows = probe.file_registry
        result: dict[str, str] = {}
        for item in rows:
            path = str(item.path or "").strip()
            status = str(item.status or "").strip()
            if path and status:
                result[path] = status
        return result

    def _binding_candidates(self, file_registry: list[EnvironmentProbeFile]) -> list[ReviewBindingCandidate]:
        registry_by_path = {
            item.path: item for item in file_registry if item.status in {"evolvable", "user-owned", "needs_review"}
        }
        files = set(registry_by_path)
        candidates: list[ReviewBindingCandidate] = []
        if "index.js" in files:
            candidates.append(
                ReviewBindingCandidate(
                    binding_ref="hook.before_prompt_build",
                    target_file="index.js",
                    kind="prompt_hook",
                    confidence="high",
                )
            )
            candidates.append(
                ReviewBindingCandidate(
                    binding_ref="hook.after_tool_call",
                    target_file="index.js",
                    kind="signal_hook",
                    confidence="high",
                )
            )
        for path in sorted(files):
            name = Path(path).name
            if name in KNOWN_OPENCLAW_FILES:
                candidates.append(
                    ReviewBindingCandidate(
                        binding_ref="workspace.prompt_instructions",
                        target_file=path,
                        kind="workspace_file",
                        confidence="high"
                        if name
                        in {
                            "AGENTS.md",
                            "SOUL.md",
                            "IDENTITY.md",
                            "USER.md",
                            "TOOLS.md",
                            "MEMORY.md",
                            "HEARTBEAT.md",
                            "BOOTSTRAP.md",
                        }
                        else "medium",
                    )
                )
                continue
            if (
                "/" not in path
                and path.endswith((".md", ".txt"))
                and ("prompt" in path.lower() or "instruction" in path.lower())
            ):
                candidates.append(
                    ReviewBindingCandidate(
                        binding_ref="workspace.prompt_instructions",
                        target_file=path,
                        kind="workspace_file",
                        confidence="medium",
                    )
                )
        deduped: list[ReviewBindingCandidate] = []
        seen: set[tuple[str, str]] = set()
        for item in candidates:
            key = (item.binding_ref, item.target_file)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(item)
        return deduped[:12]

    def _editable_files_from_registry(self, file_registry: list[EnvironmentProbeFile]) -> list[EnvironmentProbeFile]:
        binding_targets = {item.target_file for item in self._binding_candidates(file_registry)}
        ranked: list[tuple[int, EnvironmentProbeFile]] = []
        for item in file_registry:
            if item.status in {
                "runtime",
                "plugin_private",
                "generated_or_dependency",
                "git_metadata",
                "skill-owned",
            }:
                continue
            path = str(item.path)
            name = Path(path).name
            is_core_openclaw_file = name in KNOWN_OPENCLAW_FILES
            sort_bucket = (
                0
                if is_core_openclaw_file
                else 1
                if item.role == "plugin_hook_entry"
                else 2
                if path in binding_targets
                else 3
            )
            ranked.append((sort_bucket, item))
        ranked.sort(key=lambda row: (row[0], row[1].priority, row[1].path))
        return [item for _, item in ranked[:50]]

    def _build_env_probe(
        self,
        instance_id: str,
        workspace_root: Path,
        inventory: list[WorkspaceInventoryItem],
        baseline: SnapshotBaseline,
    ) -> EnvironmentProbe:
        previous_statuses = self._previous_registry_statuses(instance_id)
        file_registry: list[EnvironmentProbeFile] = []
        for item in inventory:
            path = item.relative_path
            classification = item.classification
            previous_status = previous_statuses.get(path)
            status, semantic_meta = self._registry_entry_status(workspace_root, path, classification, previous_status)
            layer = None
            governs: list[str] = []
            write_risk = "unknown"
            role = "workspace_file"
            if path == "index.js":
                role = "plugin_hook_entry"
            elif Path(path).name == "AGENTS.md":
                role = "agent_instructions"
            elif path.endswith("SKILL.md"):
                role = "skill_prompt"
            elif path.endswith((".md", ".txt")) and ("prompt" in path.lower() or "instruction" in path.lower()):
                role = "prompt_doc"
            if semantic_meta:
                layer = semantic_meta.get("layer")
                governs = list(semantic_meta.get("governs") or [])
                write_risk = str(semantic_meta.get("write_risk") or "unknown")
            write_policy_map = {
                "evolvable": "section-edit",
                "user-owned": "append-only",
                "skill-owned": "skill-managed",
                "needs_review": "blocked-until-classified",
                "runtime": "read-only",
            }
            file_registry.append(
                EnvironmentProbeFile(
                    path=path,
                    classification=classification,
                    status=status,
                    layer=layer,
                    governs=governs,
                    write_risk=write_risk,
                    write_policy=write_policy_map.get(status, "blocked-until-classified"),
                    priority=self._key_file_priority(path),
                    role=role,
                    size_bytes=item.size_bytes,
                )
            )
        editable_files = self._editable_files_from_registry(file_registry)
        binding_candidates = self._binding_candidates(file_registry)
        status_counts: dict[str, int] = {}
        for registry_item in file_registry:
            status_counts[registry_item.status] = status_counts.get(registry_item.status, 0) + 1
        return EnvironmentProbe(
            workspace_root=str(workspace_root),
            git_root=baseline.git_root,
            baseline_commit=baseline.commit_hash,
            status_counts=status_counts,
            file_registry=file_registry,
            editable_files=editable_files,
            binding_candidates=binding_candidates,
            rules=EnvironmentProbeRuleSet(
                do_not_invent_paths=True,
                target_file_must_exist_in_workspace=True,
                prefer_prompt_hook_or_real_workspace_file=True,
                preserve_user_owned_on_reinit=True,
            ),
            write_policy=EnvironmentProbeWritePolicy(
                evolvable="section-edit",
                user_owned="append-only",
                skill_owned="skill-managed",
                needs_review="blocked-until-classified",
                runtime="read-only",
            ),
        )

    def _ensure_baseline(self, workspace_root: Path) -> SnapshotBaseline:
        git_root = self._workspace_git_root(workspace_root)
        if git_root != workspace_root:
            raise ValidationError("workspace_root must be a local workspace git repo")
        head_commit = self._git_current_head(workspace_root)
        if not head_commit:
            head_commit = self._ensure_initial_workspace_head(workspace_root)
        if not head_commit:
            raise ValidationError("workspace git repo has no HEAD commit")
        return SnapshotBaseline(
            storage_kind="workspace_git",
            git_root=str(git_root),
            commit_hash=head_commit,
            summary="workspace baseline from workspace git HEAD",
        )

    def _workspace_git_root(self, workspace_root: Path) -> Path | None:
        try:
            output = subprocess.check_output(
                ["git", "-C", str(workspace_root), "rev-parse", "--show-toplevel"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None
        if not output:
            return None
        return Path(output).resolve()

    def _git_current_head(self, git_root: Path) -> str | None:
        try:
            output = subprocess.check_output(
                ["git", "-C", str(git_root), "rev-parse", "HEAD"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None
        return output or None

    def _ensure_initial_workspace_head(self, git_root: Path) -> str | None:
        try:
            subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(git_root),
                    "-c",
                    "user.name=OpenClaw",
                    "-c",
                    "user.email=openclaw@local",
                    "add",
                    "-A",
                ],
                stderr=subprocess.STDOUT,
                text=True,
            )
            subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(git_root),
                    "-c",
                    "user.name=OpenClaw",
                    "-c",
                    "user.email=openclaw@local",
                    "commit",
                    "--allow-empty",
                    "-m",
                    "openclaw baseline",
                ],
                stderr=subprocess.STDOUT,
                text=True,
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None
        return self._git_current_head(git_root)

    def _create_review_baseline_commit(self, workspace_root: Path, sequence: int) -> str:
        current_head = self._git_current_head(workspace_root)
        if not current_head:
            current_head = self._ensure_initial_workspace_head(workspace_root)
        if not current_head:
            raise ValidationError("workspace git repo has no HEAD commit")

        changed_paths = self._list_changed_anchor_paths(workspace_root)
        head_ref = self._git_head_ref(workspace_root)
        with tempfile.TemporaryDirectory(prefix="openclaw-baseline-index-") as temp_dir:
            index_path = str(Path(temp_dir) / "index")
            env = {
                **os.environ,
                "GIT_INDEX_FILE": index_path,
                "GIT_AUTHOR_NAME": "OpenClaw",
                "GIT_AUTHOR_EMAIL": "openclaw@local",
                "GIT_COMMITTER_NAME": "OpenClaw",
                "GIT_COMMITTER_EMAIL": "openclaw@local",
            }
            subprocess.check_output(
                ["git", "-C", str(workspace_root), "read-tree", current_head],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            )
            for relative_path in changed_paths:
                absolute_path = workspace_root / relative_path
                if absolute_path.exists():
                    subprocess.check_output(
                        ["git", "-C", str(workspace_root), "add", "--", relative_path],
                        stderr=subprocess.STDOUT,
                        text=True,
                        env=env,
                    )
                else:
                    subprocess.check_output(
                        [
                            "git",
                            "-C",
                            str(workspace_root),
                            "rm",
                            "--cached",
                            "-r",
                            "--ignore-unmatch",
                            "--",
                            relative_path,
                        ],
                        stderr=subprocess.STDOUT,
                        text=True,
                        env=env,
                    )
            tree_hash = subprocess.check_output(
                ["git", "-C", str(workspace_root), "write-tree"],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            ).strip()
            commit_hash = subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(workspace_root),
                    "commit-tree",
                    tree_hash,
                    "-p",
                    current_head,
                    "-m",
                    f"openclaw baseline {sequence}",
                ],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            ).strip()
        subprocess.check_output(
            ["git", "-C", str(workspace_root), "update-ref", head_ref, commit_hash, current_head],
            stderr=subprocess.STDOUT,
            text=True,
        )
        return commit_hash

    def _run_git(self, args: list[str], cwd: Path) -> str:
        return subprocess.check_output(["git", *args], cwd=str(cwd), stderr=subprocess.STDOUT, text=True)

    def _commit_selected_workspace_paths(
        self, workspace_root: Path, relative_paths: list[str], message: str
    ) -> str | None:
        current_head = self._git_current_head(workspace_root)
        if not current_head:
            current_head = self._ensure_initial_workspace_head(workspace_root)
        if not current_head:
            raise ValidationError("workspace git repo has no HEAD commit")
        selected_paths = sorted({path for path in relative_paths if str(path or "").strip()})
        if not selected_paths:
            return None

        head_ref = self._git_head_ref(workspace_root)
        with tempfile.TemporaryDirectory(prefix="openclaw-expression-index-") as temp_dir:
            index_path = str(Path(temp_dir) / "index")
            env = {
                **os.environ,
                "GIT_INDEX_FILE": index_path,
                "GIT_AUTHOR_NAME": "OpenClaw",
                "GIT_AUTHOR_EMAIL": "openclaw@local",
                "GIT_COMMITTER_NAME": "OpenClaw",
                "GIT_COMMITTER_EMAIL": "openclaw@local",
            }
            subprocess.check_output(
                ["git", "-C", str(workspace_root), "read-tree", current_head],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            )
            for relative_path in selected_paths:
                absolute_path = workspace_root / relative_path
                if absolute_path.exists():
                    subprocess.check_output(
                        ["git", "-C", str(workspace_root), "add", "--", relative_path],
                        stderr=subprocess.STDOUT,
                        text=True,
                        env=env,
                    )
                else:
                    subprocess.check_output(
                        [
                            "git",
                            "-C",
                            str(workspace_root),
                            "rm",
                            "--cached",
                            "-r",
                            "--ignore-unmatch",
                            "--",
                            relative_path,
                        ],
                        stderr=subprocess.STDOUT,
                        text=True,
                        env=env,
                    )
            tree_hash = subprocess.check_output(
                ["git", "-C", str(workspace_root), "write-tree"],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            ).strip()
            head_tree = subprocess.check_output(
                ["git", "-C", str(workspace_root), "rev-parse", f"{current_head}^{{tree}}"],
                stderr=subprocess.STDOUT,
                text=True,
            ).strip()
            if tree_hash == head_tree:
                return None
            commit_hash = subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(workspace_root),
                    "commit-tree",
                    tree_hash,
                    "-p",
                    current_head,
                    "-m",
                    message,
                ],
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
            ).strip()
        subprocess.check_output(
            ["git", "-C", str(workspace_root), "update-ref", head_ref, commit_hash, current_head],
            stderr=subprocess.STDOUT,
            text=True,
        )
        return commit_hash

    def _instance_workspace_root(self, instance_id: str) -> Path | None:
        row = self._instance_row(instance_id)
        root = str(row.workspace_root or "")
        if not root:
            return None
        path = Path(root).expanduser().resolve()
        return path if path.exists() and path.is_dir() else None
