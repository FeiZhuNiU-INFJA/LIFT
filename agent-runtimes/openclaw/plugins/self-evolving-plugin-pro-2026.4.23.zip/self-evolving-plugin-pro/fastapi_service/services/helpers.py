from __future__ import annotations

import json
import secrets
import shutil
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]


def new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(6)}"


def plugin_version() -> str:
    try:
        raw = json.loads((REPO_ROOT / "package.json").read_text(encoding="utf8"))
    except Exception:
        return ""
    return str(raw.get("version") or "").strip()


def openclaw_version() -> str | None:
    if not shutil.which("openclaw"):
        return None
    try:
        result = subprocess.run(
            ["openclaw", "--version"],
            check=True,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except Exception:
        return None
    value = str(result.stdout or result.stderr or "").strip()
    return value or None


def ecs_instance_id() -> str | None:
    if not shutil.which("curl"):
        return None
    try:
        result = subprocess.run(
            ["curl", "-fsS", "--max-time", "1", "100.96.0.96/latest/instance_id"],
            check=True,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except Exception:
        return None
    value = str(result.stdout or "").strip()
    return value or None


def parse_since_seconds(since_text: str | None) -> int | None:
    value = str(since_text or "").strip().lower()
    if not value:
        return None
    import re

    match = re.fullmatch(r"(\d+)\s*([smhdw])", value)
    if not match:
        return None
    amount = int(match.group(1))
    multipliers = {
        "s": 1,
        "m": 60,
        "h": 3600,
        "d": 24 * 3600,
        "w": 7 * 24 * 3600,
    }
    return amount * multipliers[match.group(2)]
