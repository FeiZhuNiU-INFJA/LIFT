class DomainError(Exception):
    """Base for all domain-specific errors."""


class EntityNotFoundError(DomainError):
    """Raised when a requested entity does not exist."""


class ValidationError(DomainError):
    """Raised when a domain validation rule is violated."""


class ServiceUnavailableError(DomainError):
    """Raised when an external service is unreachable."""
