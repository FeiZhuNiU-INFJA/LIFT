from __future__ import annotations

from typing import Annotated, NamedTuple

from fastapi import Depends, Header, HTTPException, Query, Request
from sqlmodel import Session

from fastapi_service.infra import get_session
from fastapi_service.infra.instances_store import get_instance_by_id, resolve_default_instance_id
from fastapi_service.modules.expressions.service import ExpressionService
from fastapi_service.modules.genes.service import GeneService
from fastapi_service.modules.instances.service import InstanceService
from fastapi_service.modules.reviews.service import ReviewService
from fastapi_service.modules.signals.service import SignalService
from fastapi_service.modules.verification.service import VerificationService
from fastapi_service.modules.workspace.service import WorkspaceService


class AuthHeaders(NamedTuple):
    instance_id: str | None
    instance_token: str | None


def get_db_session():
    session = get_session()
    try:
        yield session
    finally:
        session.close()


DbSessionDep = Annotated[Session, Depends(get_db_session)]


def _require_app_service(request: Request, attr_name: str, label: str):
    service = getattr(request.app.state, attr_name, None)
    if service is None:
        raise HTTPException(status_code=503, detail=f"{label} is not initialized")
    return service


def _service_dep(attr: str, label: str):
    def _get(request: Request):
        return _require_app_service(request, attr, label)

    return _get


def auth_headers(
    instance_id: str | None = Header(default=None, alias="x-openclaw-instance-id"),
    instance_token: str | None = Header(default=None, alias="x-openclaw-instance-token"),
) -> AuthHeaders:
    return AuthHeaders(instance_id=instance_id, instance_token=instance_token)


AuthHeadersDep = Annotated[AuthHeaders, Depends(auth_headers)]
InstanceServiceDep = Annotated[InstanceService, Depends(_service_dep("instance_service", "instance service"))]
SignalServiceDep = Annotated[SignalService, Depends(_service_dep("signal_service", "signal service"))]
GeneServiceDep = Annotated[GeneService, Depends(_service_dep("gene_service", "gene service"))]
ExpressionServiceDep = Annotated[ExpressionService, Depends(_service_dep("expression_service", "expression service"))]
ReviewServiceDep = Annotated[ReviewService, Depends(_service_dep("review_service", "review service"))]
WorkspaceServiceDep = Annotated[WorkspaceService, Depends(_service_dep("workspace_service", "workspace service"))]
VerificationServiceDep = Annotated[
    VerificationService, Depends(_service_dep("verification_service", "verification service"))
]


def assert_instance_access_session(session: Session, headers: AuthHeaders, instance_id: str) -> None:
    if not instance_id:
        raise HTTPException(status_code=400, detail="instance_id is required")
    row = get_instance_by_id(session, instance_id)
    if row is None:
        raise HTTPException(status_code=404, detail="instance not found")
    if headers.instance_id and headers.instance_id != instance_id:
        raise HTTPException(status_code=403, detail="instance header mismatch")
    if headers.instance_token and row.instance_token != headers.instance_token:
        raise HTTPException(status_code=403, detail="invalid instance token")


def resolve_instance_id_session(session: Session, headers: AuthHeaders, explicit_instance_id: str | None = None) -> str:
    if explicit_instance_id:
        return explicit_instance_id
    if headers.instance_id:
        return headers.instance_id
    instance_id = resolve_default_instance_id(session)
    if not instance_id:
        raise HTTPException(status_code=404, detail="no local instance found")
    return instance_id


def get_verified_instance_id(
    headers: AuthHeaders = Depends(auth_headers),  # noqa: B008
    session: Session = Depends(get_db_session),  # noqa: B008
    instance_id: str = Query(...),
) -> str:
    assert_instance_access_session(session, headers, instance_id)
    return instance_id


def get_resolved_instance_id(
    headers: AuthHeaders = Depends(auth_headers),  # noqa: B008
    session: Session = Depends(get_db_session),  # noqa: B008
    instance_id: str | None = Query(default=None),
) -> str:
    resolved_instance_id = resolve_instance_id_session(session, headers, instance_id)
    assert_instance_access_session(session, headers, resolved_instance_id)
    return resolved_instance_id


VerifiedInstanceIdDep = Annotated[str, Depends(get_verified_instance_id)]
ResolvedInstanceIdDep = Annotated[str, Depends(get_resolved_instance_id)]
