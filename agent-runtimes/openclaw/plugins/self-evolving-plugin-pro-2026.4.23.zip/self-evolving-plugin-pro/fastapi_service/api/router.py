from fastapi import APIRouter

from fastapi_service.modules.expressions.controller import router as expressions_router
from fastapi_service.modules.genes.controller import router as genes_router
from fastapi_service.modules.health.controller import router as health_router
from fastapi_service.modules.instances.controller import router as instances_router
from fastapi_service.modules.reviews.controller import router as reviews_router
from fastapi_service.modules.signals.controller import router as signals_router
from fastapi_service.modules.verification.controller import router as verification_router
from fastapi_service.modules.workspace.controller import router as workspace_router

router = APIRouter()
router.include_router(health_router)
router.include_router(instances_router)
router.include_router(signals_router)
router.include_router(workspace_router)
router.include_router(verification_router)
router.include_router(genes_router)
router.include_router(expressions_router)
router.include_router(reviews_router)
