from fastapi import APIRouter

from .router import router as runtime_router

router = APIRouter()
router.include_router(runtime_router)
