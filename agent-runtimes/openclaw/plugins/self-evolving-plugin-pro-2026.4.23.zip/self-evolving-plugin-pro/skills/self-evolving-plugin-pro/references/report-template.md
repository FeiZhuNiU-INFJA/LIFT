# Review Report Template

Use this as the default shape for a completed review report.

Keep it compact.
Do not invent numbers or conclusions that are not supported by the workset.

## Default Structure

```markdown
## 今日结论

- 回看模式：session_start | timer | command
- 核心判断：复用旧经验 | 新增经验 | 下调旧经验 | 无变化
- strongest evidence：直接用户纠正 | 重复成功 | 重复工具失败 | feature gap | mixed

## 今日新增经验

- Reused: expression_id or none
- Added: expression_id or none
- Downgraded: expression_id or none
- 如果有新增 expression，明确说明 target_file / binding_ref / status

## 今日用户改动观察

- 只写 workset 里真实出现的 workspace changes
- 如果做了 attribution，写清归因对象和原因
- 如果没有用户改动，明确写无

## 今日证据

- 最强 signal
- 最关键的直接用户反馈
- 重要的矛盾、确认、或 attribution 证据

## 待你决定启用

- 新 expression 默认 `disabled`
- 列出用户后续可以手动启用的 expression id
```

## Writing Rules

- lead with the result, not the process
- mention direct user correction explicitly when it changed the decision
- keep each section short
- prefer concrete language over abstract analysis
- if nothing changed, say that clearly

## Good Outcome Labels

Use one of these simple labels in `核心判断`:

- `reused old experience`
- `added new experience`
- `downgraded old experience`
- `no change`
- `mixed update`

## Evidence Labels

Use one of these simple labels in `strongest evidence`:

- `direct user correction`
- `repeated success`
- `repeated tool failure`
- `feature gap`
- `mixed`

## If Nothing Changed

Do not pad the report.
Use a minimal version:

```markdown
## 今日结论

- 回看模式：timer
- 核心判断：no change
- strongest evidence：mixed

## 今日新增经验

- 无

## 今日用户改动观察

- 无

## 今日证据

- 现有 experience 仍然覆盖了这类问题
- 还没有足够强的新重复模式

## 待你决定启用

- 无
```
