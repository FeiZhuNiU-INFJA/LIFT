# Pattern Keys

Use a stable `pattern_key` whenever you reuse a cached gene or create an expression from it.

Purpose:

- avoid duplicate learning
- make cross-session matching easier
- keep the system deterministic
- keep one recurring problem attached to one stable idea

Good keys are:

- short
- lowercase
- dot-separated
- based on the failure or correction shape, not on one exact sentence
- based on cause or reusable lesson, not on who said it

Examples:

- `env.python.venv_missing`
- `tool.retry.same_failure`
- `feedback.user.corrected_path_strategy`
- `path.workspace.relative_confusion`
- `feature.missing.export_option`
- `feedback.user.prefers_simple_next_step`

Avoid:

- timestamps
- session IDs
- user-specific names
- vague keys like `misc.fix`
- wording-only variants like `python.venv.fix_again`

Checklist:

1. name the recurring shape
2. ignore one-off wording details
3. reuse the existing key if it already fits
4. during review, only reuse a key returned by lookup or already present in the workset
5. do not mint a brand-new local key when lookup returned nothing

If a new candidate clearly matches an existing key, reuse the key instead of creating a new one locally during review.
