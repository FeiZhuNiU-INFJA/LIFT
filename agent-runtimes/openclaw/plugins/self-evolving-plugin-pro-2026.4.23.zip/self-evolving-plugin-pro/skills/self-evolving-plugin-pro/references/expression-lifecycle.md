# Expression Lifecycle

Use expression status conservatively.

## Statuses

- `active`: safe to inject now
- `stale`: no longer preferred, but kept for traceability
- `disabled`: should not be injected anymore

Think of these as:

- `active`: keep using it
- `stale`: keep the memory, stop trusting it by default
- `disabled`: stop using it entirely

## Effective Means "Will Be Injected"

For this plugin, "effective" means the expression can be injected by the
`before_prompt_build` hook on the next prompt build.

Use this rule:

- `active` + backend `GET /ready` healthy => effective
- `disabled` => not effective
- `stale` => not effective for prompt guidance

Do not use "the user manually enabled it in this chat" as the test.
The source of truth is backend state plus expression status.

## Typical Decisions

When the user confirms success and an active expression clearly fits:

- call `POST /expressions/activate-log`

When the user directly corrects an active expression:

- do not log a hit
- usually `PATCH` it to `stale`

When the user correction clearly proves the expression harmful or misleading:

- `PATCH` it to `disabled`

When you create a stronger replacement:

- create the replacement
- downgrade the weaker one to `stale`

When the evidence is mixed:

- prefer keeping the old expression `active` or moving it to `stale`
- avoid `disabled` unless the contradiction is clear

When the same old expression keeps being corrected:

- first `stale`
- then `disabled` if repeated correction shows it is consistently misleading

Do not disable expressions casually.
Prefer `stale` unless the contradiction is clear.
