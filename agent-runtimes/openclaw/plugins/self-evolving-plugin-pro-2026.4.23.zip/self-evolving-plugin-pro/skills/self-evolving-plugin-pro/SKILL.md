---
name: self-evolving-plugin-pro
description: Use when the Self-Evolving Plugin Pro needs judgment about review worksets, expression state, prompt injection effectiveness, or local backend setup and readiness.
---

# Self-Evolving Plugin Pro

This skill is the operator guide for the self-evolving pro loop.

The plugin only does three things:

1. collect runtime signals
2. inject active expressions before prompt build
3. schedule review runs

New expressions are not auto-enabled by default.
Create them in a pending state (`disabled`) unless the user explicitly approved activation in the current conversation.
The report should clearly list which new expressions are waiting for user enablement.

This skill does the judgment.

Use these references when needed:

- `references/pattern-keys.md`
- `references/expression-lifecycle.md`
- `references/report-template.md`

## Agent Command Surface

Distinguish chat commands from agent CLI commands.

| Surface                             | Use this form           |
| ----------------------------------- | ----------------------- |
| 普通聊天界面给最终用户看的示例      | `/learn status`         |
| OpenClaw agent / shell / debug 排障 | `openclaw learn status` |

When you are acting as the OpenClaw agent itself, prefer the CLI form:

- `openclaw learn status`
- `openclaw learn signals`
- `openclaw learn expressions --status active`
- `openclaw learn review`
- `openclaw learn report`
- `openclaw learn reports`

Do not tell the OpenClaw agent to use `/learn ...` as if it were a shell command.

## When To Use This Skill

Use this skill whenever any of these is true:

- a review workset was prepared and needs judgment
- the user directly corrected the previous approach
- the user confirmed a previously shaky path worked
- the same failure shape appeared again
- a request suggests a missing reusable experience
- you are about to create, downgrade, or reuse an expression

Also review existing active expressions before any major review or before creating a new one.

## Quick Reference

| Situation                                                            | Default action                                                    |
| -------------------------------------------------------------------- | ----------------------------------------------------------------- |
| Existing active expression clearly fits and user confirmed success   | log an activation hit                                             |
| Existing active expression fits but user corrected it                | do not log a hit; usually downgrade it                            |
| Repeated failure shape without a fitting expression                  | inspect existing genes; if none fits, do not create an expression |
| Clear reusable rule from correction and no fitting expression exists | create a new expression                                           |
| Weak or ambiguous evidence                                           | create nothing; mention it in the report                          |
| Review cannot finish cleanly                                         | call `fail` with the real reason                                  |

## Core Model

- `signal`: a fact from runtime, not a conclusion
- `gene`: an internal reusable pattern derived from repeated evidence
- `expression`: a user-facing reusable experience injected into future prompts
- `review`: a bounded work item for inspecting recent evidence and updating expressions

Treat `gene` as internal memory. Prefer talking about `signals` and `expressions`.

## Runtime Shape

The plugin has two layers:

1. the in-process OpenClaw plugin
2. the local FastAPI backend under `evolution-runtime`

Normal startup flow:

1. plugin is installed and enabled
2. installed plugin directory runs `./scripts/setup-runtime.sh`
3. gateway starts or reloads
4. backend must pass HTTP `GET /ready`
5. only then should review, signal, and expression flows be treated as healthy

If `GET /ready` is not healthy, treat expression state and review state as unreliable until setup is fixed.

## System Boundary

The evolution backend is the source of truth.

- read facts through OpenAPI
- write conclusions through OpenAPI
- never edit storage directly
- never assume a pattern exists until signals support it
- never assume a new expression is better than an older one without evidence

## Signal Types

The plugin may emit these high-value signal kinds:

- `tool_failure`: environment or tool path failed
- `correction`: the user explicitly said the previous approach was wrong
- `frustration`: the user signaled impatience or repeated failure pain
- `success_confirmation`: the user confirmed something worked
- `feature_request`: the user asked for a missing capability
- `user_feedback`: generic feedback that did not fit a stronger category

Direct user feedback has priority over environment-only evidence.

## Evidence Priority

When signals disagree, trust them in this order:

1. direct user correction
2. repeated user-confirmed success
3. repeated tool failure across sessions
4. repeated feature request
5. generic user feedback
6. isolated environment noise

One strong correction usually outweighs multiple weak generic signals.

## First Principles

Always reason in this order:

1. read facts from the backend
2. identify the strongest user feedback in the workset
3. check whether an existing active expression already fits
4. only if no expression fits, inspect the genes already present in the workset or `GET /genes`
5. only if an existing gene clearly fits and the evidence is stable, create a new expression
6. always close the review with `complete` or `fail`

Keep the system conservative:

- prefer reuse over creation
- prefer downgrade over silent contradiction
- prefer a narrow rule over a broad vague one
- prefer no new expression over a duplicate expression

## Three Review Modes

The plugin can trigger three review shapes. They are not the same.

### `session_start`

Use this as a short stabilizing review.

- bias toward the focused or most recent session
- prioritize `correction`, `frustration`, and unresolved `tool_failure`
- prefer updating or disabling a bad expression over creating a new one
- create a new expression only if the pattern is already obvious

### `timer`

Use this as the broader daily review.

- inspect multiple recent sessions
- look for recurring failures across sessions
- look for repeated success confirmations that validate an expression
- use stable pattern keys to avoid duplicate genes or expressions
- look for repeated direct corrections that should replace an older rule

### `command`

Use this as a manual user-triggered review.

- treat it like a deliberate on-demand audit, not an automatic sweep
- keep the same conservative standards as `timer`
- bias toward the most actionable report body because the user is explicitly asking to inspect results now
- if the strongest evidence is still weak, prefer a clear "no change" report over speculative creation

## Pre-Review Checklist

Before making any write decision:

1. read the workset
2. read active expressions
3. identify whether a matching expression already exists
4. identify whether the strongest evidence came from user feedback or only from tooling
5. check whether there is a workspace change that needs attribution
6. check whether the environment probe exposes a real editable target file or only a `binding_ref`
7. if no expression fits, decide whether an existing gene already covers the same reusable rule

## Read APIs

Use only OpenAPI calls against the local backend.

- `GET /health`
- `GET /ready`
- `GET /genes?instance_id=<id>`
- `GET /expressions?instance_id=<id>&status=active`
- `GET /reviews/{review_id}/workset`
- `GET /reviews/{review_id}`
- `GET /workspace/changes/{change_id}/attributions?instance_id=<id>`

## Write APIs

Use these to change state explicitly.

- `POST /expressions`
- `PATCH /expressions/{expression_id}`
- `POST /expressions/activate-log`
- `POST /workspace/changes/{change_id}/attributions`
- `POST /reviews/{review_id}/complete`
- `POST /reviews/{review_id}/fail`

## Gene Reuse Boundary

The current implementation does not allow local gene creation during review.
不要在本地生成 gene。

- do not create a new gene locally
- do not invent a new `pattern_key` when no existing gene clearly fits
- if no active expression fits, inspect workset genes first, then `GET /genes`
- only create an expression when an existing gene clearly fits the evidence
- if no existing gene fits, preserve the evidence in the report and wait for stronger repetition later

The prompt will tell you explicitly when this boundary applies. Follow it literally.

## Expression Effectiveness Rules

Do not confuse "created", "enabled in chat", and "already taking effect".

- only `active` expressions are injected before prompt build
- `disabled` expressions are stored but not injected
- `stale` expressions are kept for traceability but should not be trusted as active guidance
- injection happens through the plugin hook before prompt build, not by printing anything user-visible

When asked whether an expression is currently effective, judge it by backend state:

1. check whether its status is `active`
2. check whether the local backend is healthy through HTTP `GET /ready`
3. if needed, verify the active list through `GET /expressions?...status=active` or `openclaw learn expressions --status active`

Do not answer "not active" merely because the user did not manually run an enable command in the current chat.
If an expression is already `active`, treat it as live even if the user cannot directly see the injected prompt text.

## Workspace Attribution And Targeting

When the workset includes a workspace change:

- attribute it through `POST /workspace/changes/{change_id}/attributions`
- attribute to an existing expression, a cached cloud gene, or a custom user expression
- treat attribution as record-only; it must not trigger a second code modification

When choosing expression targets:

- prefer real files exposed by the environment probe
- only use `target_file` values that came from the workset or environment probe
- if there is no suitable real file, keep `binding_ref` and leave `target_file` empty
- never invent a workspace path

## Direct User Feedback Rules

### If the user corrected the previous approach

- do not log an activation hit for the contradicted expression
- if an existing expression clearly encouraged that wrong path, mark it `stale` or `disabled`
- prefer creating a replacement expression only if the corrected rule is clear

### If the user confirmed success

- if an existing expression matches, log an activation hit
- if success happened after a recent correction, prefer the corrected expression over the older one
- repeated success across sessions is evidence that an expression should remain active

### If the user is frustrated

- reduce complexity in the next step
- do not create broad speculative expressions from frustration alone
- use frustration as a tie-breaker against repeating a shaky strategy

### If the user requested a missing capability

- treat it as a possible feature gap, not an execution failure
- do not create an expression unless the request implies a reusable decision rule
- mention recurring requests in the review report even when no expression is created

## Conservative Creation Rules

Create nothing when:

- evidence comes from only one weak generic signal
- feedback is ambiguous
- the candidate duplicates an existing active expression
- the rule is too specific to one session
- the only evidence is frustration without a clear corrective rule

Review genes when:

- there is a repeated failure shape
- or a direct correction states a clear reusable rule
- and no active expression already fits

Create nothing when no existing gene clearly fits.

Create a new expression only when:

- no active expression already fits
- an existing gene clearly fits
- the reusable advice is specific enough to inject later
- the rule would help in a future similar situation
- default status should be `disabled` so the user can decide whether to enable it

## Recurring Pattern Discipline

Use recurring patterns the same way every time:

1. search for an existing matching expression first
2. if none fits, inspect genes from the workset or `GET /genes`
3. if an existing gene matches, reuse its `pattern_key`
4. if no gene fits, do not mint a new local key during review
5. do not create near-duplicate expressions with different wording

If a pattern keeps showing up across sessions, prefer strengthening one existing expression over creating many similar ones.

## Suggested Review Workflow

1. Read the review workset.
2. Rank signals by strength:
   - correction
   - frustration
   - tool_failure
   - success_confirmation
   - generic feedback
3. Check active expressions for a match.
4. If matched:
   - log activation on success or confirmed reuse
   - do not reinforce if the user corrected it
5. If not matched:
   - inspect workset genes or `GET /genes`
   - create an expression only if an existing gene fits and the rule is reusable
6. If a workspace change exists, record attribution without triggering a second code modification.
7. If an older expression is contradicted, downgrade it.
8. Complete the review with a compact report.

## Minimal Decision Rules

Use these defaults unless the evidence clearly supports something stronger:

- one correction + no matching expression:
  inspect existing genes, and only create an expression if one clearly fits and the correction is reusable
- one success + matching active expression:
  log activation
- one failure + no correction:
  usually report only; do not rush to create
- repeated same failure across sessions:
  inspect existing genes; if none fits, report only
- repeated correction of the same old expression:
  downgrade the old one and consider a replacement

## Good Expression Shape

A good expression is:

- short
- specific
- reusable in future prompts
- framed as what to do next
- grounded in a repeated or clearly corrected pattern

Avoid expressions that are:

- just a copy of one chat message
- too broad to be actionable
- emotionally reactive
- tied to one exact session or one exact user phrasing

## Report Shape

A good report includes:

1. 今日结论
2. 今日新增经验
3. 今日用户改动观察
4. 今日证据
5. 待你决定启用

Also include:

- whether the strongest evidence came from direct user feedback
- whether the outcome was reuse, creation, downgrade, or no change
- whether there was a workspace attribution worth recording
- whether the candidate pattern should be watched again before creating anything

When possible, follow `references/report-template.md` so reports stay easy to scan across days.

## Failure Discipline

If blocked by auth, API failure, malformed data, or uncertainty too high:

- call `POST /reviews/{review_id}/fail`
- include the real reason
- do not silently stop

## Setup And Troubleshooting

When the plugin appears installed but review, report, or expression checks fail, use this order:

1. confirm the installed plugin directory is the active one
2. run `./scripts/setup-runtime.sh` from the installed plugin directory
3. reload or restart OpenClaw gateway
4. verify HTTP `GET /ready`
5. only then retry `openclaw learn ...` or review APIs

Quick checks:

- runtime ready marker: `evolution-runtime/runtime-ready.json`
- backend readiness: HTTP `GET /ready`
- if setup succeeded but service still does not answer, inspect gateway/plugin startup logs
- if startup appears stuck around `backend.lock`, treat it as a backend startup issue first

## FAQ

### Why does `openclaw learn ...` fail right after install?

Usually because runtime setup or backend startup did not finish.
Run `./scripts/setup-runtime.sh` in the installed plugin directory, reload gateway, then check `GET /ready`.

### Why does the model say an expression is not active, but behavior suggests it already is?

Because prompt injection is invisible to the user.
The source of truth is backend status plus expression state.
If the expression is `active` and `GET /ready` is healthy, treat it as effective.

### Which command form should the agent use?

The OpenClaw agent should use `openclaw learn ...`.
Only end-user chat examples should use `/learn ...`.

## Style Of Judgment

Be calm and practical.

- do not over-claim
- do not treat one conversation as a universal rule
- do not reward a path the user explicitly rejected
- do not create extra objects just to look productive
- when unsure, preserve evidence and wait for another signal
