#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(CDPATH= cd -- "${SCRIPT_DIR}/.." && pwd -P)"
STATE_DIR="${OPENCLAW_STATE_DIR:-~/.openclaw}"
if [[ -d "${STATE_DIR}" ]]; then
  STATE_DIR="$(CDPATH= cd -- "${STATE_DIR}" && pwd -P)"
fi
DEFAULT_WORKSPACE_DIR="${OPENCLAW_WORKSPACE_ROOT:-${STATE_DIR}/workspace}"
EXTENSIONS_ROOT="${STATE_DIR}/extensions"
PARENT_DIR_NAME="$(basename "$(dirname "${REPO_ROOT}")")"
PLUGIN_ID="self-evolving-plugin-pro"

set_openclaw_config_if_missing() {
  local path="$1"
  local value="$2"

  if openclaw config get "${path}" >/dev/null 2>&1; then
    return 0
  fi

  openclaw config set "${path}" "${value}"
}

ensure_plugin_config() {
  local plugin_prefix="plugins.entries.${PLUGIN_ID}"
  local plugin_config_prefix="${plugin_prefix}.config"

  set_openclaw_config_if_missing "${plugin_prefix}.enabled" "true"
  set_openclaw_config_if_missing "${plugin_config_prefix}.serviceEndpoint" "http://127.0.0.1:18090"
  set_openclaw_config_if_missing "${plugin_config_prefix}.listenHost" "0.0.0.0"
  set_openclaw_config_if_missing "${plugin_config_prefix}.autoDailyReviewEnabled" "true"
  set_openclaw_config_if_missing "${plugin_config_prefix}.autoDailyReviewIntervalHours" "24"
  set_openclaw_config_if_missing "${plugin_config_prefix}.sessionStartReviewEnabled" "true"
  set_openclaw_config_if_missing "${plugin_config_prefix}.sessionStartReviewIntervalHours" "4"
  set_openclaw_config_if_missing "${plugin_config_prefix}.sessionStartReviewWindow" "6h"
  set_openclaw_config_if_missing "${plugin_config_prefix}.sessionStartReviewLimit" "5"
  set_openclaw_config_if_missing "${plugin_config_prefix}.timerReviewWindow" "24h"
  set_openclaw_config_if_missing "${plugin_config_prefix}.timerReviewLimit" "20"

  if [[ -n "${OPENCLAW_WORKSPACE_ROOT:-}" ]]; then
    set_openclaw_config_if_missing "${plugin_config_prefix}.workspaceRoot" "${DEFAULT_WORKSPACE_DIR}"
  fi
}

if ! command -v openclaw >/dev/null 2>&1; then
  echo "openclaw not found on PATH" >&2
  exit 127
fi

cd "${REPO_ROOT}"
if [[ "${PARENT_DIR_NAME}" != "extensions" && "${REPO_ROOT}" != "${EXTENSIONS_ROOT}/"* ]]; then
  # --dangerously-force-unsafe-install is required from OpenClaw 2026.4.10+:
  # the static install scanner flags our child_process usage (spawn backend
  # uvicorn in runtimeManager.js, spawn `openclaw agent --local` in review
  # worker) and process.env + localhost fetch as critical. Both are load-
  # bearing for this plugin and the only side effect is localhost IO.
  openclaw plugins install --dangerously-force-unsafe-install "${REPO_ROOT}"
fi
ensure_plugin_config
bash "${SCRIPT_DIR}/setup-runtime.sh"
openclaw gateway restart 2>/dev/null || true
