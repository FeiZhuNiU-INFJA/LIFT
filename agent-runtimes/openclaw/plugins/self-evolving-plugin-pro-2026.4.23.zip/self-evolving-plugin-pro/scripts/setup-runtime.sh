#!/usr/bin/env bash
set -euo pipefail

PLUGIN_ID="self-evolving-plugin-pro"
RUNTIME_STATE_DIR_NAME="evolution-runtime"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(CDPATH= cd -- "${SCRIPT_DIR}/.." && pwd)"

if [[ -n "${OPENCLAW_STATE_DIR:-}" ]]; then
  STATE_DIR="${OPENCLAW_STATE_DIR}/${RUNTIME_STATE_DIR_NAME}"
else
  STATE_DIR="${HOME}/.openclaw/${RUNTIME_STATE_DIR_NAME}"
fi

RUNTIME_DIR="${STATE_DIR}/python-runtime"
VENV_DIR="${RUNTIME_DIR}/.venv"
VENV_PYTHON="${VENV_DIR}/bin/python"
READY_FILE="${STATE_DIR}/runtime-ready.json"
UV_INSTALL_DIR="${STATE_DIR}/uv-bin"
UV_BIN="${OPENCLAW_UV_BIN:-}"
PLUGIN_VERSION="$(node -p "require('${REPO_ROOT}/package.json').version" 2>/dev/null || true)"

mkdir -p "${STATE_DIR}" "${RUNTIME_DIR}"

# ── lock: only one setup process at a time ──
# `flock` ships with util-linux on Linux but is not present on stock macOS.
# Fall back to no locking when missing — concurrent setup is rare and the
# rest of the script is idempotent (venv create + uv pip install).
SETUP_LOCK="${STATE_DIR}/setup.lock"
exec 200>"${SETUP_LOCK}"
if command -v flock >/dev/null 2>&1; then
  if ! flock -n 200; then
    printf 'setup already in progress, skipping\n' >&2
    exit 0
  fi
fi

# ── already ready: nothing to do ──
if [[ -x "${VENV_PYTHON}" ]] && "${VENV_PYTHON}" -c "import fastapi, uvicorn" >/dev/null 2>&1 \
   && [[ -f "${READY_FILE}" ]]; then
  printf 'runtime already ready: %s\n' "${READY_FILE}"
  exit 0
fi

print_uv_path() {
  local candidate="$1"
  if [[ -n "${candidate}" && -x "${candidate}" ]]; then
    printf '%s\n' "${candidate}"
    return 0
  fi
  return 1
}

resolve_uv() {
  print_uv_path "${UV_BIN}" && return 0
  print_uv_path "${UV_INSTALL_DIR}/uv" && return 0
  print_uv_path "${UV_INSTALL_DIR}/bin/uv" && return 0
  if command -v uv >/dev/null 2>&1; then
    command -v uv
    return 0
  fi
  if ! command -v curl >/dev/null 2>&1; then
    echo "curl not found on PATH; cannot install uv" >&2
    return 1
  fi
  mkdir -p "${UV_INSTALL_DIR}"
  curl -LsSf https://astral.sh/uv/install.sh | env UV_UNMANAGED_INSTALL="${UV_INSTALL_DIR}" sh >&2
  print_uv_path "${UV_INSTALL_DIR}/uv" && return 0
  print_uv_path "${UV_INSTALL_DIR}/bin/uv" && return 0
  echo "failed to install uv into ${UV_INSTALL_DIR}" >&2
  return 1
}

UV_BIN="$(resolve_uv)"
[[ -d "${VENV_DIR}" ]] || "${UV_BIN}" venv "${VENV_DIR}"
"${UV_BIN}" pip install --python "${VENV_PYTHON}" -r "${REPO_ROOT}/requirements.txt"
"${VENV_PYTHON}" -c "import fastapi, uvicorn" >/dev/null 2>&1

cat > "${READY_FILE}" <<EOF
{
  "plugin_id": "${PLUGIN_ID}",
  "version": "${PLUGIN_VERSION}",
  "repo_root": "${REPO_ROOT}",
  "runtime_dir": "${RUNTIME_DIR}",
  "venv_python": "${VENV_PYTHON}"
}
EOF

printf 'runtime ready: %s\n' "${READY_FILE}"
