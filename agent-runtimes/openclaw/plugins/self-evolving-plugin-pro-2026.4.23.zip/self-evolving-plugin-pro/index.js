const register = require("./src/plugin/register");

let definePluginEntry;
try {
  definePluginEntry = require("openclaw/plugin-sdk/plugin-entry").definePluginEntry;
} catch {
  // Outside openclaw host (e.g. tests) — export register directly
  definePluginEntry = null;
}

module.exports = definePluginEntry
  ? definePluginEntry({
      id: "self-evolving-plugin-pro",
      name: "Self-Evolving Plugin Pro",
      register,
    })
  : register;
