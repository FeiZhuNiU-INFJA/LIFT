function extractText(value) {
  if (typeof value === "string") return value.trim();
  if (!value) return "";
  if (Array.isArray(value)) return value.map(extractText).filter(Boolean).join("\n").trim();
  if (typeof value !== "object") return String(value).trim();
  if (typeof value.text === "string") return value.text.trim();
  if (typeof value.content === "string") return value.content.trim();
  if (typeof value.message === "string") return value.message.trim();
  if (value.message) return extractText(value.message);
  if (value.content) return extractText(value.content);
  if (Array.isArray(value.parts)) return extractText(value.parts);
  return "";
}

function firstString(values, fallback = "") {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return fallback;
}

function extractSessionId(context) {
  if (!context || typeof context !== "object") return "unknown-session";
  return firstString(
    [
      context.sessionId,
      context.sessionKey,
      context.conversationId,
      context.threadId,
      context.messageId,
      context.metadata && context.metadata.sessionId,
      context.metadata && context.metadata.threadId,
    ],
    "unknown-session",
  );
}

function extractUserId(context) {
  if (!context || typeof context !== "object") return "anonymous";
  return firstString(
    [context.userId, context.user_id, context.senderId, context.from, context.metadata && context.metadata.senderId],
    `session:${extractSessionId(context)}`,
  );
}

module.exports = { extractText, extractSessionId, extractUserId };
