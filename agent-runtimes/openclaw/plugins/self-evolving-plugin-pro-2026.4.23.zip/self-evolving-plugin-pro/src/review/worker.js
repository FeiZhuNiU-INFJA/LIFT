const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const { buildReviewPrompt } = require("./promptBuilder");

function commandResolvable(command) {
  const candidate = String(command || "").trim();
  if (!candidate) return false;
  if (candidate.includes("/") || candidate.startsWith(".")) {
    try {
      fs.accessSync(candidate, fs.constants.X_OK);
      return true;
    } catch {
      return false;
    }
  }
  const pathValue = String(process.env.PATH || "");
  for (const entry of pathValue.split(path.delimiter).filter(Boolean)) {
    const resolved = path.join(entry, candidate);
    try {
      fs.accessSync(resolved, fs.constants.X_OK);
      return true;
    } catch {}
  }
  return false;
}

function resolveCliPath() {
  const envPath = String(process.env.OPENCLAW_CLI_PATH || "").trim();
  if (envPath && commandResolvable(envPath)) return envPath;
  const mainScript = (require.main && require.main.filename) || process.argv[1] || "";
  if (mainScript) {
    let dir = path.dirname(mainScript);
    for (let depth = 0; depth < 6 && dir && dir !== path.dirname(dir); depth += 1) {
      try {
        const pkg = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8"));
        if (pkg && pkg.name === "openclaw") {
          const prefix = path.resolve(dir, "..", "..", "..");
          const candidate = path.join(prefix, "bin", "openclaw");
          if (commandResolvable(candidate)) return candidate;
          break;
        }
      } catch {}
      dir = path.dirname(dir);
    }
  }
  return commandResolvable("openclaw") ? "openclaw" : "";
}

function estimateReviewSeconds({ signalCount, sessionCount, changedFileCount }) {
  const base = 12;
  const estimated =
    base + Number(signalCount || 0) * 2 + Number(sessionCount || 0) * 4 + Number(changedFileCount || 0) * 3;
  return Math.max(15, Math.min(estimated, 180));
}

function parseTokenUsage(stdout) {
  try {
    const lines = String(stdout || "")
      .trim()
      .split("\n")
      .filter(Boolean);
    for (let i = lines.length - 1; i >= 0; i -= 1) {
      let parsed;
      try {
        parsed = JSON.parse(lines[i]);
      } catch {
        continue;
      }
      if (parsed && (parsed.usage || parsed.token_usage)) {
        const usage = parsed.usage || parsed.token_usage;
        return {
          input_tokens: Number(usage.input_tokens || 0),
          output_tokens: Number(usage.output_tokens || 0),
          total_tokens: Number(usage.total_tokens || usage.input_tokens || 0) + Number(usage.output_tokens || 0),
        };
      }
    }
  } catch {}
  return null;
}

function createReviewWorker(options) {
  const { ensureReady, fetchJson, buildUrl, buildAuthHeaders, config, cwd } = options;

  async function failPreparedReview(reviewId, error) {
    if (!reviewId) return null;
    try {
      return await fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/fail`), {
        method: "POST",
        headers: buildAuthHeaders(config),
        body: JSON.stringify({
          instance_id: config.instanceId,
          error: String((error && (error.message || error)) || "review worker failed").slice(0, 4000),
        }),
      });
    } catch {
      return null;
    }
  }

  async function executePreparedReview({ reviewId, workset, since, reason }) {
    await ensureReady();
    const cliPath = resolveCliPath();
    if (!cliPath) {
      throw new Error("OpenClaw CLI is unavailable. Ensure `openclaw` is on PATH.");
    }
    const message = buildReviewPrompt({
      workset,
      reviewId,
      since,
      reason,
      config,
      buildUrl,
    });
    let stdout = "";
    let stderr = "";
    await new Promise((resolve, reject) => {
      const child = spawn(
        cliPath,
        ["agent", "--local", "--session-id", `review-${reviewId}`, "--message", message, "--json", "--thinking", "low"],
        {
          cwd,
          stdio: ["ignore", "pipe", "pipe"],
        },
      );
      child.on("error", (error) => {
        reject(new Error(`failed to launch OpenClaw CLI: ${String(error.message || error)}`));
      });
      child.stdout.on("data", (chunk) => {
        stdout += String(chunk);
      });
      child.stderr.on("data", (chunk) => {
        stderr += String(chunk);
      });
      child.on("exit", (code) => {
        if (code === 0) resolve();
        else reject(new Error(stderr || `review worker failed with code ${code}`));
      });
    });
    const tokenUsage = parseTokenUsage(stdout);
    if (tokenUsage) {
      await fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/token-usage`), {
        method: "POST",
        headers: buildAuthHeaders(config),
        body: JSON.stringify({ instance_id: config.instanceId, token_usage: tokenUsage }),
      }).catch(() => null);
    }
    const review = await fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}`), {
      headers: buildAuthHeaders(config),
    });
    if (review && review.status === "running") {
      await fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/fail`), {
        method: "POST",
        headers: buildAuthHeaders(config),
        body: JSON.stringify({
          instance_id: config.instanceId,
          error: `worker_exited_without_completion\n${String(stdout || stderr).slice(-1200)}`,
        }),
      }).catch(() => null);
      return fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}`), {
        headers: buildAuthHeaders(config),
      });
    }
    return review;
  }

  async function prepareReviewRun({ since, reason, limit, focusSessionId }) {
    await ensureReady();
    const prepared = await fetchJson(buildUrl(config.serviceEndpoint, "reviews/prepare"), {
      method: "POST",
      headers: buildAuthHeaders(config),
      body: JSON.stringify({
        instance_id: config.instanceId,
        since,
        limit: Number(limit || 20),
        reason,
        focus_session_id: focusSessionId || null,
      }),
    });
    try {
      const workset = await fetchJson(
        buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(prepared.id)}/workset`),
        { headers: buildAuthHeaders(config) },
      );
      const signalCount = Array.isArray(workset.signals) ? workset.signals.length : 0;
      const sessionCount = Array.isArray(workset.sessions) ? workset.sessions.length : 0;
      const changedFileCount = Number(workset.workspace_change?.summary?.changed_file_count || 0);
      return {
        reviewId: prepared.id,
        signalCount,
        sessionCount,
        changedFileCount,
        estimateSeconds: estimateReviewSeconds({ signalCount, sessionCount, changedFileCount }),
        runner: async () => {
          try {
            return await executePreparedReview({
              reviewId: prepared.id,
              workset,
              since,
              reason,
            });
          } catch (error) {
            await failPreparedReview(prepared.id, error);
            throw error;
          }
        },
      };
    } catch (error) {
      await failPreparedReview(prepared.id, error);
      throw error;
    }
  }

  async function runReviewWorker(request) {
    const prepared = await prepareReviewRun(request);
    return prepared.runner();
  }

  runReviewWorker.prepareReviewRun = prepareReviewRun;
  return runReviewWorker;
}

module.exports = {
  commandResolvable,
  resolveCliPath,
  parseTokenUsage,
  createReviewWorker,
  estimateReviewSeconds,
};
