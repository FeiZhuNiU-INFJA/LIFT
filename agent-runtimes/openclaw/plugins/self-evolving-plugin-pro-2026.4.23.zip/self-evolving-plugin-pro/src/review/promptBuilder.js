function preview(value, max = 160) {
  const text = String(value || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!text) return "";
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

function renderChangedFiles(workspaceChange) {
  const files = workspaceChange && workspaceChange.summary && workspaceChange.summary.changed_files;
  if (!Array.isArray(files) || files.length === 0) return "- none";
  return files
    .slice(0, 8)
    .map((item) => `- ${item.priority} ${item.status} ${item.path}`)
    .join("\n");
}

function renderBindingCandidates(workset, patchEnabled) {
  if (!patchEnabled) return "- none";
  const source = Array.isArray(workset.binding_candidates)
    ? workset.binding_candidates
    : Array.isArray(workset.environment_probe?.binding_candidates)
      ? workset.environment_probe.binding_candidates
      : [];
  if (!source.length) return "- none";
  return source
    .slice(0, 8)
    .map((item) => `- ${item.kind} ${item.binding_ref} -> ${item.target_file}`)
    .join("\n");
}

function renderTargetCandidates(generation, patchEnabled) {
  if (!patchEnabled) return "- none";
  const list = generation.target_candidates;
  if (!Array.isArray(list) || list.length === 0) return "- none";
  return list
    .slice(0, 4)
    .map((item) => `- 文件: ${item.file || "-"} | 位置: ${item.section || "-"} | 操作: ${item.operation || "append"}`)
    .join("\n");
}

function buildApplyGuidance(bindingCandidates, patchEnabled) {
  if (patchEnabled) {
    return [
      "Binding candidates:",
      bindingCandidates,
      "",
      "只能从 binding candidates 给出的真实锚点文件中选择 target_file。",
      "如果没有合适的真实文件，就只填写 binding_ref，不要编造路径。",
    ];
  }
  return [
    "注入方式：本部署仅启用 before_prompt_build hook 注入，不会改写 workspace 文件。创建 expression 时不要传 target_file 和 binding_ref，否则会被服务端忽略。规则的全部作用就是 expression 的 content 字段会被原样注入到下一轮 LLM 的 system prompt 里。",
    "因此 content 必须是一段可以独立成立的中文行为约束，不依赖任何 workspace 文件的存在。",
  ];
}

function buildTargetGuidance(targetCandidates, patchEnabled) {
  if (patchEnabled) return ["## 目标文件", targetCandidates];
  return ["## 注入位置", "before_prompt_build hook，自动注入到 system prompt（不需要选文件）。"];
}

function buildRequirementsSection(patchEnabled) {
  if (patchEnabled) {
    return [
      "1. 输出的内容可以直接追加到目标文件中",
      "2. 语言简洁明确，Agent 可以理解和遵循",
      "3. 不要输出解释或说明，只输出规则内容本身",
      "4. 如果目标是 Markdown 文件，使用合适的 Markdown 格式",
      "5. 如果目标是 JSON 文件，输出合法 JSON 片段",
      "6. 内容必须结合当前 case 和用户反馈，不要只复述 gene 模板",
      "7. 规则应尽量窄、稳定、可复用，避免过度泛化",
    ];
  }
  return [
    "1. content 字段会被原样注入到下一轮 LLM 的 system prompt，写一段可独立成立的中文行为约束即可。",
    "2. 语言简洁明确，LLM 可以理解和遵循。",
    "3. 不要引用、假设、读取任何 workspace 文件（AGENTS.md / SOUL.md 等），也不要提 target_file。",
    "4. 不要输出解释或说明，只输出规则内容本身。",
    "5. 内容必须结合当前 case 和用户反馈，不要只复述 gene 模板。",
    "6. 规则应尽量窄、稳定、可复用，避免过度泛化。",
  ];
}

function buildReviewPrompt({ workset, reviewId, since, reason, config, buildUrl }) {
  const strongestSignals = (Array.isArray(workset.signals) ? workset.signals : [])
    .slice(0, 5)
    .map((signal) => `- ${signal.kind}: ${preview(signal.content, 120)}`)
    .join("\n");
  const workspaceChange = workset.workspace_change || null;
  const changedFiles = renderChangedFiles(workspaceChange);
  // expression_apply_policy.workspace_patch_enabled tells us whether the
  // server will actually accept target_file/binding_ref and write to a
  // workspace file. When patching is disabled (the default), the rule
  // reaches the LLM purely via the before_prompt_build hook, so the
  // prompt renders a simplified hook-only flavor.
  const applyPolicy = workset.expression_apply_policy || { workspace_patch_enabled: false, apply_mode: "hook_only" };
  const patchEnabled = Boolean(applyPolicy.workspace_patch_enabled);
  const bindingCandidates = renderBindingCandidates(workset, patchEnabled);
  const generation = workset.expression_generation_context || {};
  const generationCase = generation.case || {};
  const errorEvidence = Array.isArray(generation.error_evidence)
    ? generation.error_evidence.map((item) => `- ${item}`).join("\n")
    : "- none";
  const userInputExcerpt = String(generation.user_input_excerpt || "").trim() || "- none";
  const targetCandidates = renderTargetCandidates(generation, patchEnabled);
  const applyGuidance = buildApplyGuidance(bindingCandidates, patchEnabled);
  const targetGuidance = buildTargetGuidance(targetCandidates, patchEnabled);
  const requirements = buildRequirementsSection(patchEnabled);
  return [
    "Use the self-evolving-plugin-pro skill.",
    `Base URL: ${config.serviceEndpoint}`,
    `Instance id: ${config.instanceId}`,
    `Review id: ${reviewId}`,
    `Reason: ${reason || "command"}`,
    `Time window: ${since}`,
    "",
    "这是一次演进回看任务。",
    "你必须真的调用后端 OpenAPI 完成它，不能只写计划。",
    "不要读取本地仓库源码、schema、测试文件或技能文件来推断接口，也不要做与后端无关的本地探索。",
    "只允许通过 shell 中的 HTTP 调用访问下面列出的接口；如果这些接口不够，就直接调用 /reviews/{id}/fail，不要继续查本地代码。",
    "只做保守判断：先看已有 expression，再看 workset 里已经给出的 genes；只有存在明确可复用的 gene 候选时才能创建 expression。",
    "新创建的 expression 默认不要直接启用。除非用户在当前对话中明确批准，否则创建时用 disabled，等待用户后续决定开启哪些。",
    "不要在本地生成 gene。只允许复用 workset / GET /genes 里已经存在的 gene。没有明确匹配 gene 时，不要创建 expression。",
    "expression 用中文写 1-2 句，能直接注入未来 prompt，不要解释来源。",
    "结束前必须调用 /reviews/{id}/complete；如果做不完，就调用 /reviews/{id}/fail。",
    "",
    "后端鉴权头：",
    `x-openclaw-instance-id: ${config.instanceId}`,
    `x-openclaw-instance-token: ${config.instanceToken}`,
    "",
    "你至少需要访问：",
    `GET ${buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/workset`)}`,
    `GET ${buildUrl(config.serviceEndpoint, "genes")}?instance_id=${encodeURIComponent(config.instanceId)}`,
    `POST ${buildUrl(config.serviceEndpoint, "expressions")}`,
    `PATCH ${buildUrl(config.serviceEndpoint, "expressions/<expression_id>")}`,
    `POST ${buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/complete`)}`,
    `POST ${buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}/fail`)}`,
    "",
    "Workset summary:",
    `- sessions: ${(workset.sessions || []).length}`,
    `- signals: ${(workset.signals || []).length}`,
    `- expressions: ${(workset.expressions || []).length}`,
    `- pending expressions: ${(workset.pending_expressions || []).length}`,
    `- genes: ${(workset.genes || []).length}`,
    `- workspace change id: ${workspaceChange ? workspaceChange.id : "-"}`,
    `- workspace changed files: ${workspaceChange && workspaceChange.summary ? workspaceChange.summary.changed_file_count || 0 : 0}`,
    "",
    "Strongest signals:",
    strongestSignals || "- none",
    "",
    "Workspace changes:",
    changedFiles,
    "",
    ...applyGuidance,
    "",
    "注意：workset.pending_expressions 里是尚未启用但已经存在的经验，创建前先检查，避免重复。",
    "",
    "当你决定基于某个已存在的 gene 创建 expression 时，用下面的子模版先在脑中生成 expression 的 content 字段。",
    "这个子模版只约束 expression 内容本身，不是最终 report。",
    "创建 expression 时，不要传本地 gene_id，只传 remote_gene_id。",
    "当你创建或更新 expression 时，必须把本次真正采用的 signals 聚成一组，并在请求里带上 signal_ids。",
    "当你创建或更新 expression 时，必须在请求里带上 review_id，值就是当前 Review id。",
    "只有真的用于生成或更新 expression 的那组 signals 才能出现在 signal_ids 里，不要把所有 matched signals 都塞进去。",
    "",
    "每次创建 expression 时，必须在请求 body 里额外提供两个评分字段：confidence 和 risk，各为 0.0-1.0 的浮点数。",
    "- confidence：你对这条 expression 是「真正可复用、能稳定改善未来行为」的把握。参考维度：signal 数量和一致性、用户反馈是否明确、规则是否聚焦一个真实场景。样例：多个独立 signal 一致指向同一问题且 gene 匹配清晰 → 0.9+；只有 1 条模糊 signal → 0.5-0.7。",
    "- risk：如果这条 expression 被注入未来 prompt 后「用错场景」，会造成多大的坏影响。参考维度：作用范围（越通用越高风险）、是否可逆、与已有 expression 是否有冲突、是否可能让模型回避正常任务。样例：窄且只给建议的规则 → 0.1-0.2；强制性的、影响面广的规则 → 0.4+。",
    "两个评分要严肃校准，不要默认都写 0.9/0.1。",
    "后端会自动启用 confidence ≥ 0.85 且 risk ≤ 0.25 的 expression；其他的保持 disabled 等待用户确认。所以高置信低风险的常识性规则可以放心创建，它们会直接生效；范围大或可能误伤的规则请用更保守的分数。",
    "完成 review 时，必须在 /reviews/{id}/complete 里返回 matched_genes，格式为 [{ signal_id, remote_gene_ids }].",
    "",
    "你是一个 Agent 配置优化专家。请根据以下信息，生成一条具体的、可直接添加到 OpenClaw Agent 配置文件中的规则/指令。",
    "",
    "## 基因信息",
    "- 规则摘要: <selected_gene.summary>",
    "- 规则正文: <selected_gene.rule_text>",
    "- 远端基因ID: <selected_gene.remote_gene_id>",
    "",
    "## Case 信息",
    `- 归因编码: ${generationCase.primary_code || "-"} (${generationCase.primary_label || "-"})`,
    `- 归因证据:\n${errorEvidence}`,
    `- Bad Score: ${Number(generationCase.bad_score || 0).toFixed(2)}`,
    "",
    "## 用户原始输入（截取）",
    userInputExcerpt,
    "",
    ...targetGuidance,
    "",
    "## 要求",
    ...requirements,
    "",
    "Write the final report in this structure:",
    "## 今日结论",
    "用 2-4 句话直接说明今天学到了什么、为什么值得保留。",
    "## 今日新增经验",
    patchEnabled
      ? "只写真正新增或更新的 expression，每条都要标出 confidence / risk / 最终 status（active 表示已自动启用，disabled 表示等待用户确认）和落点文件。"
      : "只写真正新增或更新的 expression，每条都要标出 confidence / risk / 最终 status（active 表示已自动启用，disabled 表示等待用户确认）。当前部署仅通过 prompt hook 注入，不要提落点文件。",
    "## 今日用户改动观察",
    "只写今天看到的关键 workspace changes；如果没有，就明确写无。",
    "## 今日证据",
    "把最关键的 signal / 锚点文件 diff / 失败证据用短列表列出来。",
    "## 待你决定启用",
    "只列 status=disabled 的 expression id，告诉用户这些需要手动启用。已自动启用的不要放在这里。",
  ].join("\n");
}

module.exports = {
  buildReviewPrompt,
};
