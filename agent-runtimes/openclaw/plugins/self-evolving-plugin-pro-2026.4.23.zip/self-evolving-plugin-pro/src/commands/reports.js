async function handleReports({ parsed, listReviews, renderReviewHistory }) {
  const rows = await listReviews(Number(parsed.flags.limit || 10), String(parsed.flags.status || "completed"));
  return renderReviewHistory(rows);
}

async function handleReport({ parsed, listReviews, getReview, renderReviewDetail }) {
  const reviewId = String(parsed.flags.id || "").trim();
  const raw = Boolean(parsed.flags.raw);
  if (reviewId) {
    return renderReviewDetail(await getReview(reviewId), raw);
  }
  const reviews = await listReviews(1, "completed");
  const latest = Array.isArray(reviews) ? reviews[0] : null;
  if (!latest) {
    return "还没有已完成的 review。先运行 `/learn review` 生成一次。";
  }
  return renderReviewDetail(latest, raw);
}

module.exports = {
  handleReports,
  handleReport,
};
