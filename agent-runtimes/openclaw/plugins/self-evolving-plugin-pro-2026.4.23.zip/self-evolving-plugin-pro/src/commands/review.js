async function handleReview({ parsed, config, defaults, runReviewWorker, prepareReviewRun, renderReviewSummary }) {
  if (parsed.flags.report || parsed.flags.latest || parsed.flags.id) {
    return "历史查看请用 `/learn report` 或 `/learn reports`。";
  }
  const request = {
    since: String(parsed.flags.since || config.timerReviewWindow || defaults.defaultTimerReviewWindow),
    reason: "command",
    limit: Number(config.timerReviewLimit || defaults.defaultTimerReviewLimit),
    focusSessionId: null,
  };
  if (!runReviewWorker && typeof prepareReviewRun === "function") {
    const prepared = await prepareReviewRun(request);
    const result = await prepared.runner();
    if (result.report_markdown && String(result.report_markdown).trim()) return result.report_markdown;
    return renderReviewSummary(result);
  }
  const result = await runReviewWorker(request);
  if (result.report_markdown && String(result.report_markdown).trim()) return result.report_markdown;
  return renderReviewSummary(result);
}

module.exports = { handleReview };
