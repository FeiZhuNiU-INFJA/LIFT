async function handleSignals({ parsed, listSignals, renderSignalsCard }) {
  const rows = await listSignals(Number(parsed.flags.limit || 20));
  return renderSignalsCard(rows);
}

module.exports = { handleSignals };
