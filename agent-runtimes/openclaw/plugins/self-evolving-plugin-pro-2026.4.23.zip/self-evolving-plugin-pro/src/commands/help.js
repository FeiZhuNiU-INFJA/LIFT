async function handleHelp({ renderHelp }) {
  return renderHelp();
}

module.exports = { handleHelp };
