async function handleStatus({ listExpressions, listSignals, config, renderStatusCard }) {
  const expressions = await listExpressions("");
  const signals = await listSignals(5);
  return renderStatusCard({
    instanceId: config.instanceId,
    serviceEndpoint: config.serviceEndpoint,
    expressionCount: Array.isArray(expressions) ? expressions.length : 0,
    signalCount: Array.isArray(signals) ? signals.length : 0,
  });
}

module.exports = { handleStatus };
