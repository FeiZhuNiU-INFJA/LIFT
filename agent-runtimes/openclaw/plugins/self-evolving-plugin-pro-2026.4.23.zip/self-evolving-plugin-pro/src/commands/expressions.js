async function handleExpressions({ parsed, listExpressions, renderExpressionsCard }) {
  const rows = await listExpressions(parsed.flags.all ? "" : String(parsed.flags.status || ""));
  return renderExpressionsCard(rows);
}

async function handleEnable({ parsed, patchExpression, renderExpressionActionResult }) {
  const expressionId = parsed.positionals[0];
  if (!expressionId) return "Usage: /learn enable <expression_id>";
  const row = await patchExpression(expressionId, { status: "active" });
  return renderExpressionActionResult("已启用经验", row);
}

async function handleDisable({ parsed, patchExpression, renderExpressionActionResult }) {
  const expressionId = parsed.positionals[0];
  if (!expressionId) return "Usage: /learn disable <expression_id>";
  const row = await patchExpression(expressionId, { status: "disabled" });
  return renderExpressionActionResult("已停用经验", row);
}

module.exports = {
  handleExpressions,
  handleEnable,
  handleDisable,
};
