const fs = require("fs");
const net = require("net");
const os = require("os");
const path = require("path");
const { randomBytes } = require("crypto");
const { spawn, execFileSync } = require("child_process");
const { resolveWorkspaceRoot } = require("./workspaceResolver");

const defaultServiceEndpoint = "http://127.0.0.1:18090";

function safeProcessCwd() {
  try {
    return process.cwd();
  } catch {
    return "";
  }
}

function canonicalPath(targetPath) {
  const resolved = path.resolve(String(targetPath || ""));
  try {
    return fs.realpathSync(resolved);
  } catch {
    return resolved;
  }
}

function createRuntimeManager(options) {
  const {
    api,
    config,
    pluginId,
    defaults,
    buildUrl,
    buildAuthHeaders,
    fetchJson,
    pluginDir,
    runtimeStateDirName = "evolution-runtime",
    setupScriptRelativePath = "scripts/setup-runtime.sh",
  } = options;

  const resolvedOpenClawStateDir =
    api.runtime && api.runtime.state && typeof api.runtime.state.resolveStateDir === "function"
      ? api.runtime.state.resolveStateDir()
      : "";
  const baseStateDir = canonicalPath(
    resolvedOpenClawStateDir || process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), ".openclaw"),
  );
  const stateDir = path.resolve(path.join(baseStateDir, runtimeStateDirName));
  const backendLockFile = path.join(stateDir, "backend.lock");
  const runtimeStateFile = path.join(stateDir, "runtime-state.json");
  const runtimeDir = path.join(stateDir, "python-runtime");
  const runtimeVenvDir = path.join(runtimeDir, ".venv");
  const runtimePython = path.join(runtimeVenvDir, "bin", "python");
  const runtimeReadyFile = path.join(stateDir, "runtime-ready.json");
  const backendLogFile = path.join(stateDir, "backend.stderr.log");
  let backendChild = null;
  let ownsBackend = false;
  let backendStartPromise = null;
  const backendLockMaxAgeMs = 10 * 60 * 1000;

  function serviceEndpointUsesDefaultPort() {
    return String(config.serviceEndpoint || "").trim() === defaultServiceEndpoint;
  }

  function probeBindablePort(host, port) {
    return new Promise((resolve, reject) => {
      const server = net.createServer();
      const cleanup = () => {
        try {
          server.close(() => undefined);
        } catch {}
      };
      server.once("error", (error) => {
        cleanup();
        reject(error);
      });
      server.listen(port, host, () => {
        const address = server.address();
        const boundPort = address && typeof address === "object" ? Number(address.port || 0) : 0;
        cleanup();
        resolve(boundPort);
      });
    });
  }

  async function chooseServiceUrlForStartup(listenHost) {
    const current = new URL(config.serviceEndpoint);
    if (!serviceEndpointUsesDefaultPort()) return current;
    try {
      await probeBindablePort(listenHost, Number(current.port || 0));
      return current;
    } catch (error) {
      if (!error || error.code !== "EADDRINUSE") throw error;
      const reboundPort = await probeBindablePort(listenHost, 0);
      current.port = String(reboundPort);
      config.serviceEndpoint = current.toString();
      if (typeof api.setConfig === "function") {
        api.setConfig({ serviceEndpoint: config.serviceEndpoint });
      }
      return current;
    }
  }

  function ensureStateDir() {
    fs.mkdirSync(stateDir, { recursive: true });
  }

  function loadRuntimeState() {
    ensureStateDir();
    try {
      const payload = JSON.parse(fs.readFileSync(runtimeStateFile, "utf8"));
      if (payload && typeof payload === "object") {
        if (payload.instanceId && !config.instanceId) config.instanceId = String(payload.instanceId);
        if (payload.instanceToken && !config.instanceToken) config.instanceToken = String(payload.instanceToken);
        if (payload.lastAutoReviewAt && !config.lastAutoReviewAt)
          config.lastAutoReviewAt = Number(payload.lastAutoReviewAt);
      }
    } catch {}
  }

  function saveRuntimeState() {
    ensureStateDir();
    const payload = {
      instanceId: config.instanceId || "",
      instanceToken: config.instanceToken || "",
      lastAutoReviewAt: Number(config.lastAutoReviewAt || 0),
    };
    fs.writeFileSync(runtimeStateFile, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
  }

  function pythonHasBackendDeps(python) {
    try {
      execFileSync(python, ["-c", "import fastapi, uvicorn"], {
        cwd: runtimeDir,
        stdio: ["ignore", "ignore", "ignore"],
      });
      return true;
    } catch {
      return false;
    }
  }

  function setupScriptPath() {
    return path.join(pluginDir, setupScriptRelativePath);
  }

  function isRuntimeSetup() {
    if (!fs.existsSync(runtimeReadyFile)) return false;
    if (!fs.existsSync(runtimePython)) return false;
    return pythonHasBackendDeps(runtimePython);
  }

  function runtimeSetupError() {
    return new Error(`Evolution backend runtime is not set up. Run \`${setupScriptPath()}\` first.`);
  }

  function backendLockPayload() {
    return {
      pid: process.pid,
      started_at: Date.now(),
      serviceEndpoint: config.serviceEndpoint || "",
    };
  }

  function readBackendLock() {
    try {
      const raw = fs.readFileSync(backendLockFile, "utf8");
      const payload = JSON.parse(raw);
      return payload && typeof payload === "object" ? payload : null;
    } catch {
      return null;
    }
  }

  function isPidAlive(pid) {
    const numericPid = Number(pid || 0);
    if (!Number.isInteger(numericPid) || numericPid <= 0) return false;
    try {
      process.kill(numericPid, 0);
      return true;
    } catch (error) {
      return error && error.code === "EPERM";
    }
  }

  function isStaleBackendLock() {
    const payload = readBackendLock();
    if (payload && Number.isFinite(Number(payload.started_at || 0))) {
      const startedAt = Number(payload.started_at || 0);
      if (startedAt > 0 && Date.now() - startedAt > backendLockMaxAgeMs) return true;
    }
    if (payload && payload.pid && !isPidAlive(payload.pid)) return true;
    try {
      const stat = fs.statSync(backendLockFile);
      return Date.now() - stat.mtimeMs > backendLockMaxAgeMs;
    } catch {
      return false;
    }
  }

  function removeBackendLockIfStale() {
    if (!fs.existsSync(backendLockFile)) return false;
    if (!isStaleBackendLock()) return false;
    try {
      fs.unlinkSync(backendLockFile);
      return true;
    } catch {
      return false;
    }
  }

  function acquireBackendLock() {
    ensureStateDir();
    try {
      const fd = fs.openSync(backendLockFile, "wx");
      fs.writeFileSync(fd, `${JSON.stringify(backendLockPayload(), null, 2)}\n`, "utf8");
      return fd;
    } catch (error) {
      if (error && error.code === "EEXIST" && removeBackendLockIfStale()) {
        const fd = fs.openSync(backendLockFile, "wx");
        fs.writeFileSync(fd, `${JSON.stringify(backendLockPayload(), null, 2)}\n`, "utf8");
        return fd;
      }
      throw error;
    }
  }

  function runRuntimeSetup() {
    execFileSync("/bin/bash", [setupScriptPath()], {
      cwd: pluginDir,
      stdio: ["ignore", "ignore", "pipe"],
      env: Object.assign({}, process.env, {
        OPENCLAW_STATE_DIR: baseStateDir,
      }),
    });
  }

  async function persistPluginConfig() {
    try {
      const runtimeConfig = api.runtime && api.runtime.config;
      if (
        !runtimeConfig ||
        typeof runtimeConfig.loadConfig !== "function" ||
        typeof runtimeConfig.writeConfigFile !== "function"
      ) {
        return;
      }
      const root = runtimeConfig.loadConfig() || {};
      const before = JSON.stringify(root);
      root.plugins = root.plugins || {};
      root.plugins.entries = root.plugins.entries || {};
      root.plugins.entries[pluginId] = root.plugins.entries[pluginId] || {};
      root.plugins.entries[pluginId].enabled = root.plugins.entries[pluginId].enabled !== false;
      root.plugins.entries[pluginId].config = root.plugins.entries[pluginId].config || {};
      root.plugins.entries[pluginId].config.serviceEndpoint =
        root.plugins.entries[pluginId].config.serviceEndpoint || config.serviceEndpoint || "http://127.0.0.1:18090";
      root.plugins.entries[pluginId].config.listenHost =
        root.plugins.entries[pluginId].config.listenHost || config.listenHost || "0.0.0.0";
      delete root.plugins.entries[pluginId].config.openclawCliPath;
      root.plugins.entries[pluginId].config.autoDailyReviewEnabled =
        root.plugins.entries[pluginId].config.autoDailyReviewEnabled ?? Boolean(config.autoDailyReviewEnabled);
      root.plugins.entries[pluginId].config.autoDailyReviewIntervalHours =
        root.plugins.entries[pluginId].config.autoDailyReviewIntervalHours ||
        Number(config.autoDailyReviewIntervalHours || defaults.defaultReviewIntervalHours);
      root.plugins.entries[pluginId].config.sessionStartReviewEnabled =
        root.plugins.entries[pluginId].config.sessionStartReviewEnabled ?? Boolean(config.sessionStartReviewEnabled);
      root.plugins.entries[pluginId].config.sessionStartReviewIntervalHours =
        root.plugins.entries[pluginId].config.sessionStartReviewIntervalHours ||
        Number(config.sessionStartReviewIntervalHours || defaults.defaultSessionStartReviewIntervalHours);
      root.plugins.entries[pluginId].config.sessionStartReviewWindow =
        root.plugins.entries[pluginId].config.sessionStartReviewWindow ||
        config.sessionStartReviewWindow ||
        defaults.defaultSessionStartReviewWindow;
      root.plugins.entries[pluginId].config.sessionStartReviewLimit =
        root.plugins.entries[pluginId].config.sessionStartReviewLimit ||
        Number(config.sessionStartReviewLimit || defaults.defaultSessionStartReviewLimit);
      root.plugins.entries[pluginId].config.timerReviewWindow =
        root.plugins.entries[pluginId].config.timerReviewWindow ||
        config.timerReviewWindow ||
        defaults.defaultTimerReviewWindow;
      root.plugins.entries[pluginId].config.timerReviewLimit =
        root.plugins.entries[pluginId].config.timerReviewLimit ||
        Number(config.timerReviewLimit || defaults.defaultTimerReviewLimit);
      root.plugins.entries[pluginId].config.instanceId = config.instanceId || "";
      root.plugins.entries[pluginId].config.instanceToken = config.instanceToken || "";
      root.plugins.entries[pluginId].config.workspaceRoot = config.workspaceRoot || "";
      const after = JSON.stringify(root);
      if (before !== after) {
        await runtimeConfig.writeConfigFile(root);
      }
    } catch {}
  }

  function isReadyPayload(payload) {
    if (!payload || typeof payload !== "object") return false;
    if (payload.status !== "ok") return false;
    if (payload.plugin_id !== pluginId) return false;
    const payloadRuntimeRoot = String(payload.runtime_root || "").trim();
    if (!payloadRuntimeRoot) return false;
    return (
      canonicalPath(payloadRuntimeRoot) === canonicalPath(stateDir) &&
      payload.db_ready === true &&
      payload.runtime_ready === true
    );
  }

  async function readinessCheck() {
    try {
      const response = await fetch(buildUrl(config.serviceEndpoint, "ready"), {
        method: "GET",
        headers: buildAuthHeaders(config),
      });
      if (!response.ok) return false;
      const payload = JSON.parse(await response.text());
      return isReadyPayload(payload);
    } catch {
      try {
        const raw = execFileSync("curl", ["-fsS", buildUrl(config.serviceEndpoint, "ready")], {
          encoding: "utf8",
          stdio: ["ignore", "pipe", "pipe"],
        });
        const payload = JSON.parse(raw);
        return isReadyPayload(payload);
      } catch {
        return false;
      }
    }
  }

  async function bootstrapInstance() {
    if (config.instanceId && config.instanceToken) return;
    const seed = `pro-${randomBytes(3).toString("hex")}`;
    let defaultAgentWorkspace = "";
    try {
      const runtimeConfig = api.runtime && api.runtime.config;
      const root =
        runtimeConfig && typeof runtimeConfig.loadConfig === "function" ? runtimeConfig.loadConfig() || {} : {};
      defaultAgentWorkspace = String((((root || {}).agents || {}).defaults || {}).workspace || "").trim();
    } catch {}
    const workspaceRoot = resolveWorkspaceRoot({
      configuredRoot: config.workspaceRoot || defaultAgentWorkspace,
      envRoot: process.env.OPENCLAW_WORKSPACE_ROOT,
      cwd: safeProcessCwd(),
      pluginDir,
    });
    fs.mkdirSync(workspaceRoot, { recursive: true });
    const payload = await fetchJson(buildUrl(config.serviceEndpoint, "instances/onboard"), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        instance_id: config.instanceId || seed,
        display_name: config.instanceId || seed,
        workspace_root: workspaceRoot,
      }),
    });
    config.instanceId = payload.id;
    config.instanceToken = payload.instance_token;
    config.workspaceRoot = workspaceRoot;
    saveRuntimeState();
    await persistPluginConfig();
    if (typeof api.setConfig === "function") {
      api.setConfig({
        instanceId: config.instanceId,
        instanceToken: config.instanceToken,
        workspaceRoot: config.workspaceRoot,
      });
    }
  }

  async function startBackend() {
    if (await readinessCheck()) {
      await bootstrapInstance();
      await persistPluginConfig();
      return true;
    }
    if (backendStartPromise) {
      return backendStartPromise;
    }
    backendStartPromise = (async () => {
      const listenHost = String(config.listenHost || "").trim() || "0.0.0.0";
      const serviceUrl = await chooseServiceUrlForStartup(listenHost);
      if (!isRuntimeSetup()) {
        throw runtimeSetupError();
      }
      ensureStateDir();
      let lockFd = null;
      try {
        lockFd = acquireBackendLock();
      } catch (error) {
        if (error && error.code === "EEXIST") {
          for (let attempt = 0; attempt < 30; attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, 500));
            if (await readinessCheck()) {
              await bootstrapInstance();
              await persistPluginConfig();
              return true;
            }
          }
          throw new Error("evolution backend lock exists but ready check never became ready");
        }
        throw error;
      }
      let startupError = "";
      try {
        const backendLogFd = fs.openSync(backendLogFile, "a");
        backendChild = spawn(
          runtimePython,
          [
            "-m",
            "uvicorn",
            "fastapi_service.app:app",
            "--host",
            listenHost,
            "--port",
            String(Number(serviceUrl.port || 8090)),
          ],
          {
            cwd: pluginDir,
            detached: true,
            env: Object.assign({}, process.env, {
              OPENCLAW_STATE_DIR: baseStateDir,
            }),
            stdio: ["ignore", "ignore", backendLogFd],
          },
        );
        fs.closeSync(backendLogFd);
        let childExitCode = null;
        backendChild.on("exit", (code) => {
          childExitCode = code;
        });
        ownsBackend = true;
        for (let attempt = 0; attempt < 30; attempt += 1) {
          await new Promise((resolve) => setTimeout(resolve, 500));
          if (await readinessCheck()) {
            if (typeof backendChild.unref === "function") {
              backendChild.unref();
            }
            await bootstrapInstance();
            await persistPluginConfig();
            return true;
          }
          if (childExitCode !== null) break;
        }
        try {
          startupError = String(fs.readFileSync(backendLogFile, "utf8") || "").trim();
        } catch {}
        throw new Error(
          `evolution backend failed to start${startupError ? `: ${startupError.trim()}` : childExitCode !== null ? ` (exit ${childExitCode})` : ""}`,
        );
      } finally {
        if (lockFd !== null) {
          try {
            fs.closeSync(lockFd);
          } catch {}
          try {
            fs.unlinkSync(backendLockFile);
          } catch {}
        }
      }
    })();
    try {
      return await backendStartPromise;
    } finally {
      backendStartPromise = null;
    }
  }

  async function stopBackend() {
    if (!ownsBackend || !backendChild) return false;
    try {
      backendChild.kill("SIGTERM");
    } catch {}
    backendChild = null;
    ownsBackend = false;
    return true;
  }

  async function ensureReady(options = {}) {
    if (options.serviceStartPromise) {
      await options.serviceStartPromise;
    }
    let healthy = await readinessCheck();
    if (!healthy) {
      await startBackend();
      healthy = await readinessCheck();
    }
    if (!healthy) {
      throw new Error("Evolution backend is not ready. The backend service may still be starting up — retry shortly.");
    }
    if (!config.instanceId || !config.instanceToken) {
      await bootstrapInstance();
    }
  }

  return {
    baseStateDir,
    loadRuntimeState,
    saveRuntimeState,
    persistPluginConfig,
    readinessCheck,
    isRuntimeSetup,
    runRuntimeSetup,
    ensureReady,
    bootstrapInstance,
    startBackend,
    stopBackend,
  };
}

module.exports = {
  createRuntimeManager,
};
