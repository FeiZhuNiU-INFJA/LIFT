function preview(value, max = 160) {
  const text = String(value || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!text) return "";
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

function formatTime(value) {
  const num = Number(value || 0);
  if (!num) return "-";
  const date = new Date(num * 1000);
  if (Number.isNaN(date.getTime())) return "-";
  return `${date.toISOString().replace("T", " ").slice(0, 16)} UTC`;
}

function escapeCell(value) {
  return String(value == null ? "-" : value)
    .replace(/\|/g, "\\|")
    .replace(/\n/g, " ");
}

function buildMarkdownTable(headers, rows) {
  const headerLine = `| ${headers.map(escapeCell).join(" | ")} |`;
  const separatorLine = `| ${headers.map(() => "---").join(" | ")} |`;
  const body = rows.map((row) => `| ${row.map(escapeCell).join(" | ")} |`);
  return [headerLine, separatorLine, ...body].join("\n");
}

function buildFeishuMarkdownCard(title, markdown, template = "blue") {
  return {
    schema: "2.0",
    config: {
      wide_screen_mode: true,
    },
    header: {
      title: {
        tag: "plain_text",
        content: title,
      },
      template,
    },
    body: {
      elements: [
        {
          tag: "markdown",
          content: markdown,
        },
      ],
    },
  };
}

function cardMetaForSubcommand(sub) {
  switch (sub) {
    case "status":
      return { title: "🌱 学习状态", template: "green" };
    case "signals":
      return { title: "🧩 最近记录", template: "wathet" };
    case "expressions":
      return { title: "✨ 已学会的经验", template: "turquoise" };
    case "review":
      return { title: "📘 回看结果", template: "purple" };
    case "report":
      return { title: "📄 日报详情", template: "purple" };
    case "reports":
      return { title: "🗂️ 日报历史", template: "indigo" };
    case "help":
    default:
      return { title: "🌱 使用说明", template: "blue" };
  }
}

function renderStatusCard({ instanceId, serviceEndpoint, expressionCount, signalCount }) {
  return [
    "## 🌱 学习状态",
    "",
    buildMarkdownTable(
      ["项目", "当前值"],
      [
        ["当前实例", instanceId || "-"],
        ["本地服务", serviceEndpoint || "-"],
        ["已学会的经验", expressionCount],
        ["最近记录的问题", signalCount],
      ],
    ),
    "",
    "## 下一步",
    "",
    "查看待启用经验：`/learn expressions --status disabled`",
    "启用经验：`/learn enable <expression_id>`",
    "停用经验：`/learn disable <expression_id>`",
  ].join("\n");
}

function renderSignalsCard(rows) {
  if (!Array.isArray(rows) || !rows.length) {
    return ["## 🧩 最近记录", "", "> 现在还没有记录到新的问题或反馈。"].join("\n");
  }
  return [
    "## 🧩 最近记录",
    "",
    buildMarkdownTable(
      ["类型", "时间", "命中基因", "内容"],
      rows
        .slice(0, 10)
        .map((row) => [
          row.kind || "-",
          formatTime(row.created_at),
          Array.isArray(row.matched_remote_gene_ids) && row.matched_remote_gene_ids.length
            ? row.matched_remote_gene_ids.join(", ")
            : "-",
          preview(row.content, 60),
        ]),
    ),
  ].join("\n");
}

function renderExpressionsCard(rows) {
  if (!Array.isArray(rows) || !rows.length) {
    return ["## ✨ 已学会的经验", "", "> 现在还没有学会新的经验。", "", "查看最近一份日报：`/learn report`"].join("\n");
  }
  const sections = rows
    .slice(0, 10)
    .map((row) => renderExpressionDetailSection(row))
    .join("\n\n");
  return [
    "## ✨ 已学会的经验",
    "",
    sections,
    "",
    "## 下一步",
    "",
    "启用某条经验：`/learn enable <expression_id>`",
    "停用某条经验：`/learn disable <expression_id>`",
  ].join("\n");
}

function expressionStatusText(row) {
  const status = String((row && row.status) || "").trim();
  if (!status) return "-";
  if (status === "disabled") return "disabled (待启用)";
  return status;
}

function renderExpressionDetailSection(row, titlePrefix = "###") {
  const title = `${titlePrefix} \`${row.id || "-"}\``;
  const details = [
    `- 状态：${expressionStatusText(row)}`,
    `- 摘要：${row.summary || "-"}`,
    `- 落点文件：${row.target_file ? `\`${row.target_file}\`` : "-"}`,
    `- 绑定点：${row.binding_ref ? `\`${row.binding_ref}\`` : "-"}`,
    `- Pattern：${row.pattern_key ? `\`${row.pattern_key}\`` : "-"}`,
    `- 基因关联：${row.remote_gene_id ? `\`${row.remote_gene_id}\`` : row.gene_id ? `\`${row.gene_id}\`` : "-"}`,
    `- 命中：${Number(row.hit_count || 0)}`,
    `- 更新时间：${formatTime(row.updated_at || row.created_at || 0)}`,
  ];
  const body = String(row.content || row.summary || "").trim() || "-";
  return [title, "", ...details, "", "```text", body, "```"].join("\n");
}

function renderExpressionActionResult(actionLabel, row) {
  return [
    `## ${actionLabel}`,
    "",
    renderExpressionDetailSection(row),
    "",
    "## 下一步",
    "",
    "查看全部经验：`/learn expressions --all`",
    "查看待启用经验：`/learn expressions --status disabled`",
  ].join("\n");
}

function renderReviewSummary(result) {
  const pendingIds = (Array.isArray(result.created_expression_ids) ? result.created_expression_ids : []).filter(
    Boolean,
  );
  const mutations = Array.isArray(result.mutations) ? result.mutations : [];
  const highlights = mutations
    .filter((item) => item && (item.description || item.target_file || item.target_label))
    .slice(0, 3)
    .map(
      (item) =>
        `- ${item.description || item.target_label || item.target_id || "新增经验"}${item.target_file ? ` · ${item.target_file}` : ""}`,
    );
  return [
    "## 今日结论",
    "",
    result.summary_text || "这次回看已完成，下面是最重要的结果。",
    "",
    "## 今日新增经验",
    "",
    highlights.length ? highlights.join("\n") : `- 新增经验 ${pendingIds.length} 条`,
    "",
    buildMarkdownTable(
      ["项目", "结果"],
      [
        ["状态", result.status || "-"],
        ["查看对话", result.session_count || 0],
        ["沿用经验", (result.matched_expression_ids || []).length],
        ["新增经验", (result.created_expression_ids || []).length],
      ],
    ),
    "",
    pendingIds.length
      ? [
          "## 待你决定启用",
          "",
          ...pendingIds.map((id) => `- ${id}`),
          "",
          "启用：`/learn enable <expression_id>`",
          "停用：`/learn disable <expression_id>`",
        ].join("\n")
      : "## 待你决定启用\n\n这次没有新增待启用经验。",
  ].join("\n");
}

function renderReviewQueued(meta) {
  return [
    "## 回看已开始",
    "",
    `review ${meta.reviewId || "-"} 已进入后台执行。`,
    "",
    buildMarkdownTable(
      ["项目", "值"],
      [
        ["Signals", meta.signalCount || 0],
        ["对话", meta.sessionCount || 0],
        ["改动文件", meta.changedFileCount || 0],
        ["预估耗时", `${Number(meta.estimateSeconds || 0)}s`],
      ],
    ),
    "",
    "结果写入后可查看：`/learn report`",
  ].join("\n");
}

function reportSummaryText(review) {
  const value = String((review && (review.report_markdown || review.error_text)) || "").trim();
  if (!value) return "现在还没有 review 生成的日报。";
  const firstMeaningful = value
    .split(/\n+/)
    .map((item) => item.trim())
    .find((item) => item && !item.startsWith("#"));
  return firstMeaningful || value.slice(0, 180);
}

function isManualReview(review) {
  const reason = String((review && review.reason_text) || "")
    .trim()
    .toLowerCase();
  return reason === "command" || reason.includes("manual");
}

function reviewTriggerLabel(review) {
  return isManualReview(review) ? "手动触发" : "常规回看";
}

function reviewReasonLabel(review) {
  const reason = String((review && review.reason_text) || "").trim();
  if (!reason) return reviewTriggerLabel(review);
  if (isManualReview(review)) return `${reviewTriggerLabel(review)} · ${reason}`;
  return reason;
}

function normalizeReviewStats(review) {
  const labelMap = {
    signals: "反馈",
    changes: "新增改动",
    applied: "待你决定",
    sessions: "对话",
  };
  const stats =
    Array.isArray(review && review.stats) && review.stats.length
      ? review.stats
      : [
          { label: "signals", value: (review && review.daySignals) || 0 },
          { label: "changes", value: (review && review.dayWorkspaceChanges) || 0 },
          {
            label: "applied",
            value:
              ((review && review.created_expression_ids) || []).length +
                ((review && review.updated_expression_ids) || []).length || 0,
          },
          { label: "sessions", value: (review && review.session_count) || 0 },
        ];
  return stats.map((item) => ({
    label: labelMap[String(item.label || "")] || String(item.label || "统计"),
    value: item.value,
  }));
}

function renderReviewHistory(rows) {
  if (!Array.isArray(rows) || !rows.length) {
    return ["## 回看历史", "", "> 现在还没有已完成的回看记录。", "", "运行一次回看：`/learn review`"].join("\n");
  }
  return [
    "## 回看历史",
    "",
    buildMarkdownTable(
      ["Review", "触发", "时间", "摘要"],
      rows.map((row) => [
        row.id || "-",
        reviewTriggerLabel(row),
        formatTime(row.created_at),
        preview(row.summary_text || reportSummaryText(row), 60),
      ]),
    ),
    "",
    "查看某次详情：`/learn report --id <review_id>`",
    "查看最近一份日报：`/learn report`",
  ].join("\n");
}

function renderReviewDetail(review, raw = false) {
  const body = String((review && (review.report_markdown || review.error_text)) || "").trim() || "暂无内容";
  if (raw) return body;
  const stats = normalizeReviewStats(review);
  const metaRows = [
    ["Review", (review && review.id) || "-"],
    ["状态", (review && review.status) || "-"],
    ["触发", reviewTriggerLabel(review)],
    ["原因", reviewReasonLabel(review)],
    ["时间", formatTime((review && (review.created_at || review.updated_at)) || 0)],
    ["查看对话", (review && review.session_count) || 0],
    ["沿用经验", ((review && review.matched_expression_ids) || []).length],
    ["新增经验", ((review && review.created_expression_ids) || []).length],
    ["更新经验", ((review && review.updated_expression_ids) || []).length],
  ];
  if (review && review.focus_session_id) metaRows.push(["聚焦会话", review.focus_session_id]);
  return [
    "## 回看详情",
    "",
    buildMarkdownTable(["项目", "值"], metaRows),
    "",
    "## 摘要",
    "",
    review && review.summary_text ? review.summary_text : reportSummaryText(review),
    "",
    "## 统计",
    "",
    buildMarkdownTable(
      ["指标", "值"],
      stats.map((item) => [item.label, item.value]),
    ),
    "",
    "## 正文",
    "",
    body,
  ].join("\n");
}

function renderHelp() {
  const commandRows = [
    ["`/learn status`", "看当前实例、服务和学习状态"],
    ["`/learn signals`", "看最近记住的报错和反馈"],
    ["`/learn expressions`", "看已经学到的经验"],
    ["`/learn enable <expression_id>`", "启用一条待生效经验"],
    ["`/learn disable <expression_id>`", "停用一条经验"],
    ["`/learn review`", "立即触发一次新的回看"],
    ["`/learn report`", "看最近一条已完成 review 日报"],
    ["`/learn reports`", "看最近几次 review 历史"],
  ];
  return [
    "## 🌱 Learn 帮助",
    "",
    "记住报错和你的纠正，下次优先少走弯路。",
    "",
    "## 说明",
    "",
    "- 作用：把错误、纠正和回看结果沉淀成可复用经验",
    "- 默认方式：正常聊天即可，不需要额外操作",
    "- 命令格式：统一使用 `/learn <子命令>`",
    "",
    "## 命令",
    "",
    buildMarkdownTable(["命令", "作用"], commandRows),
    "",
    "## 🔁 最简单的流程",
    "",
    buildMarkdownTable(
      ["阶段", "结果"],
      [
        ["1. 报错或纠正", "插件记录 signal"],
        ["2. 触发回看", "整理最近对话和 workspace 改动"],
        ["3. 形成经验", "生成或更新 expression"],
        ["4. 下次再遇到", "优先把经验注入上下文"],
      ],
    ),
  ].join("\n");
}

module.exports = {
  preview,
  buildFeishuMarkdownCard,
  cardMetaForSubcommand,
  renderStatusCard,
  renderSignalsCard,
  renderExpressionsCard,
  renderExpressionActionResult,
  renderReviewSummary,
  renderReviewQueued,
  renderReviewHistory,
  renderReviewDetail,
  renderHelp,
};
