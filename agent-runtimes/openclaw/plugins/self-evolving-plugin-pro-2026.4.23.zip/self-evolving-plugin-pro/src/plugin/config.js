const pluginId = "self-evolving-plugin-pro";
const defaultReviewIntervalHours = 24;
const defaultSessionStartReviewWindow = "6h";
const defaultTimerReviewWindow = "24h";
const defaultSessionStartReviewLimit = 5;
const defaultTimerReviewLimit = 20;
const defaultSessionStartReviewIntervalHours = 4;
const SIGNAL_RECORD_HEADING = "### 学习记录";

/**
 * @typedef {Object} PluginConfig
 * @property {string} serviceEndpoint
 * @property {string} listenHost
 * @property {string} workspaceRoot
 * @property {boolean} autoDailyReviewEnabled
 * @property {number} autoDailyReviewIntervalHours
 * @property {boolean} sessionStartReviewEnabled
 * @property {number} sessionStartReviewIntervalHours
 * @property {string} sessionStartReviewWindow
 * @property {number} sessionStartReviewLimit
 * @property {string} timerReviewWindow
 * @property {number} timerReviewLimit
 * @property {string} [instanceId]
 * @property {string} [instanceToken]
 * @property {string} [modelId]
 * @property {number} [lastAutoReviewAt]
 * @property {number} [lastSessionStartReviewAt]
 */

/**
 * @param {Partial<PluginConfig>} [apiConfig]
 * @returns {PluginConfig}
 */
function createConfig(apiConfig = {}) {
  return /** @type {PluginConfig} */ (
    Object.assign(
      {
        serviceEndpoint: "http://127.0.0.1:18090",
        listenHost: "0.0.0.0",
        workspaceRoot: "",
        autoDailyReviewEnabled: true,
        autoDailyReviewIntervalHours: defaultReviewIntervalHours,
        sessionStartReviewEnabled: true,
        sessionStartReviewIntervalHours: defaultSessionStartReviewIntervalHours,
        sessionStartReviewWindow: defaultSessionStartReviewWindow,
        sessionStartReviewLimit: defaultSessionStartReviewLimit,
        timerReviewWindow: defaultTimerReviewWindow,
        timerReviewLimit: defaultTimerReviewLimit,
      },
      apiConfig || {},
    )
  );
}

module.exports = {
  pluginId,
  defaultReviewIntervalHours,
  defaultSessionStartReviewWindow,
  defaultTimerReviewWindow,
  defaultSessionStartReviewLimit,
  defaultTimerReviewLimit,
  defaultSessionStartReviewIntervalHours,
  SIGNAL_RECORD_HEADING,
  createConfig,
};
