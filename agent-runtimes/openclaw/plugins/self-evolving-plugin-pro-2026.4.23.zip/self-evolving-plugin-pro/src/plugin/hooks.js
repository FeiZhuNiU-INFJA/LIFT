function createBeforePromptBuildHandler(options) {
  const {
    extractText,
    extractSessionId,
    logger,
    config,
    latestUserTextBySession,
    ensureReady,
    listExpressions,
    buildSignalProtocolXml,
    buildExpressionXml,
    consumePendingReviewNotice,
  } = options;

  return async function beforePromptBuild(event, ctx) {
    const messages = Array.isArray((event || {}).messages) ? event.messages : [];
    const lastText = extractText(messages[messages.length - 1]);
    const sessionId = extractSessionId(ctx);
    if (lastText) {
      latestUserTextBySession.set(sessionId, lastText);
    }
    const reviewNotice = consumePendingReviewNotice ? consumePendingReviewNotice() : null;
    const protocolParts = [
      buildSignalProtocolXml({
        serviceEndpoint: config.serviceEndpoint,
        instanceId: config.instanceId,
        instanceToken: config.instanceToken,
        sessionId,
      }),
    ];
    if (reviewNotice) {
      protocolParts.push(`<self-evolving><notice>${reviewNotice}</notice></self-evolving>`);
    }
    // prependSystemContext goes into the agent system prompt (not the user
    // turn), so webchat never renders it and providers can prompt-cache it.
    const prependSystemContext = protocolParts.join("\n");
    try {
      await ensureReady();
    } catch (error) {
      logger.warn && logger.warn("evolution backend unavailable in before_prompt_build", { error: String(error) });
      return {
        prependSystemContext,
      };
    }
    const expressions = await listExpressions("active").catch((error) => {
      logger.warn && logger.warn("evolution expression load failed", { error: String(error) });
      return [];
    });
    const appendSystemContext = buildExpressionXml(expressions);
    return {
      prependSystemContext,
      appendSystemContext: appendSystemContext || undefined,
    };
  };
}

function createAfterToolCallHandler(options) {
  const { extractSessionId, extractUserId, postSignal } = options;

  return async function afterToolCall(event, ctx) {
    const sessionId = extractSessionId(ctx);
    const userId = extractUserId(ctx);
    const toolName = event && event.toolName ? event.toolName : "unknown_tool";
    const error = event && event.error ? String(event.error) : "";
    const failed = Boolean(error);
    if (!failed) return;
    await postSignal({
      session_id: sessionId,
      user_id: userId,
      kind: "tool_failure",
      content: error,
      tags: ["tool", "failure", toolName],
      trust: 0.95,
      source: "tool_runtime",
      source_ref: `${sessionId}:${toolName}`,
      raw_payload: event || {},
      classifier_note: "captured from after_tool_call failure hook",
    });
  };
}

function createLlmOutputHandler(options) {
  const {
    extractSessionId,
    extractUserId,
    latestUserTextBySession,
    processedSignalRunIds,
    parseInternalSignals,
    classifyUserFeedback,
    buildFeedbackSignalContent,
    postSignal,
  } = options;

  return async function llmOutput(event, ctx) {
    const runId = String((event || {}).runId || "");
    if (!runId || processedSignalRunIds.has(runId)) return;
    const texts = Array.isArray(event && event.assistantTexts) ? event.assistantTexts : [];
    const parsedSignals = texts.flatMap((text) => parseInternalSignals(text));
    if (!parsedSignals.length) return;
    processedSignalRunIds.add(runId);
    const sessionId = extractSessionId(ctx) || String((event && event.sessionId) || "unknown-session");
    const userId = extractUserId(ctx);
    const lastUserText = latestUserTextBySession.get(sessionId) || "";
    const coarseFeedback = classifyUserFeedback(lastUserText);
    for (const signal of parsedSignals) {
      await postSignal({
        session_id: sessionId,
        user_id: userId,
        kind: signal.kind,
        content: buildFeedbackSignalContent(lastUserText, signal.content, signal.kind),
        tags: signal.tags.length ? signal.tags : ["feedback", signal.kind],
        trust: signal.trust,
        source: "llm_output_feedback",
        source_ref: runId,
        raw_payload: {
          raw_kind: signal.raw_kind,
          assistant_texts: texts.slice(0, 3),
          user_feedback: lastUserText,
        },
        classifier_note: coarseFeedback.promptHint || "parsed from structured learning record",
      });
    }
    if (processedSignalRunIds.size > 500) {
      const keep = Array.from(processedSignalRunIds).slice(-200);
      processedSignalRunIds.clear();
      for (const id of keep) processedSignalRunIds.add(id);
    }
  };
}

module.exports = {
  createBeforePromptBuildHandler,
  createAfterToolCallHandler,
  createLlmOutputHandler,
};
