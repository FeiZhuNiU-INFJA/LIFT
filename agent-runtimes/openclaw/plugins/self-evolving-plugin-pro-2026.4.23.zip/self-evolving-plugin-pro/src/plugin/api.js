function createPluginApi(options) {
  const { config, logger, fetchJson, buildUrl, buildAuthHeaders } = options;

  async function postSignal(payload) {
    if (!config.instanceId || !config.instanceToken) return;
    try {
      await fetchJson(buildUrl(config.serviceEndpoint, "signals"), {
        method: "POST",
        headers: buildAuthHeaders(config),
        body: JSON.stringify(Object.assign({ instance_id: config.instanceId }, payload)),
      });
    } catch (error) {
      logger.warn && logger.warn("signal post failed", { error: String(error) });
    }
  }

  async function listSignals(limit, sessionId) {
    const params = new URLSearchParams({ instance_id: config.instanceId, limit: String(limit || 20) });
    if (sessionId) params.set("session_id", sessionId);
    return fetchJson(`${buildUrl(config.serviceEndpoint, "signals")}?${params.toString()}`, {
      headers: buildAuthHeaders(config),
    });
  }

  async function listExpressions(status = "") {
    const params = new URLSearchParams({ instance_id: config.instanceId });
    if (status) params.set("status", status);
    if (config.modelId) params.set("model_id", config.modelId);
    return fetchJson(`${buildUrl(config.serviceEndpoint, "expressions")}?${params.toString()}`, {
      headers: buildAuthHeaders(config),
    });
  }

  async function listReviews(limit = 10, status = "") {
    const params = new URLSearchParams({ instance_id: config.instanceId, limit: String(limit || 10) });
    if (status) params.set("status", status);
    return fetchJson(`${buildUrl(config.serviceEndpoint, "reviews")}?${params.toString()}`, {
      headers: buildAuthHeaders(config),
    });
  }

  async function getReview(reviewId) {
    return fetchJson(buildUrl(config.serviceEndpoint, `reviews/${encodeURIComponent(reviewId)}`), {
      headers: buildAuthHeaders(config),
    });
  }

  async function flushGeneEvents(limit = 100) {
    return fetchJson(buildUrl(config.serviceEndpoint, "genes/events/flush"), {
      method: "POST",
      headers: buildAuthHeaders(config),
      body: JSON.stringify({
        instance_id: config.instanceId,
        limit: Number(limit || 100),
      }),
    });
  }

  async function flushGeneEventsBestEffort(source, limit = 100) {
    if (!config.instanceId || !config.instanceToken) return null;
    try {
      const result = await flushGeneEvents(limit);
      if (result && result.error) {
        logger.warn &&
          logger.warn("gene event flush returned error", {
            source,
            error: String(result.error),
            accepted: Number(result.accepted || 0),
            sent: Number(result.sent || 0),
          });
      }
      return result;
    } catch (error) {
      logger.warn && logger.warn("gene event flush failed", { source, error: String(error) });
      return null;
    }
  }

  async function patchExpression(expressionId, payload) {
    return fetchJson(buildUrl(config.serviceEndpoint, `expressions/${encodeURIComponent(expressionId)}`), {
      method: "PATCH",
      headers: buildAuthHeaders(config),
      body: JSON.stringify(Object.assign({ instance_id: config.instanceId }, payload)),
    });
  }

  return {
    postSignal,
    listSignals,
    listExpressions,
    listReviews,
    getReview,
    flushGeneEvents,
    flushGeneEventsBestEffort,
    patchExpression,
  };
}

module.exports = {
  createPluginApi,
};
