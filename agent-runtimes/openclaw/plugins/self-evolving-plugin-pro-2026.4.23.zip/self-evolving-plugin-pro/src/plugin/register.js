const path = require("path");
const { extractText, extractSessionId, extractUserId } = require("../runtimeHelpers");
const {
  buildFeishuMarkdownCard,
  cardMetaForSubcommand,
  renderStatusCard,
  renderSignalsCard,
  renderExpressionsCard,
  renderExpressionActionResult,
  renderReviewSummary,
  renderReviewHistory,
  renderReviewDetail,
  renderHelp,
} = require("../learnUi");
const { createRuntimeManager } = require("../runtimeManager");
const {
  pluginId,
  defaultReviewIntervalHours,
  defaultSessionStartReviewWindow,
  defaultTimerReviewWindow,
  defaultSessionStartReviewLimit,
  defaultTimerReviewLimit,
  defaultSessionStartReviewIntervalHours,
  createConfig,
} = require("./config");
const { buildUrl, buildAuthHeaders, fetchJson } = require("./client");
const { createPluginApi } = require("./api");
const {
  buildExpressionXml,
  buildSignalProtocolXml,
  parseInternalSignals,
  buildFeedbackSignalContent,
  classifyUserFeedback,
} = require("./signals");
const { createAutoReview } = require("./autoReview");
const { createBeforePromptBuildHandler, createAfterToolCallHandler, createLlmOutputHandler } = require("./hooks");
const { createReviewWorker } = require("../review/worker");
const { handleHelp } = require("../commands/help");
const { handleStatus } = require("../commands/status");
const { handleSignals } = require("../commands/signals");
const { handleExpressions, handleEnable, handleDisable } = require("../commands/expressions");
const { handleReports, handleReport } = require("../commands/reports");
const { handleReview } = require("../commands/review");

function parseArgs(input) {
  const tokens = String(input || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  const [, sub = "help", ...rest] = tokens;
  const flags = {};
  const positionals = [];
  for (let index = 0; index < rest.length; index += 1) {
    const token = rest[index];
    if (token.startsWith("--")) {
      const key = token.slice(2);
      const next = rest[index + 1];
      if (!next || next.startsWith("--")) {
        flags[key] = true;
      } else {
        flags[key] = next;
        index += 1;
      }
      continue;
    }
    positionals.push(token);
  }
  return { sub, flags, positionals };
}

module.exports = function register(api) {
  const logger = api.logger || console;
  const config = createConfig(api.config || {});
  let backendServicePromise = null;
  const processedSignalRunIds = new Set();
  const latestUserTextBySession = new Map();
  const runtimeManager = createRuntimeManager({
    api,
    config,
    pluginId,
    defaults: {
      defaultReviewIntervalHours,
      defaultSessionStartReviewIntervalHours,
      defaultSessionStartReviewWindow,
      defaultSessionStartReviewLimit,
      defaultTimerReviewWindow,
      defaultTimerReviewLimit,
    },
    buildUrl,
    buildAuthHeaders,
    fetchJson,
    pluginDir: path.resolve(__dirname, "../.."),
  });
  const {
    loadRuntimeState,
    saveRuntimeState,
    persistPluginConfig,
    readinessCheck,
    isRuntimeSetup,
    runRuntimeSetup,
    ensureReady: ensureRuntimeReady,
    bootstrapInstance,
    startBackend,
    stopBackend,
  } = runtimeManager;
  const {
    postSignal,
    listSignals,
    listExpressions,
    listReviews,
    getReview,
    flushGeneEventsBestEffort,
    patchExpression,
  } = createPluginApi({
    config,
    logger,
    fetchJson,
    buildUrl,
    buildAuthHeaders,
  });

  loadRuntimeState();

  async function ensureReady() {
    await ensureRuntimeReady({ serviceStartPromise: backendServicePromise });
  }

  const runReviewWorker = createReviewWorker({
    ensureReady,
    fetchJson,
    buildUrl,
    buildAuthHeaders,
    config,
    cwd: path.resolve(__dirname, "../.."),
  });
  const { runReviewWorkerAndFlush, maybeRunAutoReview, startReviewTimer, stopReviewTimer, consumePendingReviewNotice } =
    createAutoReview({
      api,
      config,
      logger,
      extractSessionId,
      saveRuntimeState,
      runReviewWorker,
      flushGeneEventsBestEffort,
      defaultReviewIntervalHours,
      defaultSessionStartReviewWindow,
      defaultTimerReviewWindow,
      defaultSessionStartReviewLimit,
      defaultTimerReviewLimit,
    });
  const beforePromptBuild = createBeforePromptBuildHandler({
    extractText,
    extractSessionId,
    logger,
    config,
    latestUserTextBySession,
    ensureReady,
    listExpressions,
    buildSignalProtocolXml,
    buildExpressionXml,
    consumePendingReviewNotice,
  });
  const afterToolCall = createAfterToolCallHandler({
    extractSessionId,
    extractUserId,
    postSignal,
  });
  const llmOutput = createLlmOutputHandler({
    extractSessionId,
    extractUserId,
    latestUserTextBySession,
    processedSignalRunIds,
    parseInternalSignals,
    classifyUserFeedback,
    buildFeedbackSignalContent,
    postSignal,
  });
  async function handleLearn(raw) {
    let options = {};
    if (raw && typeof raw === "object") {
      options = raw;
      raw = options.raw;
    }
    const parsed = parseArgs(raw);
    if (parsed.sub === "help") return handleHelp({ renderHelp });
    await ensureReady();
    if (parsed.sub === "status") return handleStatus({ listExpressions, listSignals, config, renderStatusCard });
    if (parsed.sub === "signals") return handleSignals({ parsed, listSignals, renderSignalsCard });
    if (parsed.sub === "expressions") return handleExpressions({ parsed, listExpressions, renderExpressionsCard });
    if (parsed.sub === "enable") return handleEnable({ parsed, patchExpression, renderExpressionActionResult });
    if (parsed.sub === "disable") return handleDisable({ parsed, patchExpression, renderExpressionActionResult });
    if (parsed.sub === "reports") return handleReports({ parsed, listReviews, renderReviewHistory });
    if (parsed.sub === "report") return handleReport({ parsed, listReviews, getReview, renderReviewDetail });
    if (parsed.sub === "review")
      return handleReview({
        parsed,
        config,
        defaults: { defaultTimerReviewWindow, defaultTimerReviewLimit },
        runReviewWorker: runReviewWorkerAndFlush,
        prepareReviewRun: runReviewWorker.prepareReviewRun,
        renderReviewSummary,
      });
    return renderHelp();
  }

  api.registerService({
    id: `${pluginId}:backend`,
    start: async () => {
      if (await readinessCheck()) {
        await bootstrapInstance();
        await persistPluginConfig();
        startReviewTimer();
        await flushGeneEventsBestEffort("startup");
        return;
      }
      if (!isRuntimeSetup()) {
        runRuntimeSetup();
      }
      backendServicePromise = startBackend();
      await backendServicePromise;
      startReviewTimer();
      await flushGeneEventsBestEffort("startup");
    },
    stop: async () => {
      stopReviewTimer();
      backendServicePromise = null;
      await stopBackend();
    },
  });

  // `session_start` is dispatched by OpenClaw's gateway path
  // (getReplyFromConfig → initSessionState → runSessionStart) every time
  // `isNewSession === true`. Production traffic always enters via gateway
  // (webchat + feishu plugin), so this fires exactly once per new session.
  // Fire-and-forget: runReviewWorker spawns a child `openclaw agent` that
  // can take minutes, and OpenClaw awaits session_start handlers before
  // the user can send their first message — we must not block that.
  api.on("session_start", async (_event, ctx) => {
    await ensureReady();
    maybeRunAutoReview("session_start", ctx).catch(
      (error) => logger.warn && logger.warn("session_start auto review failed", { error: String(error) }),
    );
  });

  api.on("before_prompt_build", beforePromptBuild);
  api.on("after_tool_call", afterToolCall);
  api.on("llm_output", llmOutput);

  api.registerCommand({
    name: "learn",
    nativeNames: {
      default: "learn",
      feishu: "learn",
      lark: "learn",
      discord: "learn",
      telegram: "learn",
      mattermost: "learn",
    },
    description: "Self-evolving plugin commands",
    acceptsArgs: true,
    requireAuth: false,
    handler: async (ctx = {}) => {
      const raw = `/learn ${String(ctx.args || "").trim()}`.trim() || "/learn help";
      const parsed = parseArgs(raw);
      const text = await handleLearn({ raw, executionMode: "chat" });
      const card = buildFeishuMarkdownCard(
        cardMetaForSubcommand(parsed.sub).title,
        text,
        cardMetaForSubcommand(parsed.sub).template,
      );
      return {
        text,
        channelData: {
          feishu: {
            card,
          },
        },
      };
    },
  });

  api.registerCli(
    ({ program }) => {
      const learn = program.command("learn").description("Self-evolving plugin commands");

      const emit = async (raw) => {
        try {
          console.log(await handleLearn({ raw, executionMode: "cli" }));
        } catch (error) {
          console.error(`Command failed: ${String(error.message || error)}`);
          process.exitCode = 1;
        }
      };

      learn
        .command("status")
        .description("Show plugin status")
        .action(async () => {
          await emit("/learn status");
        });

      learn
        .command("signals")
        .description("Show recent collected signals")
        .option("--limit <n>", "Max signals", "20")
        .action(async (opts) => {
          await emit(`/learn signals --limit ${opts.limit || 20}`);
        });

      learn
        .command("expressions")
        .description("List active learned expressions")
        .option("--all", "List all expressions")
        .option("--status <status>", "Filter by status")
        .action(async (opts) => {
          const all = opts && opts.all ? " --all" : "";
          const status = opts && opts.status ? ` --status ${opts.status}` : "";
          await emit(`/learn expressions${all}${status}`);
        });

      learn
        .command("enable")
        .description("Enable a pending expression")
        .argument("<expression_id>")
        .action(async (expressionId) => {
          await emit(`/learn enable ${expressionId}`);
        });

      learn
        .command("disable")
        .description("Disable an expression")
        .argument("<expression_id>")
        .action(async (expressionId) => {
          await emit(`/learn disable ${expressionId}`);
        });

      learn
        .command("review")
        .description("Run a bounded daily review")
        .option("--since <window>", "Review window", "24h")
        .action(async (opts) => {
          await emit(`/learn review --since ${opts.since || "24h"}`);
        });

      learn
        .command("report")
        .description("Show the latest persisted review report")
        .option("--id <review_id>", "Show a specific persisted review")
        .option("--raw", "Print only the persisted report body")
        .action(async (opts) => {
          const id = opts && opts.id ? ` --id ${opts.id}` : "";
          const raw = opts && opts.raw ? " --raw" : "";
          await emit(`/learn report${id}${raw}`);
        });

      learn
        .command("reports")
        .description("List persisted review history")
        .option("--limit <n>", "Max reviews", "10")
        .option("--status <status>", "Filter by status", "completed")
        .action(async (opts) => {
          const status = opts && opts.status ? ` --status ${opts.status}` : "";
          await emit(`/learn reports --limit ${opts.limit || 10}${status}`);
        });
    },
    { commands: ["learn"] },
  );
};
