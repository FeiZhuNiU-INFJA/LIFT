const { execFileSync } = require("child_process");

function ensureJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function buildUrl(base, segment) {
  const normalizedBase = String(base || "").replace(/\/+$/, "");
  const normalizedSegment = String(segment || "").replace(/^\/+/, "");
  return `${normalizedBase}/${normalizedSegment}`;
}

function buildAuthHeaders(config) {
  const headers = { "content-type": "application/json" };
  const instanceId = String(config.instanceId || "").trim();
  const instanceToken = String(config.instanceToken || "").trim();
  if (instanceId) headers["x-openclaw-instance-id"] = instanceId;
  if (instanceToken) headers["x-openclaw-instance-token"] = instanceToken;
  return headers;
}

async function fetchJson(url, init = {}) {
  try {
    const response = await fetch(url, init);
    const text = await response.text();
    const payload = ensureJson(text, null);
    if (!response.ok) {
      const message = payload && payload.detail ? payload.detail : text || response.statusText;
      throw new Error(`${response.status} ${message}`);
    }
    return payload;
  } catch {
    const method = String((init && init.method) || "GET").toUpperCase();
    const headers = Object.assign({}, (init && init.headers) || {});
    const args = ["-fsS", "-X", method, url];
    for (const [key, value] of Object.entries(headers)) {
      args.push("-H", `${key}: ${value}`);
    }
    if (init && init.body) {
      args.push("--data", String(init.body));
    }
    const raw = execFileSync("curl", args, { encoding: "utf8" });
    return ensureJson(raw, raw);
  }
}

module.exports = {
  ensureJson,
  buildUrl,
  buildAuthHeaders,
  fetchJson,
};
