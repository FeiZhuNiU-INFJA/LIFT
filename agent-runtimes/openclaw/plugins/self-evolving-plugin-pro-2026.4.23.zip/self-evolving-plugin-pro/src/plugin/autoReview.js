function createAutoReview(options) {
  const {
    api,
    config,
    logger,
    extractSessionId,
    saveRuntimeState,
    runReviewWorker,
    flushGeneEventsBestEffort,
    defaultReviewIntervalHours,
    defaultSessionStartReviewWindow,
    defaultTimerReviewWindow,
    defaultSessionStartReviewLimit,
    defaultTimerReviewLimit,
  } = options;

  let reviewTimer = null;
  let pendingReviewNotice = null;

  function runReviewWorkerAndFlush(request) {
    return runReviewWorker(request).then(async (result) => {
      await flushGeneEventsBestEffort("review");
      return result;
    });
  }

  function reviewPlanForReason(reason, ctx) {
    const focusSessionId = extractSessionId(ctx);
    if (reason === "session_start") {
      return {
        since: String(config.sessionStartReviewWindow || defaultSessionStartReviewWindow),
        limit: Number(config.sessionStartReviewLimit || defaultSessionStartReviewLimit),
        focusSessionId: focusSessionId === "unknown-session" ? null : focusSessionId,
      };
    }
    return {
      since: String(config.timerReviewWindow || defaultTimerReviewWindow),
      limit: Number(config.timerReviewLimit || defaultTimerReviewLimit),
      focusSessionId: null,
    };
  }

  async function maybeRunAutoReview(reason, ctx) {
    const isSessionStart = reason === "session_start";
    if (isSessionStart && !config.sessionStartReviewEnabled) return null;
    if (!isSessionStart && !config.autoDailyReviewEnabled) return null;
    // Session-start review fires every time OpenClaw tells us a new session
    // began (api.on("session_start", ...)). OpenClaw already dedupes:
    // runSessionStart only fires when isNewSession === true inside
    // initSessionState (gateway path — webchat + feishu). No time throttle,
    // no plugin-side dedup needed; one review per new gateway session.
    // Timer review still has its own 24h cadence below because the timer is
    // a periodic thing, not per-session.
    if (!isSessionStart) {
      const last = Number(config.lastAutoReviewAt || 0);
      const intervalHours = Number(config.autoDailyReviewIntervalHours || defaultReviewIntervalHours);
      if (Date.now() - last < intervalHours * 3600 * 1000) return null;
      config.lastAutoReviewAt = Date.now();
      saveRuntimeState();
      if (typeof api.setConfig === "function") {
        api.setConfig({ lastAutoReviewAt: config.lastAutoReviewAt });
      }
    }
    const plan = reviewPlanForReason(reason, ctx);
    const result = await runReviewWorker({
      since: plan.since,
      reason,
      limit: plan.limit,
      focusSessionId: plan.focusSessionId,
    });
    await flushGeneEventsBestEffort(`review:${reason}`);
    const reviewId = result && result.id ? result.id : "";
    const reviewStatus = result && result.status ? result.status : "";
    logger.info && logger.info(`evolution auto-review completed (${reason})`, { reviewId, status: reviewStatus });
    if (reviewStatus === "completed") {
      pendingReviewNotice = `自动回看已完成 (${reason}，review_id=${reviewId})，可用 /learn report 查看详情。`;
    }
    return result;
  }

  function startReviewTimer() {
    reviewTimer = setInterval(
      async () => {
        await flushGeneEventsBestEffort("timer");
        maybeRunAutoReview("timer").catch(
          (error) => logger.warn && logger.warn("evolution auto review failed", { error: String(error) }),
        );
      },
      5 * 60 * 1000,
    );
    if (reviewTimer && typeof reviewTimer.unref === "function") {
      reviewTimer.unref();
    }
    return reviewTimer;
  }

  function stopReviewTimer() {
    if (reviewTimer) clearInterval(reviewTimer);
    reviewTimer = null;
  }

  function consumePendingReviewNotice() {
    const notice = pendingReviewNotice;
    pendingReviewNotice = null;
    return notice;
  }

  return {
    runReviewWorkerAndFlush,
    reviewPlanForReason,
    maybeRunAutoReview,
    startReviewTimer,
    stopReviewTimer,
    consumePendingReviewNotice,
  };
}

module.exports = {
  createAutoReview,
};
