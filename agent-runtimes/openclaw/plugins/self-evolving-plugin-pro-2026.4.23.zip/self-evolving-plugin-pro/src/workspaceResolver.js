const fs = require("fs");
const os = require("os");
const path = require("path");

function safeProcessCwd() {
  try {
    return process.cwd();
  } catch {
    return "";
  }
}

function isWorkspaceRoot(candidate) {
  const target = String(candidate || "").trim();
  if (!target) return false;
  try {
    const resolved = path.resolve(target);
    if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) return false;
    const required = ["AGENTS.md", "SOUL.md", "IDENTITY.md", "USER.md"];
    return required.every((name) => fs.existsSync(path.join(resolved, name)));
  } catch {
    return false;
  }
}

function resolveExplicitRoot(candidate) {
  const target = String(candidate || "").trim();
  if (!target) return "";
  try {
    return path.resolve(target);
  } catch {
    return "";
  }
}

function resolveWorkspaceRoot(options = {}) {
  const configuredRoot = resolveExplicitRoot(options.configuredRoot);
  if (configuredRoot) return configuredRoot;

  const envRoot = resolveExplicitRoot(options.envRoot || process.env.OPENCLAW_WORKSPACE_ROOT);
  if (envRoot) return envRoot;

  const cwd = String(options.cwd || safeProcessCwd() || "").trim();
  if (isWorkspaceRoot(cwd)) return path.resolve(cwd);

  const cwdOpenClawWorkspace = cwd ? path.join(cwd, ".openclaw", "workspace") : "";
  if (isWorkspaceRoot(cwdOpenClawWorkspace)) return path.resolve(cwdOpenClawWorkspace);

  const pluginDir = String(options.pluginDir || __dirname).trim();
  const extensionMatch = pluginDir.match(/^(.*?)(?:\/|\\)\.openclaw(?:\/|\\)extensions(?:\/|\\).+$/);
  if (extensionMatch) {
    const siblingWorkspace = path.join(extensionMatch[1], ".openclaw", "workspace");
    if (isWorkspaceRoot(siblingWorkspace)) return path.resolve(siblingWorkspace);
  }

  const homeDir = String(options.homeDir || os.homedir() || "").trim();
  const standardHomeWorkspace = homeDir ? path.join(homeDir, ".openclaw", "workspace") : "";
  return path.resolve(standardHomeWorkspace || path.join(os.homedir(), ".openclaw", "workspace"));
}

module.exports = {
  isWorkspaceRoot,
  resolveWorkspaceRoot,
};
